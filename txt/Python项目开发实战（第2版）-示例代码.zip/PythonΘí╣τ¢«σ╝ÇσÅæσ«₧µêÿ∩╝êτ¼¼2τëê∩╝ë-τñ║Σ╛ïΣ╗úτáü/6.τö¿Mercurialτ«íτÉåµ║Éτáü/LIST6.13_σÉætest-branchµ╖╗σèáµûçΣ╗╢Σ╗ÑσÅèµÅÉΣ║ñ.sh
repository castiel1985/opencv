$ touch test2.txt
$ hg add test2.txt
$ hg commit
