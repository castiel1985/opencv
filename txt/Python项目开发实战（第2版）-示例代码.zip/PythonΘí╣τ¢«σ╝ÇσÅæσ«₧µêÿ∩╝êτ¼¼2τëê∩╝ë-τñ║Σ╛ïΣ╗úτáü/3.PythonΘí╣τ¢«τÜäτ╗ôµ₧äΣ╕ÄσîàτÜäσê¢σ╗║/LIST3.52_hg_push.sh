$ hg push https://bitbucket.org/<你的Bitbucket帐户>/guestbook
