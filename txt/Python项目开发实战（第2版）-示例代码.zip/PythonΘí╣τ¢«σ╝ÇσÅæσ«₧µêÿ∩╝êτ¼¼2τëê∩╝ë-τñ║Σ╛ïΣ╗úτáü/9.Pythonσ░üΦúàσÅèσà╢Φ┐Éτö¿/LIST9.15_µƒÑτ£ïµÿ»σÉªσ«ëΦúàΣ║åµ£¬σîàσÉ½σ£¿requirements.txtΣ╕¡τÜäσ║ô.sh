$ pip freeze -r requirements.txt
