$ sudo apt-get install nginx
