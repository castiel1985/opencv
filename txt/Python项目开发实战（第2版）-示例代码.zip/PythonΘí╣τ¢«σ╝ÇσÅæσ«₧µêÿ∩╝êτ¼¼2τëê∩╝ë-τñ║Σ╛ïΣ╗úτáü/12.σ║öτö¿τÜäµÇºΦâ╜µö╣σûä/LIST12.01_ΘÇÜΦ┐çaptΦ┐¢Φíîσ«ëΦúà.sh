$ sudo apt-get install apache2-utils
