var express = require('express');
var router = express.Router();
var logger = require('../utils/winstonUtils').logger;
var commonUtils = require('../utils/Common');
var Network = require('../middleware/network');



/* index.html . */
router.get('/', function(req, res, next) {

  Network.printHead(req);

  var code  = req.query.code || '';
  var reason = {
    "SESSION_TIMEOUT":"您的会话已经过期",
    "NEED_LOGIN":"没有登录",
    "UNKNOWN_USER":"无效的用户名",
    "INVALID_USER":"用户名或密码不正确",
    "NOT_APPROVE":"该用户未审批",
    "APP_CLIENT":"该用户只能在app端登录",
    "VERIFICATION_CODE":"验证码不正确",
    "FILE_ERROR": "文件丢失"
  };
  res.render('index', {
    reasons: function(key){
      return reason[key.toLowerCase()] || "无效的用户";
    },
    code: code,
    msg: reason[code] || "无效的用户",
    layout:'partial/login'
  });
});

module.exports = router;