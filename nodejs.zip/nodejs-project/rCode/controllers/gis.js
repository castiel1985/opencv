"use strict";
/**
 * Created by Alen on 15/2/28.
 * https://github.com/szanlin
 */
var express = require('express');
var router = express.Router();
var logger = require('../utils/winstonUtils').logger;

router.get('/', function(req, res, next) {
  var location = req.query["location"];
  res.render('gis', {
    layout: 'partial/gis_layout',
    location:location
  });
});

module.exports = router;