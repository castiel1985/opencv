/**
 * Created by szanlin on 15/2/17.
 */
var validator = require('validator');
var crypto = require('crypto');
/**
 * 暂时检测非空
 * @param str
 * @returns {*}
 */
exports.usernameCheck = function(str){
  return !validator.isNull(str) ;
};

exports.getClientIp = function(req){
  var logger = require('./winstonUtils').logger;
   /*var ip = req.headers['x-forwarded-for']
    || req.connection.remoteAddress;
  logger.info("====="+ ip +"=====");

  *//*if(ip) {
    ip = ip.replace("::ffff:","");
  }*//*
  return ip;*/

  var ipAddress = "bbb";
  var headers = req.headers;
  var forwardedIpsStr = headers['x-real-ip'] || headers['x-forwarded-for'];
  logger.info("======headers['x-real-ip']"+ (headers['x-real-ip'] || "aa") +"=======");
  logger.info("======headers['x-forwarded-for']"+ (headers['x-forwarded-for'] || "aa") +"=======");
  logger.info("======req.ip"+ (req.ip || "aa") +"=======");
  logger.info("======req.ips"+ (req.ips || "aa") +"=======");
  /*forwardedIpsStr ? ipAddress = forwardedIpsStr : ipAddress = null;
  if (!ipAddress || ipAddress == "127.0.0.1") {
    ipAddress = req.connection.remoteAddress;
  }
  if(!ipAddress || ipAddress == "127.0.0.1"){
    ipAddress = req.socket.remoteAddress;
  }
  if(!ipAddress || ipAddress == "127.0.0.1"){
    ipAddress =  req.ip;
  }
  if(ipAddress) {
    ipAddress = ipAddress.replace("::ffff:","");
  }
  logger.info("======"+ipAddress+"=======");*/

  return ipAddress;

};

exports.generateAntiCode = function (qrcode){
  return "";
};

exports.numToBase36= function(num){
  return (num).toString(36).toUpperCase();
};

exports.escape = function(str){

};

exports.padZero = function(str,num){
 return pad(str,num);
};

function pad(str,num){
  str = str.toString();
  while(str.length < num){
    str = "0" + str;
  }
  return str;
}

exports.dateFormat = function(date,fmt){
  fmt = fmt || "yyyy-MM-dd hh:mm";
  var o = {
    "M+": date.getMonth() + 1, //月份
    "d+": date.getDate(), //日
    "h+": date.getHours(), //小时
    "m+": date.getMinutes(), //分
    "s+": date.getSeconds(), //秒
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度
    "S": date.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
};

exports.date2Long = function(date){
  return date.getMilliseconds();
};

exports.generateFakeCode = function(num){
  var str = "";
  for(var i=0; i<num; i++){
    str = str + Math.floor(Math.random() * 10);
  }
  return str;
};


/**
 * hash
 *
 * @param {String} method hash method, e.g.: 'md5', 'sha1'
 * @param {String|Buffer} s
 * @param {String} [format] output string format, could be 'hex' or 'base64'. default is 'hex'.
 * @return {String} md5 hash string
 * @public
 */
exports.hash = function hash(method, s, format) {
  var sum = crypto.createHash(method);
  var isBuffer = Buffer.isBuffer(s);
  if (!isBuffer && typeof s === 'object') {
    s = JSON.stringify(s);
    //s = JSON.stringify(sortObject(s));
  }
  sum.update(s, isBuffer ? 'binary' : 'utf8');
  return sum.digest(format || 'hex');
};

/**
 * md5 hash
 *
 * @param {String|Buffer} s
 * @param {String} [format] output string format, could be 'hex' or 'base64'. default is 'hex'.
 * @return {String} md5 hash string
 * @public
 */
exports.md5 = function md5(s, format) {
  return exports.hash('md5', s, format);
};



exports.isAjaxReq = function (req){
  return req.query["ajax"] === "1";
};


exports.PER_PAGE_NUM = 10;