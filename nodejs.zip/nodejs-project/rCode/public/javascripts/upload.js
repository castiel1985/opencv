(function($) {

  var UploaderObj = function($wrap,opts){
    var defaults = {
      maxFileNum: 10,
      btnLabel: "点击选择图片",
      continueBtnLabel: "继续添加",
      fileCount : 0
    }
    this.options = $.extend(defaults, opts);

    this.$wrap = $wrap;
    // 图片容器
    this.$queue = this.$wrap.find(".filelist").length > 0 ? this.$wrap.find(".filelist") : $('<ul class="filelist"></ul>').appendTo(this.$wrap.find('.queueList'));
    // 状态栏，包括进度和控制按钮
    this.$statusBar = this.$wrap.find('.statusBar');
    // 文件总体选择信息。
    this.$info = this.$statusBar.find('.info');
    // 上传按钮
    this.$upload = this.$wrap.find('.uploadBtn');
    // 没选择文件之前的内容。
    this.$placeHolder = this.$wrap.find('.placeholder');
    // 总体进度条
    this.$progress = this.$statusBar.find('.progress').hide();
    // 添加的文件数量
    this.fileCount = this.options.fileCount;
    // 添加的文件总大小
    this.fileSize = 0;
    // 优化retina, 在retina下这个值是2
    this.ratio = window.devicePixelRatio || 1;

    this.continueAdd = this.$wrap.find('.pic-upload-continue');

    // 缩略图大小
    this.thumbnailWidth = 110 * this.ratio;
    this.thumbnailHeight = 110 * this.ratio;

    // 可能有pedding, ready, uploading, confirm, done.
    this.state = 'pedding';

    // 所有文件的进度信息，key为file id
    this.percentages = {};

    // WebUploader实例
    this.uploader;
  }

  UploaderObj.prototype = {

    _supportTransition : function(){
      var s = document.createElement('p').style;
      var r = 'transition' in s ||
          'WebkitTransition' in s ||
          'MozTransition' in s ||
          'msTransition' in s ||
          'OTransition' in s;
      s = null;
      return r;
    },

    _init : function(){
      var _self = this;
      if (!WebUploader.Uploader.support()) {
        alert('Web Uploader 不支持您的浏览器！如果你使用的是IE浏览器，请尝试升级 flash 播放器');
        throw new Error('WebUploader does not support the browser you are using.');
      }

      // 实例化
      _self.uploader = WebUploader.create({
        pick: {
          id: _self.$wrap.find('.filePicker'),
          label: _self.options.btnLabel
        },
        dnd: _self.$wrap.find('.queueList'),
        paste: document.body,

        accept: {
          title: 'Images',
          extensions: 'gif,jpg,jpeg,bmp,png',
          mimeTypes: 'image/*'
        },

        // swf文件路径
        swf: '/bower_components/fex-webuploader/dist/Uploader.swf',

        disableGlobalDnd: true,

        chunked: true,
        // server: 'http://webuploader.duapp.com/server/fileupload.php',
        server: '/api/upload_file',
        fileNumLimit: _self.options.maxFileNum - _self.fileCount,
        fileSizeLimit: 5 * 1024 * 1024, // 50 M
        fileSingleSizeLimit: 1 * 1024 * 1024 // 1 M
      });

      _self.uploader.addButton({
        id: _self.continueAdd,
        label: _self.options.continueBtnLabel
      });

      _self.uploader.onUploadProgress = function(file, percentage) {
        var $li = $('#' + file.id),
          $percent = $li.find('.progress span');

        $percent.css('width', percentage * 100 + '%');
        _self.percentages[file.id][1] = percentage;
        _self.updateTotalProgress();
      };

      _self.uploader.onFileQueued = function(file) {
        _self.fileCount++;
        _self.fileSize += file.size;
        if (_self.fileCount === 1) {
          _self.$placeHolder.addClass('element-invisible');
          _self.$statusBar.show();
        }
        _self.addFile(file);
        _self.setState('ready');
        _self.updateTotalProgress();
      };

      _self.uploader.onFileDequeued = function(file) {
        _self.fileCount--;
        _self.fileSize -= file.size;

        if (!_self.fileCount) {
          _self.setState('pedding');
        }
        _self.removeFile(file);
        _self.updateTotalProgress();
      };

      _self.uploader.on('all', function(type) {
        var stats;
        switch (type) {
          case 'uploadFinished':
            _self.setState('confirm');
            break;
          case 'startUpload':
            _self.setState('uploading');
            break;
          case 'stopUpload':
            _self.setState('paused');
            break;
        }
      });

      _self.uploader.onError = function(code) {
        var text;
        switch (code) {
          case 'Q_TYPE_DENIED':
            text = '图片格式不对，目前支持：gif,jpg,jpeg,bmp,png';
            break;
          case 'Q_EXCEED_NUM_LIMIT':
            text = '图片已超过限制总数';
            break;
          case 'F_EXCEED_SIZE':
            text = '图片超过1M限制大小';
            break;
          case 'F_DUPLICATE':
            text = '图片重复';
            break;
          default:
            text = '上传失败，请重试';
            break;
        }
        alert(text);
      };

      _self.$upload.on('click', function() {
        if ($(this).hasClass('disabled')) {
          return false;
        }
        if (_self.state === 'ready') {
          _self.uploader.upload();
        } else if (_self.state === 'paused') {
          _self.uploader.upload();
        } else if (_self.state === 'uploading') {
          _self.uploader.stop();
        }
      });

      _self.$info.on('click', '.retry', function() {
        _self.uploader.retry();
      });

      _self.$info.on('click', '.ignore', function() {
        alert('todo');
      });

      _self.$upload.addClass('state-' + _self.state);
      _self.updateTotalProgress();
    },

    //当有文件添加进来时执行，负责view的创建
    addFile: function(file){
      var _self = this;
      //_self.options.isMutli ? null : _self.$wrap.find("ul.filelist").html("");
      var $li = $('<li id="' + file.id + '">' +
        '<p class="title">' + file.name + '</p>' +
        '<p class="imgWrap"></p>' +
        '<p class="progress"><span></span></p>' +
        '</li>'),

        $btns = $('<div class="file-panel">' +
        '<span class="cancel">删除</span>' +
        '<span class="rotateRight">向右旋转</span>' +
        '<span class="rotateLeft">向左旋转</span></div>').appendTo($li),
        $prgress = $li.find('p.progress span'),
        $wrap = $li.find('p.imgWrap'),
        $info = $('<p class="error"></p>'),

        showError = function(code) {
          var text = "";
          switch (code) {
            case 'exceed_size':
              text = '文件大小超出';
              break;
            case 'interrupt':
              text = '上传暂停';
              break;
            default:
              text = '上传失败，请重试';
              break;
          }
          $info.text(text).appendTo($li);
        };

      if (file.getStatus() === 'invalid') {
        showError(file.statusText);
      } else {
        $wrap.text('预览中');
        _self.uploader.makeThumb(file, function(error, src) {
          if (error) {
            $wrap.text('不能预览');
            return;
          }
          var img = $('<img src="' + src + '">');
          $wrap.empty().append(img);
        }, _self.thumbnailWidth, _self.thumbnailHeight);

        _self.percentages[file.id] = [file.size, 0];
        file.rotation = 0;
      }

      file.on('statuschange', function(cur, prev) {
        if (prev === 'progress') {
          $prgress.hide().width(0);
        } else if (prev === 'queued') {
          $li.off('mouseenter mouseleave');
          $btns.remove();
        }

        // 成功
        if (cur === 'error' || cur === 'invalid') {
          showError(file.statusText);
          _self.percentages[file.id][1] = 1;
        } else if (cur === 'interrupt') {
          showError('interrupt');
        } else if (cur === 'queued') {
          _self.percentages[file.id][1] = 0;
        } else if (cur === 'progress') {
          $info.remove();
          $prgress.css('display', 'block');
        } else if (cur === 'complete') {
          $li.append('<span class="success"></span>');
        }
        $li.removeClass('state-' + prev).addClass('state-' + cur);
      });

      $li.on('mouseenter', function() {
        $btns.stop().animate({
          height: 30
        });
      });
      $li.on('mouseleave', function() {
        $btns.stop().animate({
          height: 0
        });
      });
      $btns.on('click', 'span', function() {
        var index = $(this).index(),
          deg;
        switch (index) {
          case 0:
            _self.uploader.removeFile(file);
            return;
          case 1:
            file.rotation += 90;
            break;
          case 2:
            file.rotation -= 90;
            break;
        }

        if (_self._supportTransition()) {
          deg = 'rotate(' + file.rotation + 'deg)';
          $wrap.css({
            '-webkit-transform': deg,
            '-mos-transform': deg,
            '-o-transform': deg,
            'transform': deg
          });
        } else {
          $wrap.css('filter', 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + (~~((file.rotation / 90) % 4 + 4) % 4) + ')');
        }
      });
      $li.appendTo(_self.$queue);
    },

    incrFileNumLimit: function(){
      var _self = this;
      var num = _self.uploader.option("fileNumLimit");
      _self.uploader.option("fileNumLimit", num + 1);
    },

    // 负责view的销毁
    removeFile : function (file) {
      var _self = this;
      var $li = $('#' + file.id);
      delete _self.percentages[file.id];
      _self.updateTotalProgress();
      $li.off().find('.file-panel').off().end().remove();
    },

    updateTotalProgress : function () {
      var _self = this;
      var loaded = 0,
        total = 0,
        spans = _self.$progress.children(),
        percent;

      $.each(_self.percentages, function(k, v) {
        total += v[0];
        loaded += v[0] * v[1];
      });
      percent = total ? loaded / total : 0;
      spans.eq(0).text(Math.round(percent * 100) + '%');
      spans.eq(1).css('width', Math.round(percent * 100) + '%');
      _self.updateStatus();
    },

    getState :function(){
      var _self = this;
      return _self.state;
    },

    getfileCount :function(){
      var _self = this;
      return _self.fileCount;
    },

    setfileCount :function(val){
      var _self = this;
      _self.fileCount = val;
    },

    updateStatus : function () {
      var _self = this;
      var text = '',
        stats;

      if (_self.state === 'ready') {
        text = '选中' + _self.fileCount + '张图片，共' +
        WebUploader.formatSize(_self.fileSize) + '。';
      } else if (_self.state === 'confirm') {
        stats = _self.uploader.getStats();
        if (stats.uploadFailNum) {
          text = '已成功上传' + stats.successNum + '张照片至服务器，' +
          stats.uploadFailNum + '张照片上传失败，<a class="retry" href="#">重新上传</a>失败图片或<a class="ignore" href="#">忽略</a>'
        }
      } else {
        stats = _self.uploader.getStats();
        text = '共' + _self.fileCount + '张（' + WebUploader.formatSize(_self.fileSize) + '），已上传' + stats.successNum + '张';
        if (stats.uploadFailNum) {
          text += '，失败' + stats.uploadFailNum + '张';
        }
      }
      _self.$info.html(text);
      if(_self.fileCount > 0){
        _self.$statusBar.show();
      }else{
        _self.$statusBar.hide();
      }
    },

    setState : function (val) {
      var _self = this;
      var file, stats;
      if (val === _self.state) {
        return;
      }
      _self.$upload.removeClass('state-' + _self.state);
      _self.$upload.addClass('state-' + val);
      _self.state = val;

      switch (_self.state) {
        case 'pedding':
          _self.$placeHolder.removeClass('element-invisible');
          _self.$queue.parent().removeClass('filled');
          _self.$queue.hide();
          _self.$statusBar.addClass('element-invisible');
          _self.uploader.refresh();
          break;
        case 'ready':
          _self.$placeHolder.addClass('element-invisible');
          _self.continueAdd.removeClass('element-invisible');
          _self.$queue.parent().addClass('filled');
          _self.$queue.show();
          _self.$statusBar.removeClass('element-invisible');
          _self.uploader.refresh();
          break;
        case 'uploading':
          _self.continueAdd.addClass('element-invisible');
          _self.$progress.show();
          _self.$upload.text('暂停上传');
          break;
        case 'paused':
          _self.$progress.show();
          _self.$upload.text('继续上传');
          break;
        case 'confirm':
          _self.$progress.hide();
          _self.$upload.text('开始上传').addClass('disabled');
          stats = _self.uploader.getStats();
          if (stats.successNum && !stats.uploadFailNum) {
            _self.setState('finish');
            return;
          }
          break;
        case 'finish':
          stats = _self.uploader.getStats();
          if (stats.successNum) {
            alert('上传成功');
          } else {
            _self.state = 'done';
            location.reload();
          }
          break;
      }
      _self.updateStatus();
    }
  };

  $.fn.uploader = function(arg1, arg2) {
    var results = [];
    this.each(function () {
      var $this = $(this);
      var uploadObj = $this.data( "upload-box" );

      // Initialize a new tags input
      if (!uploadObj ) {
        uploadObj = new UploaderObj($this, arg1);
        $this.data( "upload-box", uploadObj );
        uploadObj._init();
      } else {
        var val;
        if(arg2 || arg2 === 0){
          val = uploadObj[arg1](arg2);
        }else{
          val = uploadObj[arg1]();
        }
        if(val) {
          results.push( val );
        }
      }
    });

    if (typeof arg1 === "string") {
      return ( results.length > 1 ) ? results : results[0];
    }
    return results;
  };
})(jQuery);
