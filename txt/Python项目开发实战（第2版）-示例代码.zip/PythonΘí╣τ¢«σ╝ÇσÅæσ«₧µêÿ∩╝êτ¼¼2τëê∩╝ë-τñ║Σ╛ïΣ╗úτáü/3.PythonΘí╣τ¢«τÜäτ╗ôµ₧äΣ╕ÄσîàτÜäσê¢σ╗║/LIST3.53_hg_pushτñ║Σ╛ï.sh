$ hg push https://bitbucket.org/beproud/guestbook
