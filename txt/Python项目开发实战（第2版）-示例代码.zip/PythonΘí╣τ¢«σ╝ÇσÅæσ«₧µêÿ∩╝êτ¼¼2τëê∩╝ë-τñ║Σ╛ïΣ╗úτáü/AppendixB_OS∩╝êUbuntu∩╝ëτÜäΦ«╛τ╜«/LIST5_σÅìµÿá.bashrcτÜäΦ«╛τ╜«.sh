$ source ~/.bashrc
