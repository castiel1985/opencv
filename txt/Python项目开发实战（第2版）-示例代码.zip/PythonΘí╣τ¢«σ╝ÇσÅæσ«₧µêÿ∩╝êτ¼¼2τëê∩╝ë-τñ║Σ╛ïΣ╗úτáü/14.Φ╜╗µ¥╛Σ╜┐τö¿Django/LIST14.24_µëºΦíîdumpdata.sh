$ python manage.py dumpdata polls > polls.json
