"use strict";
/**
 * Created by Alen on 15/2/18.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var async = require('async');



function getProductionNum(userId, callback) {
  var sql = "select count(id) as cnt from qr_production where state = true  and creator =:userId";
  database.query({
    sql: sql,
    params: {
      "userId":userId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, rows[0]);
  });
}

function getBrandNum(userId, callback) {
  var sql = "select count(id) as cnt from qr_brand where state = true and creator =:userId";
  database.query({
    sql: sql,
    params: {
      "userId":userId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, rows[0]);
  });
}


