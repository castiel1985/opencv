$ hg branches

test-branch  1:bcbc567db3dd
default      0:74471564b074 (inactive)
