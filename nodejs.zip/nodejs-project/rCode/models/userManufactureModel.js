"use strict";
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;

function getUserManufactureByCorpId(tableParams, callback){
  var sqlData = "SELECT a.*,b.name as role_name,b.id as role_id,d.name as user_name,d.username FROM qr_user_manufacture a,qr_role b,qr_user c,qr_user d " +
    "WHERE c.corporation_id = :corpId and a.creator = c.id and a.role_id = b.id and a.user_id = d.id and a.state =:state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_user_manufacture a,qr_user c WHERE c.corporation_id = :corpId and a.creator = c.id and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and b.name like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_user_manufacture a,qr_role b,qr_user c " +
    "WHERE c.corporation_id = :corpId and a.creator = c.id and a.role_id = b.id and a.state =:state and b.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getUserManufactureByUserId(params, callback){
  database.query({
    sql: "SELECT distinct manufacture_id FROM qr_user_manufacture a,qr_role_manufacture b WHERE a.user_id =:userId and a.state =:state and b.role_id = a.role_id  and b.state =:state",
    params: params
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function addUserManufacture(params, callback){
  var sql = 'INSERT INTO qr_user_manufacture (' +
    '`user_id`,' +
    '`role_id`,' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(' +
    ':user_id,'+
    ':role_id,'+
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"),null);
    }
    var id = result.insertId;
    return callback(null, id);
  });
}

function getUserManufactureById(id, callback){
  database.query({
    sql: "SELECT a.*,b.name as role_name,b.id as role_id,c.name as user_name,c.id as user_id,c.username " +
    "FROM qr_user_manufacture a,qr_role b,qr_user c WHERE a.id = :id and a.user_id = c.id and a.role_id = b.id and a.state =1",
    params: {
      "id": id
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

function updateUserManufactureById(params, callback){
  var sql = "UPDATE qr_user_manufacture SET " +
    "user_id =:user_id, " +
    "role_id =:role_id " +
    "where id =:id";
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function deleteUserManufactureById(id, callback){
  database.query({
    sql: "UPDATE qr_user_manufacture SET state = 0 WHERE id =:id",
    params: {
      "id": id
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

function deleteUserManufactureByRole(roleId, callback){
  database.query({
    sql: "UPDATE qr_user_manufacture SET state = 0 WHERE role_id =:roleId",
    params: {
      "roleId": roleId
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

exports.getUserManufactureById = getUserManufactureById;
exports.addUserManufacture = addUserManufacture;
exports.getUserManufactureByUserId = getUserManufactureByUserId;
exports.getUserManufactureByCorpId = getUserManufactureByCorpId;
exports.updateUserManufactureById = updateUserManufactureById;
exports.deleteUserManufactureById = deleteUserManufactureById;
exports.deleteUserManufactureByRole = deleteUserManufactureByRole;