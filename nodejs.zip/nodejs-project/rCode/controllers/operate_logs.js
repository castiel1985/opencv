"use strict";
var express = require('express');
var router = express.Router();
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('intel');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var corpModel = require('../models/corpModel');
var userModel = require('../models/userModel');
var nconf = require('nconf');
var async = require("async");

router.get('/', function(req, res, next) {

  var date = commonUtils.dateFormat(new Date(),"yyyy-MM-dd");
  var usr = req.session.rcode.user;
  if(usr.isCorpAdmin){
    corpModel.getCorpById(usr.corporation_id, function(err, row){
      return res.render('operate_logs/result', {
        date_start:date,
        date_end:date,
        corp:row,
        header: "日志审计"
      });
    });
  }else{
    return res.render('operate_logs/result', {
      date_start:date,
      date_end:date,
      header: "日志审计"
    });
  }


});

router.get('/result', function(req, res, next) {
  res.redirect("/operate_logs");
});

router.get('/result/list', function(req,res,next){

  var usr = req.session.rcode.user;
  var corpId = req.query['corporation'];
  var userIds = [];

  var action = nconf.get("action");
  var action_name = nconf.get("action_name");
  var url = nconf.get("url");
  var menu = nconf.get("menu");
  var content_name = nconf.get("content");

  var action_corv = {};
  for (var actionKey in action) {
    var actionVal1 = action[actionKey];
    var actionVal2 = action_name[actionKey];
    action_corv[actionVal1] = actionVal2;
  }

  var menu_corv = {};
  for (var urlKey in url) {
    var urlVal1 = url[urlKey];
    var urlVal2 = menu[urlKey];
    menu_corv[urlVal1] = urlVal2;
  }

  async.waterfall([
    function(cb){
      userModel.getUsersByCorpId(corpId, usr, function(err, rows){
        rows && rows.forEach(function(item){
          userIds.push(item.id);
        });
        userIds = userIds.join(",");
        var tableParams = dataTableObj.getParams(req);
        if(req.query['userId']){
          tableParams.userId = req.query['userId'];
        }else if(!userIds){
          tableParams.userId = usr.id;
        }else{
          tableParams.userIds = userIds;
        }
        if(req.query['menu'] && req.query['menu'] != "all"){
          tableParams.url = req.query['menu'];
        }
        if(req.query['action'] && req.query['action'] != "all"){
          tableParams.action = req.query['action'];
        }
        tableParams.date_start = req.query['date_start'];
        tableParams.date_end = req.query['date_end'];
        cb(err, tableParams);
      });
    },
    function(tableParams,cb){
      logsModel.getOperateLogs(tableParams, function(tableData) {
        var rows = tableData.aaData;
        rows && rows.forEach(function(item, index){
          item.date = commonUtils.dateFormat(new Date(item.create_time),"yyyy-MM-dd");
          item.time = commonUtils.dateFormat(new Date(item.create_time),"yyyy-MM-dd hh:mm:ss");
          item.action_name = action_corv[item.action];
          item.menu = menu_corv[item.url];
          item.username = item.name + " (" + item.username + ")";
          if(item.content){
            var content = "";
            var obj = JSON.parse(item.content);
            for(var key in obj){
              var value = obj[key];
              if(key === "name"){
                key = item.operate_type + content_name[key];
              }else{
                key = content_name[key];
              }
              if(value && (value.old || value.new)){
                var o = value.old;
                var n = value.new;
                content += key + ": " + o + " -> " + n + "<br/>";
              }else{
                content += key + ": " + value + "<br/>";
              }
            }
            item.content = content;
          }
        });
        tableData.aaData = rows;
        cb(null, tableData);
      });
    }
    ],function(err, tableData){
      if(!err){
        return res.send(tableData);
      }else{
        return res.send(null);
      }
    }
  );
});

router.post('/result', function(req,res,next){
  var date_start = req.body.date_start;
  var date_end = req.body.date_end;
  var opt = {
    corporation:req.body.corporation || req.body.supervisor,
    corporation_name:req.body.corporation_name || req.body.supervisor_name,
    user_id:req.body.user_id,
    username:req.body.username,
    menu:req.body.menu,
    menu_name:req.body.menu_name,
    action:req.body.action,
    action_name:req.body.action_name
  };
  var corp = {
    id:req.body.corporation,
    name:req.body.corporation_name
  };
  return res.render('operate_logs/result', {
    date_start:date_start,
    date_end:date_end,
    opt:opt,
    corp:corp,
    header: "日志审计",
    result:true,
    user:req.session.rcode.user
  });
});

router.get('/corporations', function(req,res,next){
  var usr = req.session.rcode.user;
  corpModel.getCorpsByUserRole(usr, function(err,rows){
    return res.send(rows);
  });
});

router.get('/users', function(req,res,next){
  var corpId = req.query['corpId'];
  var usr = req.session.rcode.user;
  if(!corpId){
    return res.send([]);
  }
  userModel.getUsersByCorpId(corpId, usr, function(err, rows){
    return res.send(rows);
  });
});

router.get('/menu', function(req,res,next){
  var url = nconf.get("url");
  var menu = nconf.get("menu");
  var menus = [{id:"all",name:"所有菜单"}];
  for (var key in menu) {
    var val1 = url[key];
    var val2 = menu[key];
    menus.push({id:val1,name:val2});
  }
  return res.send(menus);
});

router.get('/action', function(req,res,next){
  var action = nconf.get("action");
  var action_name = nconf.get("action_name");
  var actions = [{id:"all",name:"所有类型"}];
  for (var key in action) {
    var val1 = action[key];
    var val2 = action_name[key];
    actions.push({id:val1,name:val2});
  }
  return res.send(actions);
});

router.get('/supervisor', function(req,res,next){
  var usr = req.session.rcode.user;
  corpModel.getAllSuperiors(function(err, rows){
    res.send(rows);
  });
});

module.exports = router;