"use strict";
var express = require('express');
var router = express.Router();
var userModel = require('../models/userModel');
var roleModel = require('../models/roleModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var passwordHash = require('../utils/Password');
var logger = require('../utils/winstonUtils').logger;
var corpModel = require('../models/corpModel');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/profile', function(req, res, next) {

  var opt = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:member"),
    action:nconf.get("action:view"),
    operate_type:nconf.get("operate_type:member"),
    operate_id:req.session.rcode.user.id,
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  res.render('admin/profile', {
    header: "用户设置",
    userinfo: req.session.rcode.user
  });
});

router.get('/profile/update', function(req, res, next) {
  res.redirect('/system/profile');
});

router.post('/profile/update', function(req, res, next) {
  var name = req.body.name;
  var mail = req.body.mail;
  var mobile_phone = req.body.mobile_phone;
  var oldpass = req.body.oldpass;
  var newpass = req.body.newpass;
  var newpass2 = req.body.newpass2;
  var userId = req.body.user_id;
  var msg = "用户资料更新成功";

  var usr = req.session.rcode.user;

  if (oldpass !== usr.passwd) {
    msg = "旧密码不正确";
    return res.render('admin/profile', {
      header: "用户资料",
      userinfo: req.session.rcode.user,
      msg: messageUtils.msgSuccess(msg)
    });
  }

  var hashedPass = passwordHash.generate(newpass);
  var saved = passwordHash.getPasswdResult(hashedPass);
  var params = {
    userId:userId,
    salt:saved.salt,
    password:saved.password
  };

  userModel.updatePass(params, function(err, result){
    if(err || !result){
      msg = "用户资料更新失败";
    }else{
      var user = req.session.rcode.user;
      user.name = name;
      user.mail = mail;
      user.passwd = newpass;
      user.mobile_phone = mobile_phone;
      req.session.rcode.user = user;
    }
    var opt = {
      user_id:usr.id,
      url:nconf.get("url:member"),
      action:nconf.get("action:update"),
      operate_type:nconf.get("operate_type:member"),
      operate_id:usr.id,
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    res.render('admin/profile', {
      header: "用户资料",
      userinfo: req.session.rcode.user,
      msg: messageUtils.msgSuccess(msg)
    });
  });

});

router.get('/user_manage/modify/:user_id/:status', function(req, res, next){
  var userId = req.params.user_id;
  var status = req.params.status;
  var msg = status === "1" ? "用户已启用" : "用户已禁用";
  var action = status === "1" ? nconf.get("action:user_enable") : nconf.get("action:user_disable");

  var opt = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:member"),
    action:action,
    operate_type:nconf.get("operate_type:member"),
    operate_id:userId,
    content:{status:status === "1" ? "用户启用" : "用户禁用"},
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  userModel.modifyStatus(userId,status,function(err, result){
    if(err || !result){
      return next(err);
    }else{
      req.session.rcode.msg = messageUtils.msgSuccess(msg);
      res.redirect('/system/user_manage');
    }
  });
});

router.get('/user_manage/reset/:userId/:username', function(req, res, next){
  var userId = req.params.userId;
  var username = req.params.username;
  var msg = "用户["+username+"]密码重置成功！默认密码跟用户名相同。";
  var hashedPass = passwordHash.generate(username);
  var saved = passwordHash.getPasswdResult(hashedPass);
  var params = {
    userId:userId,
    salt:saved.salt,
    password:saved.password
  };
  userModel.updatePass(params, function(err, result){
    if(err || !result){
      msg = "密码重置失败！";
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:member"),
      action:nconf.get("action:user_reset"),
      operate_type:nconf.get("operate_type:member"),
      operate_id:userId,
      content:{username:username},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    req.session.rcode.msg = messageUtils.msgSuccess(msg);
    res.redirect('/system/user_manage');
  });
});


router.get('/user_manage', function(req, res, next) {
  var user = req.session.rcode.user;
  var params = {
    user_id:user.id,
    url:nconf.get("url:member"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:member"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  var usr = req.session.rcode.user;
  messageUtils.getSessionMsg(req, res);
  return res.render('admin/members/index', {
    header: "用户管理",
    user: user
  });
});

router.get('/user_manage/list', function(req, res, next) {
  var user = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.corpId = user.corporation_id;
  tableParams.status = 1;
  tableParams.identity = "supervisor";
  tableParams.corpId = user.corporation_id;
  userModel.getUsersByRole(user, tableParams, function(tableData) {
    tableData.aaData.forEach(function(item, i){
      item.create_date = commonUtils.dateFormat(new Date(item.create_date));
    });
    return res.send(tableData);
  });
});


router.get('/user_manage/add', function(req, res, next) {
  var user = req.session.rcode.user;
  var corpId = user.corporation_id;
  var corp;
  var roles;

  corpModel.getCorpsByUserRole(user, function(err, rows){
    if (err) {
      return next(err);
    }
    if(user.isAdmin){
      roles = [{id:4,name:"监管部门"}];
    }
    if(user.isSupervisor){
      roles = [{id:2,name:"企业管理员"}];
    }
    if(user.isCorpAdmin){
      corp = rows[0];
      roles = [{id:3,name:"企业用户"}];
    }
    res.render('admin/members/add', {
      header: "用户管理 > 新建用户",
      user: user,
      corps: rows,
      roles:roles,
      corp: corp
    });
  });
});

router.post('/user_manage/add', function(req, res, next) {
  var newpass = req.body.newpass;
  var newpass2 = req.body.newpass2;
  var usr = req.session.rcode.user;

  var corpId = req.body.corporation_id || req.body.superior_id;
  var roleId = req.body.role_id;
  var status = usr.isAdmin || usr.isSupervisor ? 1 : 0;
  var msg;
  var client = req.body.client.length > 1 ? 0 : req.body.client;
  if(req.session.rcode && req.session.rcode.corporation){
    var corp = req.session.rcode.corporation;
    if(corp && corp.is_auto_approve){
      status = 1;
    }
  }

  var params = {
    username: req.body.username,
    corporation_id:corpId,
    name: req.body.name,
    mail: req.body.mail,
    mobile: req.body.mobile_phone,
    status: status,
    client: client,
    roleId: roleId,
    client_address: commonUtils.getClientIp(req)
  };

  if (newpass !== newpass2) {
    return res.render('admin/members/add', {
      header: "用户管理 > 新建用户",
      msg: messageUtils.msgError("两次输入的密码不一致")
    });
  }
  if(usr.isAdmin || usr.isSupervisor){
    msg = "新建用户成功";
  }else{
    msg = "新建用户成功,请等待审批";
  }

  var hashedPass = passwordHash.generate(newpass);
  var saved = passwordHash.getPasswdResult(hashedPass);

  params.salt = saved.salt;
  params.password = saved.password;
  var usertype;
  if(roleId === '2'){
    usertype = "企业管理员";
  }
  if(roleId === '3'){
    usertype = "企业用户";
  }
  if(roleId === '4'){
    usertype = "监管部门";
  }

  userModel.addUser(params, function(err, result) {
    if (!err && result) {
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:member"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:member"),
        operate_id:result.insertId,
        content:{username: req.body.username,usertype:usertype},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess(msg);
      res.redirect('/system/user_manage');
    } else {
      return next(err);
    }
  });
});

router.get('/role_manage', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  var params = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:roles"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:roles"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  return res.render('admin/roles/index', {
    header: "角色管理"
  });
});

router.get('/role_manage/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;

  roleModel.getRoleList(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_date = commonUtils.dateFormat(new Date(item.create_date));
    });
    return res.send(tableData);
  });
});


router.get('/role_manage/add', function(req, res, next) {
  roleModel.getParentPermissions(function(err, rows) {
    if (err) {
      return next(err);
    }

    return res.render('admin/roles/add', {
      header: "角色管理 > 新建角色",
      permissionList: rows
    });
  });
});

router.post('/role_manage/add', function(req, res, next) {

  var params = {
    name: req.body.name,
    identity: req.body.identity,
    desc: req.body.desc,
    permissions: req.body.permissions.split(','),
    client_address: commonUtils.getClientIp(req)
  };

  roleModel.addRole(params, function(err, roleId) {
    if (!err && roleId) {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:roles"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:roles"),
        operate_id:roleId,
        content:{name:req.body.name,permissions: req.body.permissions.split(',')},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("新建角色成功");
      res.redirect('/system/role_manage');
    } else {
      return next(err);
    }
  });
});

router.get('/role_manage/view/:role_id', function(req, res, next){
  var roleId = req.params.role_id;

  roleModel.getRoleById(roleId,function(err, row){
    if(err){
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:roles"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:roles"),
      operate_id:roleId,
      content:{name:row.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('admin/roles/view', {
      role: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/role_manage/delete/:role_id', function(req, res, next){
  var roleId = req.params.role_id;

  roleModel.delRoleById(roleId,function(err, result){
    if(err || !result){
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:roles"),
      action:nconf.get("action:delete"),
      operate_type:nconf.get("operate_type:roles"),
      operate_id:roleId,
      content:{name:req.query.roleName},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    req.session.rcode.msg = messageUtils.msgSuccess("角色删除成功");
    res.redirect('/system/role_manage');
  });
});

router.get('/user_approve', function(req, res, next) {
  var params = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:member_approve"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:member_approve"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  messageUtils.getSessionMsg(req, res);
  return res.render('admin/members/approve', {
    header: "用户申请审批"
  });
});

router.get('/user_approve/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  tableParams.status = 0;

  userModel.getUsersApproveList(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_date = commonUtils.dateFormat(new Date(item.create_date));
    });
    return res.send(tableData);
  });
});

router.get('/user/approve/:userId/:status', function(req, res, next) {
  var user = req.session.rcode.user;
  var userId = req.params.userId;
  var status = req.params.status;
  var username = req.query.username;
  var params = {
    userId:userId,
    status:status
  };
  var action = status === "1" ? nconf.get("action:approve") : nconf.get("action:approve_refuse");
  var opt = {
    user_id:user.id,
    url:nconf.get("url:member_approve"),
    action:action,
    operate_type:nconf.get("operate_type:member_approve"),
    operate_id:userId,
    content:{username:username},
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  userModel.userApprove(params, function(err, rows) {
    if (err) {
      return next(err);
    }
    req.session.rcode.msg = messageUtils.msgSuccess("用户审批成功");
    res.redirect('/system/user_approve');
  });
});

router.get('/user_manage/unique', function(req, res, next){
  var username = req.query.username;
  userModel.uniqConfirm(username, function(err, result) {
    if (err || !result) {
      return res.send(true);
    }else{
      return res.send(false);
    }
  });
});

router.get('/user_manage/client/:userId', function(req, res, next){
  var userId = req.params.userId;
  var client = req.query.client;
  var params = {
    userId:userId,
    client:client
  };
  var oldClient = req.query.old_client;
  var username = req.query.username;
  var arr = {0:"通用",1:"app端",2:"PC端"};
  var opt = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:member"),
    action:nconf.get("action:update"),
    operate_type:nconf.get("operate_type:member"),
    operate_id:userId,
    content:{client:{old:arr[oldClient],new:arr[client]}},
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  userModel.clientModify(params, function(err, result) {
    if (err || !result) {
      return res.send(false);
    }else{
      return res.send(true);
    }
  });
});

module.exports = router;