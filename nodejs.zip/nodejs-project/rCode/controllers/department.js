"use strict";
var express = require('express');
var router = express.Router();
var departmentModel = require('../models/departmentModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  return res.render('department', {
    header: "部门宣传管理"
  });
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  var opt = {
    user_id:usr.id,
    url:nconf.get("url:department"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:department"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  departmentModel.getDepartmentListByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/update/:id', function(req, res, next) {
  var departmentId = req.params.id;
  departmentModel.getDepartmentById(departmentId, function(err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('department/update', {
      header: " 部门宣传管理 > 部门修改",
      creator: req.session.rcode.user.id,
      department: row
    });
  });
});

router.post('/update/:id', function(req, res, next) {
  var departmentId = req.params.id;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    id: departmentId,
    name:req.body.name,
    desc: req.body.desc || ''
  };

  departmentModel.updateDepartmentById(params, function(err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError("部门信息修改失败");
      return res.redirect('/corp_propaganda/department/update/'+departmentId);
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:department"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:department"),
        operate_id:departmentId,
        content:{name:{old:req.body.old_name,new:req.body.title}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("部门信息修改成功");
      return res.redirect('/corp_propaganda/department');
    }
  });
});

router.get('/add', function(req, res, next) {
  return res.render('department/add', {
    header: "部门宣传管理 > 添加部门",
    creator: req.session.rcode.user.id
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    creator: usr.id,
    corporation_id:usr.corporation_id,
    name: req.body.name,
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  departmentModel.addDepartment( params, function ( err, departmentId){
    if(err){
      return res.render('department/add', {
        header: "部门宣传管理 > 添加部门",
        msg: messageUtils.msgError("部门信息添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:department"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:department"),
        operate_id:departmentId,
        content:{name:req.body.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("部门信息添加成功");
      return res.redirect('/corp_propaganda/department');
    }
  });
});


router.get('/delete/:id', function(req, res, next) {

  var departmentId = req.params.id;
  departmentModel.deletDepartment(departmentId, function(err, brand){
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("部门信息删除失败");
      return res.redirect('/corp_propaganda/department');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:department"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:department"),
        operate_id:departmentId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("部门信息删除成功");
      return res.redirect('/corp_propaganda/department');
    }
  });
});

router.get('/view/:id', function (req, res, next) {
  var departmentId = req.params.id;
  if (underscore.isNaN(departmentId)) {
    return next(new Error("Invalid brandId"));
  }
  departmentModel.getDepartmentById(departmentId, function (err, row) {
    if (err) {
      return next(err);
    }
    var params = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:department"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:department"),
      operate_id: departmentId,
      content: {title: row.name},
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    messageUtils.getSessionMsg(req, res);
    return res.render('department/view', {
      header: "部门详情",
      department: row,
      layout: "partial/modal_layout"
    });
  });
});

module.exports = router;