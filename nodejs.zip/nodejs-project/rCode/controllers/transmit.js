"use strict";
var express = require('express');
var router = express.Router();
var transmitModel = require('../models/transmitModel');
var salesModel = require('../models/salesModel');
var commonUtils = require('../utils/Common');
var QRcode = require('../middleware/qrcode.js');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var qrcodeModel = require('../models/qrcodeModel');
var async = require("async");


router.get('/', function(req, res, next) {

  var usr = req.session.rcode.user;
  var opt = {
    user_id: usr.id,
    url: nconf.get("url:transmit"),
    action: nconf.get("action:index"),
    operate_type: nconf.get("operate_type:transmit"),
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  messageUtils.getSessionMsg(req, res);
  res.render('transmit', {
    header: "配送管理"
  });
});

router.get('/list', function(req, res, next) {

  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  transmitModel.getTransmitList(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  res.render('transmit/add', {
    header: "配送管理 > 发货申请",
    creator:usr.id,
    corpcode:corp.qrcode
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  var creator = req.body.creator;
  var sold_records = req.body.sold_records_selected;
  var record_list = [];
  var codeList = [];
  var values;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }


  var params = {
    creator:creator,
    sender: req.body.sender,
    sender_phone: req.body.sender_phone,
    departure: req.body.departure,
    destination: req.body.destination,
    receiver: req.body.receiver,
    receiver_phone: req.body.receiver_phone,
    sold_records: null,
    status: transmitModel.TRANSMIT_QRCODE_STATUS.no_send,
    client_address: commonUtils.getClientIp(req)
  };
  params.transmit_qrcode = QRcode.getTransmitCodeBySerial(commonUtils.date2Long(new Date()), sold_records, params.creator, corp.qrcode);

  var corp = req.session.rcode.corporation;

  transmitModel.newRecord(params, function (err, transmitId) {
    if (err) {
      return res.render('transmit/add', {
        header: "配送管理 > 发货申请",
        msg: messageUtils.msgError("发货申请失败")
      });
    } else {
      sold_records.split(",").forEach(function (item) {
        //(`transmit_id`,`plan_id`,`production_id`,`apply_id`,`qrcode_start`,`sold_count` )
        var start = parseInt(item.split(":")[2].split("-")[0]);
        var end = parseInt(item.split(":")[2].split("-")[1]);
        var count = end - start + 1;
        record_list.push("("+transmitId+",null,"+parseInt(item.split(":")[0])+","+parseInt(item.split(":")[1])+",'"+start+"',"+count+")");
        var qrcode_prefix = corp.qrcode + "." + commonUtils.padZero(parseInt(item.split(":")[1]), 8);
        codeList.push({
          startcode: qrcode_prefix + "." + commonUtils.padZero(start, 8) + "." + 3,
          endcode: qrcode_prefix + "." + commonUtils.padZero(end, 8) + "." + 3
        });
      });
      console.log(codeList);
      async.eachSeries(codeList, function(item, cb){
        qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.saled, item, function (err, result) {
          if (err) {
            cb(err);
          }else{
            cb();
          }
        });
      },function(err){
        if (err) {
          return res.render('transmit/add', {
            header: "配送管理 > 发货申请",
            msg: messageUtils.msgError("发货申请失败")
          });
        }
      });
      values = record_list.join(",");
      transmitModel.addSoldRecord(values,function (err, planRecordId){
        if(err){
          return res.render('transmit/add', {
            header: "配送管理 > 发货申请",
            msg: messageUtils.msgError("发货申请失败")
          });
        }
        var opt = {
          user_id:usr.id,
          url: nconf.get("url:transmit"),
          action: nconf.get("action:add"),
          operate_type: nconf.get("operate_type:transmit"),
          operate_id: transmitId,
          content: {departure: req.body.departure, destination: req.body.destination},
          state: 1,
          client_address: commonUtils.getClientIp(req)
        };
        logsModel.addOperateLog(opt);
        req.session.rcode.msg = messageUtils.msgSuccess("发货申请成功");
        return res.redirect('/work_manage/production_transmit');
      });
    }
  });
});

router.get('/delete/:transmitId', function(req, res, next) {
  var transmitId = req.params.transmitId;
  transmitModel.getTransmitById(transmitId,function (err,row){
    if(row) {
      var params = {
        state: 0
      };
      transmitModel.updateTransmitById(transmitId, params, function (err, result) {
        if (err) {
          req.session.rcode.msg = messageUtils.msgSuccess("发货申请删除失败");
          return res.redirect('/work_manage/production_transmit');
        }
        transmitModel.getPlanRecordListByTransmitId(transmitId, function (err, rows){
          if (err) {
            req.session.rcode.msg = messageUtils.msgSuccess("发货申请删除失败");
            return res.redirect('/work_manage/production_transmit');
          }else {
            var corp = req.session.rcode.corporation;
            rows && rows.forEach(function (item) {
              var qrcode_prefix = corp.qrcode + "." + commonUtils.padZero(parseInt(item.apply_id), 8);
              var codeList = {
                startcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(item.qrcode_start), 8) + "." + 3,
                endcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(item.qrcode_start+item.sold_count-1), 8) + "." + 3
              };
              qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.packaged, codeList, function (err, result) {
                if (err) {
                  req.session.rcode.msg = messageUtils.msgSuccess("发货申请删除失败");
                  return res.redirect('/work_manage/production_transmit');
                }
              });
            });
            transmitModel.updatePlanRecordByTransmitId(transmitId,function(err, result){
              if (err) {
                req.session.rcode.msg = messageUtils.msgSuccess("发货申请删除失败");
                return res.redirect('/work_manage/production_transmit');
              }
              var opt = {
                user_id:req.session.rcode.user.id,
                url:nconf.get("url:transmit"),
                action:nconf.get("action:delete"),
                operate_type:nconf.get("operate_type:transmit"),
                operate_id:transmitId,
                content:{sender:row.sender},
                state:1,
                client_address: commonUtils.getClientIp(req)
              };
              logsModel.addOperateLog(opt);
              req.session.rcode.msg = messageUtils.msgSuccess("发货申请删除成功");
              return res.redirect('/work_manage/production_transmit');
            });
          }
        });
      });
    }else{
      req.session.rcode.msg = messageUtils.msgSuccess("发货申请已被删除");
      return res.redirect('/work_manage/production_transmit');
    }
  });
});

router.get('/update/:transmitId', function(req, res, next) {
  var transmitId = req.params.transmitId;
  transmitModel.getTransmitById(transmitId,function (err,row){
    var usr = req.session.rcode.user;
    res.render('transmit/update', {
      header: "配送管理 > 发货申请修改",
      transmitList:row,
      creator:usr.id
    });
  });
});

router.post('/update/:transmitId', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var transmitId = req.params.transmitId;
  var old_sold_records = req.body.old_sold_records_selected;
  var sold_records = req.body.sold_records_selected;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    sender:req.body.sender,
    sender_phone:req.body.sender_phone,
    departure:req.body.departure,
    destination:req.body.destination,
    receiver:req.body.receiver,
    receiver_phone:req.body.receiver_phone,
    sold_records:sold_records
  };
  //sold_record   status>1
  salesModel.updateSoldRecordStatus({status: 1}, sold_records, function (err, result) {
    if (err) {
      return res.render('transmit/update', {
        header: "配送管理 > 发货申请修改",
        msg: messageUtils.msgError("发货申请修改失败")
      });
    } else{
      transmitModel.updateTransmitById(transmitId, params, function (err, result) {
        if(err){
          return res.render('transmit/update', {
            header: "配送管理 > 发货申请修改",
            msg: messageUtils.msgError("发货申请修改失败")
          });
        }else{
          var opt = {
            user_id:usr.id,
            url:nconf.get("url:transmit"),
            action:nconf.get("action:update"),
            operate_type:nconf.get("operate_type:transmit"),
            operate_id:transmitId,
            content: {departure: {old:req.body.old_departure,new:req.body.departure}, destination: {old:req.body.old_destination,new:req.body.destination}},
            state:1,
            client_address: commonUtils.getClientIp(req)
          };
          logsModel.addOperateLog(opt);
          req.session.rcode.msg = messageUtils.msgSuccess("发货申请修改成功");
          return res.redirect('/work_manage/production_transmit');
        }
      });
    }
  });
});

router.get('/updateSoldRecordStatus/:soldRecordId/:status', function(req, res, next) {
  var soldRecordId = req.params.soldRecordId;
  var params = {
    status: req.params.status
  };
  salesModel.updateSoldRecordStatus(params, soldRecordId, function (err, result) {
    if(err) {
      logger.info("修改失败");
    }else{
      logger.info("修改成功");
    }
    return res.send(result);
  });
});

router.get('/updateStatus/:transmitId/:status', function(req, res, next) {
  var transmitId = req.params.transmitId;
  var status =  req.params.status;
  if (status > 2 || status < 0) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    status: status
  };
  var name = status == "1" ? "发货" : "收货";
  transmitModel.updateTransmitById(transmitId, params, function (err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError(name+"失败");
      return res.redirect('/work_manage/production_transmit');
    }else{
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:transmit"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:transmit"),
        operate_id:transmitId,
        content:{status:name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess(name+"成功");
      return res.redirect('/work_manage/production_transmit');
    }
  });
});

router.get('/scan/record/:qrcode', function(req, res, next) {
  var transmitCode = req.params.qrcode;
  var layout = req.query["layout"];
  var corp_qrcode = req.query["corp_qrcode"];
  if(underscore.isNaN(transmitCode)){
    return next(new Error("Invalid transmit code"));
  }
  transmitModel.getScanRecordByCode(transmitCode, function(err,scanRecords){
    if(err){
      logger.error(err.stack);
      return next(err);
    }else{
      var params = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:transmit"),
        action: nconf.get("action:view"),
        operate_type: nconf.get("operate_type:transmit"),
        content: {transmit_qrcode:transmitCode},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(params);
      scanRecords && scanRecords.forEach(function(item) {
        item.scan_time_fmt = commonUtils.dateFormat(new Date(item.scan_time));
      });
      if(layout){
        return res.render('transmit/scan_index', {
          header: "配送管理 > 运单跟踪记录",
          layout: "partial/modal_layout",
          corp_qrcode:corp_qrcode,
          scanRecords:scanRecords
        });
      }else{
        return res.render('transmit/scan_index', {
          header: "配送管理 > 运单跟踪记录",
          scanRecords:scanRecords
        });
      }
    }
  });
});

router.get('/select_qrcode/:productionId/:status', function (req, res, next) {
  var productionId = req.params.productionId;
  var status =  req.params.status;
  if (underscore.isNaN(productionId) || status < 1 || status >3) {
    return next(new Error("Invalid Parameters"));
  }
  return res.render('transmit/select_qrcode', {
    header: "可用二维码查看",
    layout: "partial/modal_layout",
    status: status,
    productionId: productionId
  });
});

router.get('/select_qrcode/:productionId/:status/list', function (req, res, next) {
  var selected = req.query["selected"];
  var transmitId = req.query["transmitId"];
  var planId = req.query["planId"];
  var status = req.params.status;
  var user =  req.session.rcode.user;
  var proId = req.params.productionId;
  var tableParams = dataTableObj.getParams(req);
  tableParams.productionId = proId;
  tableParams.userId = user.id;
  tableParams.status = 1;
  async.waterfall([
    function(cb){
      if(status == 1) {
        qrcodeModel.getProPackageList(proId, function (err, packages) {
          cb(err, packages);
        });
      }else if(status == 2){
        transmitModel.getPlanRecordListByTransmitId(transmitId, function(err, rows){
          cb(err,rows);
        });
      }else if(status == 3){
        transmitModel.getPlanRecordListByPlanId(planId, function(err, rows){
          cb(err,rows);
        });
      }else{
        cb(null,null)
      }
    },
    function(unused, cb){
      if(status == 1) {
        transmitModel.getPlanRecordListByCorpId(user.corporation_id, function (err, rows) {
          cb(err, unused, rows);
        });
      }else if(status == 2) {//沿途分配
        transmitModel.getPlanRecordListByTransmitPlan(transmitId, function (err, rows){
          cb(err, unused, rows);
        });
      }else if(status == 3){
        transmitModel.getPlanRecordListByPlanTransmit(planId, function(err, rows){
          cb(err,unused,rows);
        });
      }else{
        cb(null,null,null);
      }
    }
  ], function (err, unused, used) {
    var tableData;
    if(!err){
      var obj = {};
      var obj1 = {};
      var start;
      var end;
      var key;
      var value;
      var last;

      //包装记录以 apply id分组整理成json
      unused && unused.forEach(function (item){
        if(item.production_id == proId) {
          if(status == 1){
            key = "apply_" + item.qrcode_apply_id;
            start = parseInt(item.qrcode_start_id);
            end = start+parseInt(item.package_count)-1;
          }else{
            key = "apply_" + item.apply_id;
            start = parseInt(item.qrcode_start);
            end = start+parseInt(item.sold_count)-1;
          }

          if(obj[key]){
            value = obj[key];
            last = value.pop();
            if(last.end === start - 1){
              start = last.start;
              end = end;
            }else{
              value.push(last);
            }
          }else{
            value = [];
          }
          value.push({start:start,end:end});
          obj[key] = value;
        }
      });

      //销售记录以 apply id分组整理成json
      used && used.forEach(function (item){
        if(item.production_id == proId) {
          key = "apply_" + item.apply_id;
          start = parseInt(item.qrcode_start);
          end = start + parseInt(item.sold_count) - 1;
          if(obj1[key]){
            value = obj1[key];
            last = value.pop();
            if(last.end === start - 1){
              start = last.start;
              end = end;
            }else{
              value.push(last);
            }
          }else{
            value = [];
          }
          value.push({start:start,end:end});
          obj1[key] = value;
        }
      });

      var pack;
      var sale;
      var arr = [];
      var apply_id;
      var qrcode_prefix;
      var start_code;
      var end_code;
      var corporation_qrcode = req.session.rcode.corporation.qrcode;
      //根据包装记录和销售记录，将已包装，未销售的二维码段查找出来

      for(key in obj){
        pack = obj[key];
        sale = obj1[key];
        apply_id = key.split("_")[1];
        qrcode_prefix = corporation_qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);
        if(sale){
          //销售的二维码记录
          var p_start;
          var p_end;
          var s_start;
          var s_end;
          //循环每一个包装段
          pack && pack.forEach(function(p){
            p_start = p.start;
            p_end = p.end;
            var last = p_start - 1;
            var saleFlag = false;
            //循环每一个销售段
            sale.forEach(function(s, i){
              s_start = s.start;
              s_end = s.end;

              if(p_start <= s_start  && s_end <= p_end){
                //包装段中间有销售
                saleFlag = true;
                if(s_start > p_start){
                  //包装起始码 - 销售起始码
                  start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
                  end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(s_start-1), 8) + ".3";
                  arr.push({start_code:start_code,end_code:end_code});
                }
                last = s_end;
              }

              //如果有销售记录，销售结束码 - 包装结束码
              if(i == sale.length - 1 && saleFlag && s_end < p_end){
                start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
                end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_end), 8) + ".3";
                arr.push({start_code:start_code,end_code:end_code});
              }
            });

            if(!saleFlag){
              //包装段中间没有销售
              start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_start), 8) + ".3";
              end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_end), 8) + ".3";
              arr.push({start_code:start_code,end_code:end_code});
            }
          });
        }else{
          //包装的二维码没有销售记录
          pack && pack.forEach(function(item){
            start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.start), 8) + ".3";
            end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.end), 8) + ".3";
            arr.push({start_code:start_code,end_code:end_code});
          });
        }
      }

      if(selected && selected != ""){
        selected = selected.split(",");
        selected.forEach(function(item){
          var apply_id = item.split(":")[1];
          var production = item.split(":")[0];
          var one = item.split(":")[2].split("-");
          arr.forEach(function(item, index) {
            var item_apply_id = item.start_code.split(".")[5];
            if (parseInt(item_apply_id) == parseInt(apply_id)) {
              qrcode_prefix = corporation_qrcode + "." + arr[index].end_code.split(".")[5];
              if (parseInt(item.start_code.split(".")[6]) < parseInt(one[0]) && parseInt(item.end_code.split(".")[6]) > parseInt(one[1])) {
                start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(one[1]) + 1, 8) + ".3";
                end_code = item.end_code;
                arr[index].end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(one[0]) - 1, 8) + ".3";
                arr.push({start_code: start_code, end_code: end_code})
              } else if (parseInt(item.start_code.split(".")[6]) == parseInt(one[0]) && parseInt(item.end_code.split(".")[6]) == parseInt(one[1])) {
                arr.splice(index, 1);
              } else if (parseInt(item.start_code.split(".")[6]) == parseInt(one[0])) {
                arr[index].start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(one[1]) + 1, 8) + ".3";
              } else if (parseInt(item.end_code.split(".")[6]) == parseInt(one[1])) {
                arr[index].end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(one[0]) - 1, 8) + ".3";
              }
            }
          });
        });
      }

      var data = arr.slice(tableParams.start,tableParams.start+tableParams.length);
      tableData = {aaData:data,iTotalRecords:arr.length,iTotalDisplayRecords:arr.length};
      return res.send(tableData);
    }else{
      tableData = {aaData:[],iTotalRecords:0,iTotalDisplayRecords:0};
      return res.send(tableData);
    }
  });
});

router.get('/plan/:transmitId',function(req, res, next){
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  var transmitId = req.params.transmitId;
  transmitModel.getTransmitById(transmitId, function(err, row){
    if(err){
      next("数据异常");
    }
    transmitModel.getPlanRecordListByTransmitPlan(transmitId, function(err, rows){
      if(err){
        next("数据异常");
      }
      var planList = [];
      rows && rows.forEach(function (item){
          planList.push({
            destination: item.destination,
            sold_records: item.production_id+":"+item.apply_id+":"+commonUtils.padZero(item.qrcode_start, 8)+"-"+commonUtils.padZero((item.qrcode_start+item.sold_count-1), 8)
          });
      });
      res.render('transmit/plan', {
        header: "配送管理 > 下货",
        creator:usr.id,
        corpcode:corp.qrcode,
        planList:planList,
        transmit:row
      });
    });
  });
});

router.post('/plan/:transmitId',function(req, res, next){
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  var transmitId = req.params.transmitId;
  var transmit_qrcode = req.body.transmit_qrcode;
  if(req.body.sold_records_selected && req.body.sold_records_selected.length != 0) {
    var sold_record1 = req.body.sold_records_selected.split(",");
    var sold_record2 = {};
    var values = [];
    sold_record1 && sold_record1.forEach(function (item) {
      if (sold_record2[item.split(";")[1]]) {
        sold_record2[item.split(";")[1]] = sold_record2[item.split(";")[1]] + "," + item.split(";")[0];
      } else {
        sold_record2[item.split(";")[1]] = item.split(";")[0];
      }
    });
    for (var key in sold_record2) {
      values.push({destination:key,sold_records:sold_record2[key]});
    }
    async.eachSeries(values, function(item, cb){
      var record_list = [];
      var record_str;
      var params = {
        transmit_id: transmitId,
        destination: item.destination,
        sold_records: null,
        creator: usr.id,
        client_address: commonUtils.getClientIp(req)
      };
      transmitModel.addTransmitPlan(params, function (err, planId) {
        if (err) {
          cb(err);
        }
        item.sold_records.split(",").forEach(function (item) {
          var start = parseInt(item.split(":")[2].split("-")[0]);
          var end = parseInt(item.split(":")[2].split("-")[1]);
          var count = end - start + 1;
          record_list.push("(null,"+planId+","+parseInt(item.split(":")[0])+","+parseInt(item.split(":")[1])+",'"+start+"',"+count+")");
        })
        record_str = record_list.join(",");
        transmitModel.addSoldRecord(record_str,function (err, planRecordId) {
          if (err) {
            cb(err);
          }
          params = {
            "transmit_qrcode": transmit_qrcode,
            "scan_action": 1,
            "scan_user":usr.id,
            "scan_latlng": null,
            scan_location: item.destination,
            plan_id: planId
          };
          transmitModel.newScanRecord(params, function (err, scanRecord){
            if(err){
              cb(err);
            }
            cb();
          });
        });
      });
    },function(err){
        if(err){
          return res.render('transmit', {
            header: "配送管理",
            msg: messageUtils.msgError("保存失败")
          });
        }
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:transmit"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:transmit"),
        operate_id: transmitId,
        content: {destination: req.body.destination},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("保存成功");
      return res.redirect('/work_manage/production_transmit');
    });
  }else{
    req.session.rcode.msg = messageUtils.msgSuccess("保存成功");
    return res.redirect('/work_manage/production_transmit');
  }
});

router.get('/branch/:transmitId',function(req, res, next){
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  var transmitId = req.params.transmitId;
  res.render('transmit/branch', {
    header: "配送管理 > 子配送申请",
    transmitId:transmitId,
    creator:usr.id,
    corpcode:corp.qrcode
  });
});

router.post('/branch/:transmitId',function(req, res, next){
  var usr = req.session.rcode.user;
  var corp = req.session.rcode.corporation;
  var transmitId = req.params.transmitId;
  var creator = req.body.creator;
  var planId = req.body.planId;
  var sold_records = req.body.sold_records_selected;
  var record_list = [];
  var values;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  //对sold_secords进行合并

  var params = {
    creator:creator,
    sender: req.body.sender,
    sender_phone: req.body.sender_phone,
    departure: (req.body.departure).split(";")[1],
    destination: req.body.destination,
    receiver: req.body.receiver,
    receiver_phone: req.body.receiver_phone,
    sold_records: null,
    plan_id: planId,
    status: transmitModel.TRANSMIT_QRCODE_STATUS.no_send,
    client_address: commonUtils.getClientIp(req)
  };
  params.transmit_qrcode = QRcode.getTransmitCodeBySerial(commonUtils.date2Long(new Date()), sold_records, params.creator, corp.qrcode);

  var corp = req.session.rcode.corporation;

  transmitModel.newRecord(params, function (err, transmitId) {
    if (err) {
      return res.render('transmit/branch', {
        header: "配送管理 > 子配送申请",
        msg: messageUtils.msgError("配送申请失败")
      });
    } else {
      sold_records.split(",").forEach(function (item) {
       //(`transmit_id`,`plan_id`,`production_id`,`apply_id`,`qrcode_start`,`sold_count` )
       var start = parseInt(item.split(":")[2].split("-")[0]);
       var end = parseInt(item.split(":")[2].split("-")[1]);
       var count = end - start + 1;
       record_list.push("("+transmitId+",null,"+parseInt(item.split(":")[0])+","+parseInt(item.split(":")[1])+",'"+start+"',"+count+")");
       });
      values = record_list.join(",");
      transmitModel.addSoldRecord(values,function (err, planRecordId) {
        if (err) {
          return res.render('transmit/add', {
            header: "配送管理 > 发货申请",
            msg: messageUtils.msgError("发货申请失败")
          });
        }
        var opt = {
          user_id: usr.id,
          url: nconf.get("url:transmit"),
          action: nconf.get("action:add"),
          operate_type: nconf.get("operate_type:transmit"),
          operate_id: transmitId,
          content: {departure: req.body.departure, destination: req.body.destination},
          state: 1,
          client_address: commonUtils.getClientIp(req)
        };
        logsModel.addOperateLog(opt);
        req.session.rcode.msg = messageUtils.msgSuccess("发货申请成功");
        return res.redirect('/work_manage/production_transmit');
      });
    }
  });
});

router.get('/destination/:transmitId',function (req, res, next){
  var transmitId = req.params.transmitId;
  transmitModel.getTransmitPlanByTransmitId(transmitId ,function(err, rows){
    if(err){
      next("数据异常");
    }else{
      return  res.send(rows);
    }
  })
});

router.get('/view/record/:recordId', function(req, res, next) {
  var recordId = req.params.recordId;
  var corp = req.session.rcode.corporation;
  var corp_qrcode = req.query['corp_qrcode'];
  var action = req.query['action'];
  var corporation_qrcode;

  if(corp_qrcode){
    corporation_qrcode = corp_qrcode;
  }else{
    corporation_qrcode = corp.qrcode;
  }
  transmitModel.getPlanRecordListByTransmitRecordId(recordId, action, function(err, rows){
    var records = [];
    var production_id = 0;
    rows && rows.forEach(function(item){
      var qrcode_prefix = corporation_qrcode + "." + commonUtils.padZero(parseInt(item.apply_id), 8);
      var start = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.qrcode_start), 8) + ".3";
      var end = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.qrcode_start)+item.sold_count, 8) + ".3";
      if(item.production_id == production_id){
        records.push({start:start,end:end});
      }else{
        records.push({production_name:item.production_name,start:start,end:end});
        production_id = item.production_id;
      }
    })
    res.render('transmit/record_view', {
      header: "配送管理 > 运单跟踪记录 > 查看二维码",
      records:records,
      layout: "partial/modal_layout",
      action:action == "0" ? "上车" : "下车"
    });
  });
});
module.exports = router;
