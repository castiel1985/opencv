$ sudo hg init /var/hg/testrepo
