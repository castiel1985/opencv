"use strict";
var express = require('express');
var router = express.Router();
var codeModel = require('../models/qrcodeModel');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var commonUtils = require('../utils/Common');
var childProcess = require('child_process');
var path = require('path');
var logger = require('../utils/winstonUtils').logger;
var fs = require('fs');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');


router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  var usr = req.session.rcode.user;
  var params = {
    user_id:usr.id,
    url:nconf.get("url:qrcode_approve"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:qrcode"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  return res.render('qrcode_approve', {
    header: "二维码申请审批"
  });

});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.corpId = usr.corporation_id;
  tableParams.status = 0;
  codeModel.getApproveList(usr,tableParams, function(tableData) {
    messageUtils.getSessionMsg(req, res);
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.apply_time = commonUtils.dateFormat(new Date(item.create_time));
      item.generate_count = item.generate_count || 0;
    });
    return res.send(tableData);
  });
});


router.get('/:apply_id/:status/:generate', function(req, res, next) {
  var applyId = req.params.apply_id;
  var status = req.params.status;
  var generate = req.params.generate;
  if(underscore.isNaN(applyId) && underscore.isNaN(status) && underscore.isNaN(generate)){
    return next(new Error("Invalid applyId or status"));
  }

  //var corp = req.session.rcode.corporation;
  var usr = req.session.rcode.user;
  var params = {
    generate_count:generate,
    approve_user_id:usr.id,
    status:status,
    id:applyId
  };

  if(status == 2){
    var start = req.query["start"];
    var corpId = req.query["corp_id"];
    var qrcode = req.query["qrcode"];

    var child_process = childProcess.fork([path.join(__dirname, "../middleware/insertProductionCode.js")], [corpId, qrcode, applyId, start, generate, 3], {
      detached: true
    });

    child_process.on('error', function (data) {
      logger.error('error: ' + data);
    });
    child_process.on("message", function(m){
      logger.info(m);
      child_process.kill();
    });
  }

  var action;
  if(status == 2){
    action = nconf.get("action:approve");
  }else{
    action = nconf.get("action:approve_refuse");
  }

  codeModel.geApplyById(applyId, function(err, apply){
    var opt = {
      user_id:usr.id,
      url:nconf.get("url:qrcode_approve"),
      action:action,
      operate_type:nconf.get("operate_type:qrcode"),
      operate_id:applyId,
      content:{apply_count:generate},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
  });

  codeModel.approveCode(params, function(err){
    if (err) {
      return next(err);
    }
    req.session.rcode.msg = messageUtils.msgSuccess("审批成功");
    return res.redirect('/qrcode/approve');
  });
});





module.exports = router;