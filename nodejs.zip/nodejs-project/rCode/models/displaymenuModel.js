"use strict";
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;

function getDisplayMenuListByCorpId( tableParams, callback){
  var sqlData = "SELECT a.* FROM qr_displaymenu a,qr_corporation b WHERE b.id = a.corporation_id and corporation_id = :corpId and a.state =:state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_displaymenu a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and a.name like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_displaymenu a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId and a.state =:state and a.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlData = sqlData + " order by a.weight desc ";
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getDisplayMenuById( displaymenuId, callback){
  database.query({
    sql: "SELECT * FROM qr_displaymenu " +
    " WHERE id =:id and state = 1",
    params: {
      "id": displaymenuId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function updateDisplayMenuById( params, callback){
  database.query({
    sql: "UPDATE qr_displaymenu SET `name`=:name  " +
    " WHERE id =:id",
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function addDisplayMenu( params, callback){
  var sql = 'INSERT INTO qr_displaymenu (' +
    '`corporation_id`,' +
    '`name`,' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(' +
    ':corporation_id,'+
    ':name,'+
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"),null);
    }
    var displaymenuId = result.insertId;
    logger.info("added qr_displaymenu  id = %d", displaymenuId);
    return callback(null, displaymenuId);
  });
}

function deletDisplayMenu(id, callback) {
  database.query({
    sql: "UPDATE qr_displaymenu SET state = 0 WHERE id =:id",
    params: {
      "id": id
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

function getNewsListByDisplayMenuId( tableParams, callback){

  var sqlData = "SELECT a.*,b.name FROM qr_displaymenu_news a,qr_user b,qr_corporation c " +
    " WHERE a.displaymenu_id =:displaymenuId and b.id = a.creator and c.id = b.corporation_id and b.corporation_id = :corpId and a.state =:state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_displaymenu_news a,qr_user b,qr_corporation c WHERE a.displaymenu_id =:displaymenuId and b.id = a.creator and c.id = b.corporation_id and b.corporation_id = :corpId and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and a.title like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_displaymenu_news a,qr_user b,qr_corporation c WHERE a.displaymenu_id =:displaymenuId and b.id = a.creator and c.id = b.corporation_id and b.corporation_id = :corpId and a.state =:state and a.title like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlData = sqlData + " order by status desc ";
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getNewsById( newsId, callback){
  database.query({
    sql: "SELECT * FROM qr_displaymenu_news " +
    " WHERE id =:id and state = 1",
    params: {
      "id": newsId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function updateNewsById(newsId, params, callback){
  var sql_head = "UPDATE qr_displaymenu_news SET ";
  var colums = [];
  for(var key in params){
    colums.push("`"+key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + newsId;
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function addNews( params, callback){
  var sql = 'INSERT INTO qr_displaymenu_news (' +
    '`displaymenu_id`,' +
    '`title`,' +
    '`news`,' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(' +
    ':displaymenu_id,'+
    ':title,'+
    ':news,'+
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"),null);
    }
    var newsId = result.insertId;
    logger.info("added qr_displaymenu_news  id = %d", newsId);
    return callback(null, newsId);
  });
}

function deletNews( newsId, callback){
  database.query({
    sql: "UPDATE qr_displaymenu_news SET state = 0 WHERE id =:id",
    params: {
      "id": newsId
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

exports.deletNews = deletNews;
exports.addNews = addNews;
exports.updateNewsById = updateNewsById;
exports.getNewsById = getNewsById;
exports.getNewsListByDisplayMenuId = getNewsListByDisplayMenuId;
exports.deletDisplayMenu = deletDisplayMenu;
exports.addDisplayMenu = addDisplayMenu;
exports.updateDisplayMenuById = updateDisplayMenuById;
exports.getDisplayMenuById = getDisplayMenuById;
exports.getDisplayMenuListByCorpId = getDisplayMenuListByCorpId;