$ sudo apt-get install -y redmine redmine-mysql
