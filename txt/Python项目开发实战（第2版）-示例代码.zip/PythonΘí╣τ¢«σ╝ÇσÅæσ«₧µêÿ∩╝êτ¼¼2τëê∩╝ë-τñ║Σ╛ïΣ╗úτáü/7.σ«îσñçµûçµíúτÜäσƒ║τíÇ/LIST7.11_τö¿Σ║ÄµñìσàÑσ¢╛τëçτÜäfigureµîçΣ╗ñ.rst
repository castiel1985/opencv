方便多人同时编辑，也便于用版本管理工具进行管理。

.. figure:: images/7-sphinx-vcs-manage.png

   用Mercurial管理Sphinx文档
