"use strict";
/**
 * Created by Alen on 15/3/30.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var http = require("http");
var async = require('async');

function updateFilesState(params, fileIds, callback) {
  var update = "UPDATE qr_file SET `state`=:state WHERE id in (" + fileIds + ")";
  database.query({
    sql: update,
    params: params
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, result);
  });
}

function getRegionList(callback){
  database.query({
    sql: "SELECT * FROM qr_region"
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getRegionNameByCode(code,callback){
  database.query({
    sql: "SELECT * FROM qr_region WHERE code = CONCAT(SUBSTRING(:code,1,2),'0000') || code = CONCAT(SUBSTRING(:code,1,4),'00') || code = :code",
    params:{code:code}
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function insertFiles(opts, callback) {
  var insert = "insert into qr_file (name,url,`type`,mime,creator,`state`) values (:filename,:url,:type,:mimetype,:creator,1)";
  database.query({
    sql: insert,
    params: opts
  }, null);
}

function getSiteByLatlng(lng,lat, callback){
  var url = "http://api.map.baidu.com/geocoder/v2/?ak=Ev7Gna956MuEgzgKGMorszpG&location="+ lat + "," + lng +"&output=json&pois=1";
  var request_get = http.get(url, function(res) {
    var dataArr = [], len = 0;
    res.on('data', function(chunk) {
      dataArr.push(chunk);
      len += chunk.length;
    });

    res.on('end', function() {
      var buff = Buffer.concat(dataArr, len);
      var json = JSON.parse(buff);
      logger.info(json);
      var address = json.result.formatted_address;
      return callback(null, address);
    });
  });
  request_get.on('error', function(e) {
    logger.error("error " + e.stack);
    return callback(e, null);
  });
  request_get.end();
}

function queryTableDatas(sqlArr, tableParams, callback){
  var results = [];
  var tableData = {
    draw:tableParams.draw || 1,
    aaData:[],
    iTotalRecords:0,
    iTotalDisplayRecords:0
  };
  async.eachSeries(sqlArr, function (item, cb){
    database.query({
      sql: item,
      params: tableParams
    }, function(err, result) {
      if (err) {
        logger.error(err);
        cb(new global.ServerError("Can't connect MySQL"), null);
      }else{
        results.push(result);
        cb(null, result);
      }
    });
  },function(err){
    if(err){
      logger.error(err);
      return callback(err,tableData);
    }
    if(results.length > 0){
      tableData.aaData = results[0];
      if(results.length > 1){
        tableData.iTotalRecords = results[1][0].iTotalRecords;
        if(results.length > 2){
          tableData.iTotalDisplayRecords = results[2][0].iTotalDisplayRecords;
        }else{
          tableData.iTotalDisplayRecords = tableData.iTotalRecords;
        }
      }
    }
    return callback(null,tableData);
  });

}

exports.updateFilesState = updateFilesState;
exports.getRegionList = getRegionList;
exports.getRegionNameByCode = getRegionNameByCode;
exports.insertFiles = insertFiles;
exports.getSiteByLatlng = getSiteByLatlng;
exports.queryTableDatas = queryTableDatas;
