$ python datetime_dateutil_1.py
2012-02-29
