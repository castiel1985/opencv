"use strict";
var express = require('express');
var router = express.Router();



router.get('/wap', function(req, res, next) {


  res.render('template/wap', {
    header: "宣传模版设置"

  });

});


module.exports = router;