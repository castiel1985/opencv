"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;

function getProductionListByBrandId(brandId, callback) {
  database.query({
    sql: "SELECT * FROM qr_production" +
    " WHERE brand_id=:brandId and state = 1",
    params: {
      "brandId": brandId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getProductionList(tableParams, callback) {
  var sqlData;
  var sqlCount;
  var user = tableParams.user;
  if (user && user.isCorp) {
    sqlData = "SELECT a.* FROM qr_production a,qr_user b WHERE b.id = a.creator AND b.corporation_id = :corpId AND a.state =:state ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production a,qr_user b WHERE b.id = a.creator AND b.corporation_id = :corpId AND a.state =:state ";
  } else {
    sqlData = "SELECT a.*,b.name as brand_name,c.name as category_name FROM qr_production a, qr_brand b,qr_industry c,qr_user d, qr_corporation e  WHERE a.creator = d.id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) and a.brand_id=b.id and a.category=c.code and a.state = :state ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production a, qr_brand b,qr_industry c,qr_user d, qr_corporation e  WHERE a.creator = d.id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) and a.brand_id=b.id and a.category=c.code and a.state = :state ";
  }

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = "";
  var pagFlag = true; //是否分页
  if (tableParams.orderName == "brand_name") {
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  } else if (tableParams.orderName == "category_name") {
    orderStr = " ORDER BY c.name " + tableParams.orderDir;
  } else {
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if (tableParams.search) {
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND (a.name like :search OR a.short_name like :search) " + orderStr + " limit :start,:length";

    if (user && user.isCorp) {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production a,qr_user b WHERE b.id = a.creator AND b.corporation_id = :corpId AND a.state =:state AND (a.name like :search OR a.short_name like :search) ";
    } else {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production a, qr_brand b,qr_industry c,qr_user d, qr_corporation e  WHERE a.creator = d.id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) and a.brand_id=b.id and a.category=c.code and a.state = :state AND (a.name like :search OR a.short_name like :search) ";
    }
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  } else if (tableParams.length) {
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  } else {
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function (err, tableData) {
    if (err) {
      logger.error(err);
    }
    if (pagFlag) {
      callback(tableData);
    } else {
      callback(err, tableData.aaData);
    }
  });
}


function addProduction(options, callback) {
  var sql = 'INSERT INTO qr_production (`name`,' +
    ' `brand_id`, ' +
    ' `parent_id`, ' +
    '`category` ,' +
    '`short_name` ,' +
    '`pinyin` ,' +
    '`clazz` ,' +
    '`standard` ,' +
    '`unit` ,' +
    '`count` ,' +
    '`identity`, ' +
    '`status`, ' +
    'expired_date, ' +
    '`attribute`, ' +
    '`desc`, ' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:name,' +
    ':brand_id, ' +
    ':parent_id, ' +
    ':category,' +
    ':short_name,' +
    ':pinyin,' +
    ':clazz,' +
    ':standard,' +
    ':unit,' +
    ':count,' +
    ':identity, ' +
    ':status, ' +
    ':expired_date, ' +
    ':attribute, ' +
    ':desc,' +
    ':creator,' +
    'true,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function (err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var productionId = result.insertId;
    logger.info("added production id = %d", productionId);

    if (options.files) {
      options.files.forEach(function (item) {
        //insetrt to file
        item.creator = options.creator;
        item.type = 'production_' + productionId;
        commonModel.insertFiles(item, null);
      });
    }
    return callback(null, productionId);
  });

}


function getProductionById(productionId, callback) {
  database.query({
    sql: "SELECT a.*,b.name as brand_name,c.name as category_name,d.name as parent_name FROM qr_production a LEFT JOIN qr_production d on a.parent_id = d.id, qr_brand b,qr_industry c " +
    " WHERE a.id =:productionId and a.brand_id=b.id and a.category=c.code and a.state = 1",
    params: {
      "productionId": productionId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:type and state=:state",
        params: {
          type: "production_" + productionId,
          state: 1
        }
      }, function (err, rows2) {
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.files = rows2;
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }
  });
}

function getProductionBaseList(tableParams, callback) {
  var sqlData;
  var sqlCount;
  var user = tableParams.user;
  if (user && user.isCorp) {
    sqlData = "SELECT a.* FROM qr_production_base a, qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state=:state ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production_base a, qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state=:state ";
  } else {
    sqlData = "SELECT a.* FROM qr_production_base a, qr_user b, qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state=:state";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production_base a, qr_user b, qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state=:state ";
  }

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr;
  var pagFlag = true; //是否分页
  if (tableParams.orderName == "qrcode") {
    orderStr = " ORDER BY a.id " + tableParams.orderDir;
  } else {
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if (tableParams.search) {
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr + " limit :start,:length";
    if (user && user.isCorp) {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production_base a, qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state=:state AND a.name like :search ";
    } else {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production_base a, qr_user b, qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state=:state AND a.name like :search ";
    }

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  } else if (tableParams.length) {
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  } else {
    pagFlag = false;
    sqlArr.push(sqlData);
  }

  commonModel.queryTableDatas(sqlArr, tableParams, function (err, tableData) {
    if (err) {
      logger.error(err);
    }
    if (pagFlag) {
      callback(tableData);
    } else {
      callback(tableData.aaData);
    }
  });
}


function addProductionBase(options, callback) {
  var sql = 'INSERT INTO qr_production_base (`name`,' +
    '`desc`, ' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:name,' +
    ':desc,' +
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function (err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var baseId = result.insertId;
    logger.info("added production base id = %d", baseId);
    return callback(null, baseId);
  });

}


function getProductionManufactureList(tableParams, callback) {
  var type = tableParams.type;
  var sql1 = type ? " AND a.type=:type" : "";
  var sqlData;
  var sqlCount;
  if(tableParams.manuIds){
    sql1 += " AND a.id IN (" + tableParams.manuIds + ") ";
  }
  var user = tableParams.user;
  if (user && user.isCorp) {
    sqlData = "SELECT a.* FROM qr_manufacture a,qr_user b WHERE a.creator=b.id AND a.state=:state AND b.corporation_id = :corpId " + sql1;
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_manufacture a,qr_user b WHERE a.creator=b.id AND a.state=:state AND b.corporation_id = :corpId " + sql1;
  } else {
    sqlData = "SELECT a.* FROM qr_manufacture a,qr_user b,qr_corporation c WHERE a.creator=b.id AND a.state=:state AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) " + sql1;
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_manufacture a,qr_user b,qr_corporation c WHERE a.creator=b.id AND a.state=:state AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) " + sql1;
  }

  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if (tableParams.search) {
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr + " limit :start,:length";
    if (user && user.isCorp) {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_manufacture a,qr_user b WHERE a.creator=b.id AND a.state=:state AND b.corporation_id = :corpId AND a.name like :search " + sql1;
    } else {
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_manufacture a,qr_user b,qr_corporation c WHERE a.creator=b.id AND a.state=:state AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.name like :search " + sql1;
    }
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  } else if (tableParams.length) {
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  } else {
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function (err, tableData) {
    if (err) {
      logger.error(err);
    }
    if (pagFlag) {
      callback(tableData);
    } else {
      callback(err, tableData.aaData);
    }
  });
}


function addProductionManufacture(options, callback) {
  var sql = 'INSERT INTO qr_manufacture (`name`,' +
    '`type`, ' +
    '`sort`, ' +
    '`creator`, ' +
    '`corporation_id`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:name,' +
    ':type,' +
    ':sort,' +
    ':creator,' +
    ':corporation_id,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function (err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var proManuId = result.insertId;

    if (options.pictureFiles) {
      options.pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = options.creator;
        item.type = 'production_manu_picture_' + proManuId;
        commonModel.insertFiles(item, null);
      });
    }
    return callback(null, proManuId);
  });

}

function getIndustryList(callback) {
  database.query({
    sql: "SELECT * FROM qr_industry WHERE state=:state",
    params: {
      "state": 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getProductionBaseQrcode(productionBaseId, callback) {
  var sql = "select qp.id,qp.name,b.qrcode from qr_production_base qp,qr_base_code b where " +
    "qp.id=:productionBaseId and b.type=1 and b.production_base_id=:productionBaseId and b.state=:state and qp.state=:state";
  database.query({
    sql: sql,
    params: {
      productionBaseId: productionBaseId,
      state: 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

function getProductionManuQrcodeList(productionBaseId, callback) {
  var sql = "select qm.id,qm.name,b.qrcode from qr_manufacture qm,qr_base_code b where b.type=2 " +
    "and b.production_base_id=:productionBaseId and b.manufacture_id = qm.id and b.state=:state and qm.state=:state";
  database.query({
    sql: sql,
    params: {
      productionBaseId: productionBaseId,
      state: 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function updateProduction(params, callback) {
  var sql = 'UPDATE qr_production SET ' +
    '`name` =:name,' +
    ' `brand_id` =:brand_id, ' +
    ' `parent_id` =:parent_id, ' +
    '`category`  =:category,' +
    '`short_name`  =:short_name,' +
    '`pinyin`  =:pinyin,' +
    '`clazz`  =:clazz,' +
    '`standard`  =:standard,' +
    '`unit`  =:unit,' +
    '`count`  =:count,' +
    '`identity` =:identity, ' +
    '`status` =:status, ' +
    'expired_date =:expired_date, ' +
    '`attribute` =:attribute, ' +
    '`desc` =:desc, ' +
    '`creator` =:creator ' +
    'where id =:id';
  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    } else {
      var id = params.id;
      if (params.pictureFiles) {
        params.pictureFiles.forEach(function (item) {
          //insetrt to file
          item.creator = params.creator;
          item.type = 'production_' + id;
          commonModel.insertFiles(item, null);
        });
      }
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

function delProductionManuById(proManuId, callback) {
  var update = "UPDATE qr_manufacture SET `state`=0 WHERE id = :proManuId";
  var params = {
    proManuId: proManuId
  };
  database.query({
    sql: update,
    params: params
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, result);
  });
}

function getProductionManuById(proManuId, callback) {
  database.query({
    sql: "SELECT * FROM qr_manufacture WHERE id = :proManuId",
    params: {
      "proManuId": proManuId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:pictureType AND state=1",
        params: {
          "pictureType": "production_manu_picture_" + proManuId
        }
      }, function (err, rows2) {
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = rows2;
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }
  });
}

function updateProductionManu(params, proManuId, callback) {
  var pictureFiles = params.pictureFiles;
  var creator = params.creator;
  delete params.pictureFiles;
  delete params.creator;
  var sql_head = "UPDATE qr_manufacture SET ";
  var colums = [];
  for (var key in params) {
    colums.push("`" + key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + proManuId;

  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (pictureFiles) {
      pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = creator;
        item.type = 'production_manu_picture_' + proManuId;
        commonModel.insertFiles(item, null);
      });
    }
    if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}

function delProductionBaseById(productionBaseId, callback) {
  var update = "UPDATE qr_production_base SET `state`=0 WHERE id = :productionBaseId";
  var params = {
    productionBaseId: productionBaseId
  };
  database.query({
    sql: update,
    params: params
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, result);
  });
}

function getProductionBaseById(productionBaseId, callback) {
  database.query({
    sql: "SELECT * FROM qr_production_base WHERE id = :productionBaseId",
    params: {
      "productionBaseId": productionBaseId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      return callback(null, row);
    } else {
      return callback(null, null);
    }
  });
}

function updateProductionBase(params, productionBaseId, callback) {
  var sql_head = "UPDATE qr_production_base SET ";
  var colums = [];
  for (var key in params) {
    colums.push("`" + key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + productionBaseId;
  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    } else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}

function delProduction(productionId, callback) {
  database.query({
    sql: "UPDATE qr_production SET state = 0 WHERE id =:id",
    params: {
      "id": productionId
    }
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    } else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }
  });
}

function getProductionByCode(qrcode, callback) {
  var sql = "select a.* from qr_production a,qr_package b where (:qrcode >= b.qrcode_start_id) and (:qrcode < (b.qrcode_start_id+b.package_count)) and b.qrcode_apply_id =:qrcode_apply_id  and b.production_id = a.id";
  database.query({
    sql: sql,
    params: {
      "qrcode": parseInt(qrcode.substr(-10, 8)),
      "qrcode_apply_id": parseInt(qrcode.substr(-19, 8))
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

function getCorpMaxSort(corpId, callback) {
  var sql = "SELECT ifnull(MAX(sort),0)+1 AS sort_num FROM `qr_manufacture` where corporation_id = :corpId AND state = :state";
  database.query({
    sql: sql,
    params: {corpId: corpId, state: 1}
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    } else {
      return callback(null, result[0]);
    }
  });
}

function queryCorpSort(corpId, sort, callback) {
  var sql = "SELECT * FROM `qr_manufacture` where corporation_id = :corpId AND sort = :sort AND state = :state";
  database.query({
    sql: sql,
    params: {corpId: corpId, sort: sort, state: 1}
  }, function (err, rows) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

function getProManuListByCorpId(corpId, callback) {
  var sql = "SELECT a.*, GROUP_CONCAT(b.url) AS url FROM qr_manufacture a LEFT JOIN qr_file b ON b.type= CONCAT('production_manu_picture_',a.id) WHERE a.corporation_id = :corpId AND a.state = :state AND b.state = :state GROUP BY a.id";
  database.query({
    sql: sql,
    params: {
      corpId: corpId,
      state: 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

exports.delProduction = delProduction;
exports.updateProduction = updateProduction;
exports.addProduction = addProduction;
exports.getProductionList = getProductionList;
exports.getProductionById = getProductionById;
exports.getProductionBaseList = getProductionBaseList;
exports.addProductionBase = addProductionBase;
exports.getProductionManufactureList = getProductionManufactureList;
exports.addProductionManufacture = addProductionManufacture;
exports.getIndustryList = getIndustryList;
exports.getProductionBaseQrcode = getProductionBaseQrcode;
exports.getProductionManuQrcodeList = getProductionManuQrcodeList;
exports.delProductionManuById = delProductionManuById;
exports.getProductionManuById = getProductionManuById;
exports.updateProductionManu = updateProductionManu;
exports.delProductionBaseById = delProductionBaseById;
exports.getProductionBaseById = getProductionBaseById;
exports.updateProductionBase = updateProductionBase;
exports.getProductionListByBrandId = getProductionListByBrandId;
exports.getProductionByCode = getProductionByCode;
exports.getCorpMaxSort = getCorpMaxSort;
exports.queryCorpSort = queryCorpSort;
exports.getProManuListByCorpId = getProManuListByCorpId;
