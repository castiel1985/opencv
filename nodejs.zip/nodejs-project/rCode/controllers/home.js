"use strict";
var express = require('express');
var router = express.Router();
var messageUtils = require('../utils/Message');
var corpModel = require('../models/corpModel');
var logger = require('../utils/winstonUtils').logger;

var roles = ["admin","corp","supervisor","dealers"];

/* HOME page. */
router.get('/', function(req, res, next) {

  var usr = req.session.rcode.user;
  messageUtils.getSessionMsg(req, res);
  return res.render('home', {
    header: "主页"
  });
});

module.exports = router;