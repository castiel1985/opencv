"use strict";

var express = require('express');
var router = express.Router();
var commonUtil = require('../utils/Common.js');
var userModel = require('../models/userModel');
var passwordHash = require('../utils/Password');
var validator = require('validator');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var corpModel = require('../models/corpModel');
var nconf = require('nconf');

router.get('/logout', function(req,res,next) {
  var usr = req.session.rcode.user;
  req.session.rcode = {};
  req.session.destroy();
  return res.redirect("/");
});


/**
 * Login
 */
router.post('/login', function(req, res, next) {

  var username = req.body.username;
  var password = req.body.password;
  if (commonUtil.usernameCheck(username) && commonUtil.usernameCheck(password)) {
    //check db;
    userModel.getUserRoleByName({
      username: username
    }, function(err, userInfo) {
      if (err) {
        logger.error(err.message);
        return next(err);
      }
      if (userInfo == null) {
        logger.error("没有查询到用户");
        return res.redirect("/?code=UNKNOWN_USER");
      }
      if (userInfo.status != 1) {
        logger.error("该用户未审批");
        return res.redirect("/?code=NOT_APPROVE");
      }
      if (userInfo.client == 1) {
        logger.error("该用户只能在app端登录");
        return res.redirect("/?code=APP_CLIENT");
      }
      //verify user's password
      if(passwordHash.verify(password,[passwordHash.algorithm,userInfo.salt,passwordHash.iterations,userInfo.passwd].join('$'))){

        var user = {
          "id": userInfo.id,
          "name": userInfo.name,
          "username":userInfo.username,
          "mail": userInfo.mail,
          "corporation_id":userInfo.corporation_id,
          "mobile_phone": userInfo.mobile_phone,
          "passwd": password,
          "isAdmin": userInfo.identity === 'admin',
          "isCorpAdmin":  userInfo.identity === 'corp-admin',
          "isCorp": userInfo.identity === 'corp',
          "isSupervisor": userInfo.identity === 'supervisor'
        };

        req.session.rcode = {};
        req.session.rcode.user = user;

        var opt = {
          user_id:user.id,
          url:nconf.get("url:member"),
          action:nconf.get("action:login"),
          operate_type:nconf.get("operate_type:member"),
          content:{username:username},
          state:1,
          client_address: commonUtil.getClientIp(req)
        };
        logsModel.addOperateLog(opt);

        corpModel.getCorpById(user.corporation_id, function(err, row) {
          if (err) {
            return next(err);
          }
          req.session.rcode.corporation = row;

          if(user.isAdmin || user.isSupervisor){

            return res.redirect("/system/user_manage");
          }else{
            if(user.isCorpAdmin){
              return res.redirect("/home");
            }else if(user.isCorp) {
              return res.redirect("/work_manage/serials_manage");
            }
          }
        });

      }else{
        return res.redirect("/?code=INVALID_USER");
      }
    });

  } else {
    return res.render("/", {
      msg: "用户名或者密码不存在"
    });
  }

});



router.get('/table_i18n',function(req,res,next){
  res.send({
    "bAutoWidth": true,
    "sProcessing":   "处理中...",
    "sLengthMenu":   "显示 _MENU_ 项结果",
    "sZeroRecords":  "没有匹配结果",
    "sInfo":         "显示第 _START_ 至 _END_ 项结果，共 _TOTAL_ 项",
    "sInfoEmpty":    "显示第 0 至 0 项结果，共 0 项",
    "sInfoFiltered": "(由 _MAX_ 项结果过滤)",
    "sInfoPostFix":  "",
    "sUrl":          "",
    "sEmptyTable":     "未查询到数据",
    "sLoadingRecords": "载入中...",
    "sInfoThousands":  ",",
    "oPaginate": {
      "sFirst":    "首页",
      "sPrevious": "上页",
      "sNext":     "下页",
      "sLast":     "末页"
    },
    "oAria": {
      "sSortAscending":  ": 以升序排列此列",
      "sSortDescending": ": 以降序排列此列"
    }
  });
});

module.exports = router;