"use strict";
var express = require('express');
var router = express.Router();
var corpModel = require('../models/corpModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var async = require("async");
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/update', function(req, res, next) {

  var usr = req.session.rcode.user;

  corpModel.getCorpById(usr.corporation_id, function(err, row) {
    if (err) {
      return next(err);
    }

    messageUtils.getSessionMsg(req, res);
    return res.render('corporation/update', {
      header: "本企业信息",
      corporation: row,
      user:usr
    });
  });
});


router.post('/update', function(req, res, next) {

  var usr = req.session.rcode.user;

  var params = {
    anti_fake: req.body.anti_fake,
    contact: req.body.contact,
    telephone: req.body.telephone,
    email: req.body.email,
    address: req.body.address,
    share: req.body.share || 1,
    is_auto_approve: req.body.is_auto_approve || 0,
    manu_sort_flag: req.body.manu_sort_flag || 0,
    id: req.body.corp_id
  };
  var corp_user_id = req.body.corp_user_id;
  var corp_id = req.body.corp_id;

  if (corp_user_id != usr.id && corp_id != usr.corporation_id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var opt = {
    user_id:usr.id,
    url:nconf.get("url:corporation"),
    action:nconf.get("action:update"),
    operate_type:nconf.get("operate_type:corporation"),
    operate_id:corp_id,
    content:{name:req.body.name},
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);

  corpModel.updateCorporation(params, function(err, result) {
    req.session.rcode.msg = messageUtils.msgSuccess("资料更新成功");
    if(usr.isSupervisor || usr.isAdmin){
      res.redirect('/corp_manage');
    }else{
      res.redirect('/corp_info/update');
    }

  });

});

router.get('/superior/:superior_id', function(req, res, next) {
  var superiorId = req.params.superior_id;
  corpModel.getSuperiorById(superiorId, function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.send(rows);
  });
});

router.get('/regionName/:region_id', function(req, res, next) {
  var regionId = req.params.region_id;
  commonModel.getRegionNameByCode(regionId, function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.send(rows);
  });

});

router.get('/', function(req, res, next){
  var usr = req.session.rcode.user;
  var params = {
    user_id:usr.id,
    url:nconf.get("url:corporation"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:corporation"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  messageUtils.getSessionMsg(req, res);
  var msg;
  if(usr.isAdmin || usr.isSupervisor){
    msg = "企业管理";
  }else{
    msg = "企业信息";
  }
  return res.render('corporation', {
    header: msg,
    user:usr
  });
});

router.get('/list', function(req, res, next){
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.superiorId = usr.corporation_id;
  tableParams.user = usr;
  tableParams.userId = usr.id;
  tableParams.state = 1;
  corpModel.getCorpListByRole(tableParams, function(tableData){
    if(tableData.aaData.length <= 0){
      return res.send(tableData);
    }
    var regions = [];
    tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
      regions.push(item.region_id);
    });
    corpModel.covRegionToName(regions, function(err, names){
      tableData.aaData.forEach(function(item, i){
        item.region_id = names[i];
      });
      return res.send(tableData);
    });
  });
});

router.get('/add', function(req, res, next){
  var usr = req.session.rcode.user;
  var msg;
  var superior_id;
  if(usr.isAdmin){
    msg = "企业管理 > 监管部门添加";
  }else if(usr.isSupervisor){
    msg = "企业管理 > 企业添加";
    superior_id = usr.corporation_id;
  }else{
    msg = "企业信息> 企业添加";
  }
  return res.render('corporation/add', {
    header: msg,
    creator: usr.id,
    superior_id: superior_id,
    user:usr
  });

});

router.post('/add', function(req, res, next){
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var region_id = req.body.category;

  var qrcode;
  if(!usr.isAdmin){
    qrcode = "i.1." + region_id + ".0" + region_id.substring(0,2) + "." + commonUtils.generateFakeCode(6);
  }
  var params = {
    creator:creator,
    superior_id:req.body.superior_id || null,
    name: req.body.name || "",
    region_id: region_id,
    qrcode: qrcode,
    is_show_anti_fake: req.body.anti_fake,
    contact: req.body.contact,
    telephone: req.body.telephone,
    email: req.body.email,
    address: req.body.address,
    share: req.body.share,
    is_auto_approve: req.body.is_auto_approve,
    manu_sort_flag: req.body.manu_sort_flag,
    state:1,
    client_address: commonUtils.getClientIp(req)
  };

  corpModel.insertCorporation(params, function(err, result) {
    if(err || !result){
      logger.info(err);
      req.session.rcode.msg = messageUtils.msgSuccess("企业添加失败");
      res.redirect('/corporation');
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:corporation"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:corporation"),
        operate_id:result.insertId,
        content:{name:req.body.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("企业添加成功");
      res.redirect('/corp_manage');
    }
  });

});

router.get('/update/:corpId', function(req, res, next){
  var usr = req.session.rcode.user;
  var corpId = req.params.corpId;
  corpModel.getCorpById(corpId, function(err, row){
    if (err) {
      return next(err);
    }
    var msg;
    if(usr.isAdmin){
      msg = "企业管理 > 监管部门更新";
    }else if(usr.isSupervisor){
      msg = "企业管理 > 企业更新";
    }else{
      msg = "企业信息> 企业更新";
    }
    return res.render('corporation/update', {
      header: msg,
      creator: usr.id,
      corporation: row
    });
  });
});

router.get('/delete/:corpId', function(req, res, next){
  var usr = req.session.rcode.user;
  var corpId = req.params.corpId;
  corpModel.delCorpById(corpId, function(err, result){
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("企业删除失败");
      res.redirect('/corporation');
    }else{
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:corporation"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:corporation"),
        operate_id:corpId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("企业删除成功");
      res.redirect('/corp_manage');
    }

  });
});

router.get('/view/:corpId', function(req, res, next) {
  var corpId = req.params.corpId;

  corpModel.getCorpById(corpId, function(err, row) {
    if (err) {
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:corporation"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:corporation"),
      operate_id:corpId,
      content:{name:row.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('corporation/view', {
      header: "本企业信息",
      corp: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/superiors', function(req, res, next){
  corpModel.getAllSuperiors(function(err, rows){
    if (err) {
      return next(err);
    }
    return res.send(JSON.stringify(rows));
  });

});


module.exports = router;