$ pip install factory-boy
