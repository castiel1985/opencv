"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;

function insertQrCode(params, callback) {
  var sql = 'INSERT INTO qr_base_code (`corporation_id`,' +
    ' `production_base_id`, ' +
    ' `qrcode`, ' +
    ' `type`, ' +
    '`state`) values ' +
    '(:corporation_id,' +
    ':production_base_id,' +
    ':qrcode,' +
    ':type,' +
    ':state)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback ? callback(new global.DBError("MySQL Error"), null) : null;
    }
    var codeId = result.insertId;
    logger.info("added qr_code id = %d", codeId);
    return callback ? callback(null, codeId) : null;
  });
}

function insertPatchQrCode(vals) {
  if(vals && vals.length > 0){
    var sqlPrex = 'INSERT INTO qr_base_code (corporation_id,production_base_id, manufacture_id, qrcode, type, state) values ';
    sqlPrex = sqlPrex + vals.join(",");
    database.query({
      sql: sqlPrex
    }, function(err, result) {
      if(err){
        logger.error("add qr_code error ", err);
      }else{
        logger.info("add qr_code ", result);
      }
    });
  }
}

function getBaseCodeInfoByCode(code, callback) {
  database.query({
    sql: "SELECT * FROM qr_base_code" +
    " WHERE qrcode=:code",
    params: {
      "code": code
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

exports.insertQrCode = insertQrCode;
exports.insertPatchQrCode = insertPatchQrCode;
exports.getBaseCodeInfoByCode = getBaseCodeInfoByCode;
