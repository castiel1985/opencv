$ python setup.py bdist_wheel
running bdist_wheel
-（中间省略）-
creating _build/bdist.linux-x86_64/wheel/guestbook-1.0.0.dist-info/WHEEL

$ ls dist/
guestbook-1.0.0-py2-none-any.whl   guestbook-1.0.0.tar.gz
