"use strict";
var express = require('express');
var router = express.Router();
var displaymenu = require('../models/displaymenuModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  var usr = req.session.rcode.user;
  messageUtils.getSessionMsg(req, res);
  var params = {
    user_id:usr.id,
    url:nconf.get("url:displaymenu"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:displaymenu"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  return res.render('displaymenu', {
    header: "自定义栏目管理"
  });
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId =usr.corporation_id;
  tableParams.state = 1;
  displaymenu.getDisplayMenuListByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/update/:id', function(req, res, next) {
  var displaymenuId = req.params.id;
  displaymenu.getDisplayMenuById(displaymenuId, function(err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('displaymenu/update', {
      header: "自定义栏目管理 > 栏目修改",
      creator: req.session.rcode.user.id,
      displaymenu: row
    });
  });
});

router.post('/update/:id', function(req, res, next) {
  var displaymenuId = req.params.id;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    id: displaymenuId,
    name:req.body.name
  };

  displaymenu.updateDisplayMenuById(params, function(err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError("栏目修改失败");
      return res.redirect('/corp_propaganda/displaymenu/update/'+displaymenuId);
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:displaymenu"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:displaymenu"),
        operate_id:displaymenuId,
        content:{name:{old:req.body.old_name,new:req.body.name}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("栏目修改成功");
      return res.redirect('/corp_propaganda/displaymenu');
    }
  });
});

router.get('/add', function(req, res, next) {
  return res.render('displaymenu/add', {
    header: "自定义栏目管理 > 添加栏目",
    creator: req.session.rcode.user.id
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    creator: usr.id,
    corporation_id:usr.corporation_id,
    name: req.body.name,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  displaymenu.addDisplayMenu( params, function ( err, displaymenuId){
    if(err){
      return res.render('displaymenu/add', {
        header: "自定义栏目管理 > 添加栏目",
        msg: messageUtils.msgError("栏目添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:displaymenu"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:displaymenu"),
        operate_id:displaymenuId,
        content:{name:req.body.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("栏目添加成功");
      return res.redirect('/corp_propaganda/displaymenu');
    }
  });
});

router.get('/delete/:id', function(req, res, next) {

  var displaymenuId = req.params.id;
  displaymenu.deletDisplayMenu(displaymenuId, function(err, brand){
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("栏目删除失败");
      return res.redirect('/corp_propaganda/displaymenu');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:displaymenu"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:displaymenu"),
        operate_id:displaymenuId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("栏目删除成功");
      return res.redirect('/corp_propaganda/displaymenu');
    }
  });
});

module.exports = router;