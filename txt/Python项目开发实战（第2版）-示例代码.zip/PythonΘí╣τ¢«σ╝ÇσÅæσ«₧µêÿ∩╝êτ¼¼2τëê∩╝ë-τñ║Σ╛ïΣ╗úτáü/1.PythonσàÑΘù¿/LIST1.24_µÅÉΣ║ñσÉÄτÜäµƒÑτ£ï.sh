$ hg status
