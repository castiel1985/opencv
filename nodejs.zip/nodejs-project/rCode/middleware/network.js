"use strict";
/**
 * Created by Alen on 15/4/3.
 * https://github.com/szanlin
 */
var logger = require('../utils/winstonUtils').logger;


(function(Network) {

  Network.printHead = function (req) {
    var hd = req.headers;
    logger.info(hd);
  };


}(exports));

