"use strict";
var express = require('express');
var router = express.Router();
var corpModel = require('../models/corpModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var async = require("async");
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {

  var usr = req.session.rcode.user;

  corpModel.getCorpById(usr.corporation_id, function(err, row) {
    if (err) {
      return next(err);
    }
    var params = {
      user_id: usr.id,
      url: nconf.get("url:corporation_introduction"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:corporation_introduction"),
      operate_id:usr.corporation_id,
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);

    messageUtils.getSessionMsg(req, res);
    return res.render('corporation_introduction', {
      header: "企业概况管理",
      creator: req.session.rcode.user.id,
      corporation: row
    });
  });
});

router.post('/update/:corpId', function(req, res, next) {
  var corpId = req.params.corpId;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var delFileIds = req.body.delFileIds;

  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    corporationid: corpId,
    contact: req.body.contact || '',
    telephone: req.body.telephone || '',
    email: req.body.email || '',
    address: req.body.address || '',
    desc: req.body.desc || '',
    creator:creator
  };

  /*var filesVideo = req.session.rcode.uploadedFile;
  if(filesVideo){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.files = filesVideo;
  }*/

  var pictureFiles = req.session.rcode.uploadedFile;
  if(pictureFiles){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  if(delFileIds){
    commonModel.updateFilesState({state:0}, delFileIds, function (err, result) {
      if(err || !result){
        req.session.rcode.msg = messageUtils.msgError("企业概况修改失败");
        return res.redirect('/corp_propaganda/introduction');
      }
    });
  }

  corpModel.updateIntroduction(params, function(err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError("企业概况修改失败");
      return res.redirect('/corp_propaganda/introduction');
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:corporation_introduction"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:corporation_introduction"),
        operate_id:corpId,
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("企业概况修改成功");
      return res.redirect('/corp_propaganda/introduction');
    }
  });
});

module.exports = router;