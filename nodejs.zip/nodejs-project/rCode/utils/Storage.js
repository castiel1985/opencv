var nconf = require('nconf');
var path = require('path');
var fs = require('fs');
var utils = require('./Common');


exports.upload = function (file, options, callback) {
  var filename = options.filename;

  var newFilename = utils.md5(filename + String((new Date()).getTime())) +
    path.extname(filename);

  var upload_path = path.join(__dirname,"..",nconf.get("upload:path"));
  var base_url    = nconf.get("upload:url");
  var filePath    = path.join(upload_path, newFilename);
  var fileUrl     = base_url + newFilename;

  file.on('end', function () {
    callback(null, {
      url: fileUrl
    });
  });

  file.pipe(fs.createWriteStream(filePath));
};
