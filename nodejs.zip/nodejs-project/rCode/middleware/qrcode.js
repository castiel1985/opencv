"use strict";
/**
 * Created by Alen on 15/3/21.
 * https://github.com/szanlin
 */

var commonUtils = require('../utils/Common');
var logger = require('../utils/winstonUtils').logger;
var util = require('util');
var underscore = require('underscore');


(function(QRcode) {
  //'生产基地码 1/生产加工类型码 2/销售码 3/产品码 3/物流码 5'
  QRcode.TYPE = {
    "BASE": 1,
    "MANUFACTURE": 2,
    "SALES": 3,
    "PRODUCTION": 3,
    "TRANSMIT": 5
  };

  /**
   * 生成QRCODE列表
   * @param qrcode_prefix
   * @param code_start
   * @param code_end
   * @param code_type
   * @param anti_fake_identify
   * @param page_idx
   * @returns {{codeList: Array, page_idx: (*|number), page_total: number}}
   */
  QRcode.generateQRcodeList = function(qrcode_prefix, code_start, code_end, code_type, anti_fake_identify, page_idx) {

    var diff = code_end - code_start;
    var per_page = commonUtils.PER_PAGE_NUM;
    var page_total = diff / per_page;
    page_idx = page_idx || 1;
    if (diff % per_page > 0) {
      page_total += 1;
    }
    var list = [];
    for (var i = per_page * (page_idx - 1); i < Math.min(diff, per_page); i++) {
      var tmp = {
        qrcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(code_start) + i, 8) + "." + code_type,
        fake_code: commonUtils.padZero(commonUtils.numToBase36(parseInt(anti_fake_identify) + i), 6),
        status_text: "未使用"
      };
      list.push(tmp);
    }
    return {
      codeList: list,
      page_idx: page_idx,
      page_total: page_total
    };
  };


  QRcode.getTransmitCodeBySerial = function(longDate,sold_records,creator,corpcode){
    var now = longDate || Date.now();
    var seed = util.format("%s%s%s",sold_records,creator ||"", now);
    return util.format("%s.%s.%s",corpcode, commonUtils.hash('md5',seed,'hex'), QRcode.TYPE.TRANSMIT);
  };


}(exports));
