"use strict";
var express = require('express');
var router = express.Router();
var packageModel = require('../models/productionPackageModel');
var qrcodeModel = require('../models/qrcodeModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var async = require("async");

router.get('/', function (req, res, next) {
  messageUtils.getSessionMsg(req, res);
  var opt = {
    user_id: req.session.rcode.user.id,
    url: nconf.get("url:package"),
    action: nconf.get("action:index"),
    operate_type: nconf.get("operate_type:package"),
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  return res.render('production_package', {
    header: "包装管理"
  });
});

router.get('/list', function (req, res, next) {
  var user = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = user.id;
  tableParams.corpId = user.corporation_id;
  tableParams.state = 1;
  packageModel.getPackagelist(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.package_date = commonUtils.dateFormat(new Date(item.package_date));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {
  var corp = req.session.rcode.corporation;
  return res.render('production_package/add', {
    header: "包装管理 > 产品包装",
    corpcode: corp.qrcode
  });
});

router.post('/add', function (req, res, next) {
  var qrcode_start_id = parseInt(req.body.qrcode_start);
  var qrcode_end_id = parseInt(req.body.qrcode_end);
  var apply_id = parseInt(req.body.apply_id);
  var count = qrcode_end_id - qrcode_start_id + 1;
  var params = {
    production_id: req.body.production,
    serial_id: req.body.serial,
    subserial_id: req.body.subserial,
    qrcode_apply_id: apply_id,
    qrcode_start_id: qrcode_start_id,
    package_count: count,
    creator: req.session.rcode.user.id,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  var corp = req.session.rcode.corporation;
  var statuscondition = "status = " + qrcodeModel.PRODUCTION_QRCODE_STATUS.no_use;
  var qrcode_prefix = corp.qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);

  var codeList = {
    startcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(qrcode_start_id) + 0, 8) + "." + 3,
    endcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(qrcode_start_id + count - 1) + 0, 8) + "." + 3
  };
  qrcodeModel.getQrcodeByCode(codeList, statuscondition, function (err, tableData) {
    if (tableData.aaData.length < count) {
      return res.render('production_package/add', {
        header: "包装管理 > 产品包装",
        corpcode: corp.qrcode,
        msg: messageUtils.msgError("产品包装失败,所选二维码可能已被使用")
      });
    }
    qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.packaged, codeList, function (err, result) {
      if (err || !result) {
        return res.render('production_package/add', {
          header: "包装管理 > 产品包装",
          corpcode: corp.qrcode,
          msg: messageUtils.msgError("产品包装失败")
        });
      } else {
        packageModel.addPackage(params, function (err, packageId) {
          if (err) {
            return res.render('sales/add', {
              header: "包装管理 > 产品包装",
              corpcode: corp.qrcode,
              msg: messageUtils.msgError("产品包装失败")
            });
          } else {
            var opt = {
              user_id: req.session.rcode.user.id,
              url: nconf.get("url:package"),
              action: nconf.get("action:add"),
              operate_type: nconf.get("operate_type:package"),
              operate_id: packageId,
              content: {production_name: req.body.production_name, package_count: count},
              state: 1,
              client_address: commonUtils.getClientIp(req)
            };
            logsModel.addOperateLog(opt);
            req.session.rcode.msg = messageUtils.msgSuccess("产品包装成功");
            return res.redirect('/work_manage/production_package');
          }
        });
      }
    });
  });
});

router.get('/select_qrcode/view', function (req, res, next) {
  var corp = req.session.rcode.corporation;
  var corporationId = corp.id;
  if (underscore.isNaN(corporationId)) {
    return next(new Error("Invalid Parameters"));
  }
  return res.render('sales/select_qrcode', {
    header: "可用二维码查看",
    id: corporationId,
    layout: "partial/modal_layout"
  });
});

router.get('/select_qrcode/:corporationId/list', function (req, res, next) {
  var user = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corporationId = req.params.corporationId;
  tableParams.userId = user.id;
  tableParams.status = 0;
  if(user.isCorp){
    tableParams.all = true;
  }else{
    tableParams.all = false;
  }
  var corpId = req.params.corporationId;
  async.waterfall([
    function(cb){
      packageModel.getCorpApplyIds(corpId, function(err, rows){
        cb(err, rows);
      });
    },
    function(rows, cb){
      var ids = [];
      rows && rows.forEach(function(item){
        ids.push(item.id);
      });
      packageModel.getApplyPackages(ids, function(err, packages){
        cb(err, rows, packages);
      });
    }
  ], function (err, rows, packages) {
    var tableData;
    if(!err){
      var key;
      var value=[];
      var last;
      var start;
      var end;
      //已包装的二维码段
      var obj = {};
      packages && packages.forEach(function(item){
        key = "apply_"+item.qrcode_apply_id;
        start = item.qrcode_start_id;
        end = item.qrcode_start_id+item.package_count-1;
        if(obj[key]){
          value = obj[key];
          last = value.pop();
          if(last.end === item.qrcode_start_id - 1){
            start = last.start;
            end = item.qrcode_start_id+item.package_count-1;
          }else{
            value.push(last);
          }
        }else{
          value = [];
        }
        value.push({start:start,end:end});
        obj[key] = value;
      });

      //已申请的二维码段
      var obj1 = {};
      rows && rows.forEach(function(item){
        key = "apply_"+item.id;
        start = item.qrcode_start;
        end = item.qrcode_start+item.apply_count-1;
        obj1[key] = {start:start,end:end};
      });
      var apply;
      var pack;
      var arr = [];
      var apply_id;
      var qrcode_prefix;
      var start_code;
      var end_code;
      var corporation_qrcode = req.session.rcode.corporation.qrcode;

      //根据已申请和已包装的二维码段，得到未包装的二维码段
      for(key in obj1){
        apply = obj1[key];
        pack = obj[key];
        apply_id = key.split("_")[1];
        qrcode_prefix = corporation_qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);
        if(pack){
          //申请的二维码有包装记录
          last=apply.start-1;
          pack.forEach(function(item, index){
            //申请的二维码从第一个到最后一个都已经包装了
            if(item.start === apply.start && item.end === apply.end){
            }else{
              //包装的二维码跟上一次包装的二维码时连续的
              if(last === item.start-1){
              }else{
                //申请的二维码有未包装的
                start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
                end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.start-1), 8) + ".3";
                arr.push({start_code:start_code,end_code:end_code});
              }
              last = item.end;
            }
            //最后一段二维码未包装
            if(index === pack.length - 1 && item.end != apply.end){
              start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
              end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(apply.end), 8) + ".3";
              arr.push({start_code:start_code,end_code:end_code});
            }
          });
        }else{
          //申请的二维码没有包装记录
          start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(apply.start), 8) + ".3";
          end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(apply.end), 8) + ".3";
          arr.push({start_code:start_code,end_code:end_code});
        }
      }
      var data = arr.slice(tableParams.start,tableParams.start+tableParams.length);
      tableData = {aaData:data,iTotalRecords:arr.length,iTotalDisplayRecords:arr.length};
      return res.send(tableData);
    }else{
      tableData = {aaData:[],iTotalRecords:0,iTotalDisplayRecords:0};
      return res.send(tableData);
    }
  });
});

router.get('/view/:packageId', function (req, res, next) {
  var packageId = req.params.packageId;
  if (underscore.isNaN(packageId)) {
    return next(new Error("Invalid Parameters"));
  }
  if (req.query["corp_qrcode"]) {
    req.session.rcode.corp_qrcode = req.query["corp_qrcode"];
  }

  return res.render('production_package/view', {
    header: "查看包装记录",
    packageId: packageId,
    layout: "partial/modal_layout"
  });
});

router.get('/view/:packageId/list', function (req, res, next) {
  var packageId = req.params.packageId;
  if (underscore.isNaN(packageId)) {
    return next(new Error("Invalid Parameters"));
  }
  packageModel.getPackageById(packageId, function (err, rows) {
    if (err) {
      return next(err);
    } else {
      var num = parseInt(rows.package_count);
      var startId = parseInt(rows.qrcode_start_id);
      var corp = req.session.rcode.corporation;
      var corp_qrcode = corp && corp.qrcode ? corp.qrcode : req.session.rcode.corp_qrcode;
      var qrcode_prefix = corp_qrcode + "." + commonUtils.padZero(parseInt(rows.qrcode_apply_id), 8);
      var tableParams = dataTableObj.getParams(req);
      var page_start = parseInt(tableParams.start);
      tableParams.startcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(startId) + 0, 8) + "." + 3;
      tableParams.page_startcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(startId) + page_start, 8) + "." + 3;
      tableParams.endcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(startId + num - 1) + 0, 8) + "." + 3;
      tableParams.orderName = "qrcode";
      tableParams.package_count = num;
      var params = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:package"),
        action: nconf.get("action:view"),
        operate_type: nconf.get("operate_type:package"),
        operate_id: packageId,
        content: {production_name: rows.production, package_count: num},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(params);
      qrcodeModel.getQrcodeByCode(tableParams, null, function (err, tableData) {
        tableData.aaData && tableData.aaData.forEach(function (item) {
          item.production = rows.production;
          item.package_date = commonUtils.dateFormat(new Date(rows.package_date));
        });
        return res.send(tableData);
      });
    }
  });
});

module.exports = router;