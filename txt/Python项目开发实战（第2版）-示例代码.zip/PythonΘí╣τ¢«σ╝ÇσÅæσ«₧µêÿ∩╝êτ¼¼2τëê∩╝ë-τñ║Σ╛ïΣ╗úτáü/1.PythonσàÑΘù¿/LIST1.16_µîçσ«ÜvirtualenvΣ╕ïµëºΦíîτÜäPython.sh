$ virtualenv --python=/opt/python2.7.9/bin/python venv2
$ source venv2/bin/activate
(venv2)$
Python 2.7.9
