$ sudo chown -R www-data:www-data /usr/share/redmine
