"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;


function delReportById(reportId,callback){
    var update = "UPDATE qr_serials_test_report SET `state`=0 WHERE id = :reportId";
    var params = {
        reportId: reportId
    };
    database.query({
        sql: update,
        params: params
    },function(err, result) {
        if (err || !result) {
            logger.error(err ? err.stack : "row is null");
            return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        return callback(null, result);
    });
}

function getReportList(tableParams, callback) {
  var sqlData = "select c.*, a.name as production_name ,b.serial_no, ifnull(d.serial_no,'公用') as sub_serial_no from qr_production a, qr_serials b, qr_serials_test_report c left join qr_serials d on d.id = c.sub_serial_id " +
    "where a.id = b.production_id and c.state = :state  and b.id = c.serial_id " +
    "and b.id=:serialId ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_serials_test_report WHERE serial_id = :serialId AND state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and c.sub_serial_no like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_serials_test_report WHERE serial_id = :serialId AND state = :state AND sub_serial_no like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function addReport(params, callback) {
  var sql = 'INSERT INTO qr_serials_test_report (`sub_serial_id`,' +
    ' `serial_id`, ' +
    ' `creator`, ' +
    ' `title`, ' +
    ' `desc`, ' +
    ' `state`,' +
    ' `client_address`) values ' +
    '(:sub_serial_id,' +
      ':serial_id,' +
      ':creator,' +
      ':title,' +
      ':desc,' +
     ':state,' +
     ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var reportId = result.insertId;
    logger.info("added report id = %d", reportId);

    if(params.pictureFiles) {
      params.pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = params.creator;
        item.type = 'report_picture_' + reportId;
        commonModel.insertFiles(item, null);
      });
    }
    return callback(null, reportId);
  });

}


function updateReport(params,reportId, callback) {
  var sql_head = "UPDATE qr_serials_test_report SET ";
  var colums = [];
  var pictureFiles = params.pictureFiles;
  var creator = params.creator;
  delete params.pictureFiles;
  delete params.creator;
  for(var key in params){
    colums.push("`"+key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + reportId ;
  database.query({
    sql:sql,
    params: params
  }, function(err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if(pictureFiles) {
        pictureFiles.forEach(function (item) {
          item.creator = creator;
          item.type = 'report_picture_' + reportId;
          commonModel.insertFiles(item, null);
        });
      }
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

function getReportById(recordId, callback) {
  database.query({
    sql: "SELECT a.*,IFNULL(b.serial_no,'公用') AS sub_serial_no FROM qr_serials_test_report a LEFT JOIN qr_serials b ON b.id = a.sub_serial_id WHERE a.id =:recordId",
    params: {
      "recordId": recordId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:pictureType AND state=1",
        params: {
          "pictureType": "report_picture_" + recordId
        }
      }, function(err, rows2){
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = rows2;
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }
  });
}

exports.getReportList = getReportList;
exports.addReport = addReport;
exports.updateReport = updateReport;
exports.getReportById = getReportById;
exports.delReportById = delReportById;
