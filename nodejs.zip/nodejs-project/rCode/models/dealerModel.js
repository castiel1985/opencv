"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require('./commonModel.js');


function getDealerListByCorpId(tableParams, callback) {
  var sqlData;
  var sqlCount;
  var user =  tableParams.user;
  if(user && user.isCorp){
    sqlData = "SELECT a.* FROM qr_production_dealer a,qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state = :state ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production_dealer a,qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state = :state ";
  }else{
    sqlData = "SELECT a.* FROM qr_production_dealer a,qr_user b,qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_production_dealer a,qr_user b,qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state ";
  }

  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    if(user && user.isCorp){
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production_dealer a,qr_user b WHERE a.creator =b.id AND b.corporation_id = :corpId AND a.state = :state AND a.name like :search ";
    }else{
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_production_dealer a,qr_user b,qr_corporation c WHERE a.creator =b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state AND a.name like :search ";
    }

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function addDealer(options, callback) {
  var sql = 'INSERT INTO qr_production_dealer (`creator`,' +
    '`name`, ' +
    '`region_id`, ' +
    '`type`, ' +
    '`address`, ' +
    '`location`, ' +
    '`note`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:creator,'+
    ':name,' +
    ':region_id,' +
    ':type,' +
    ':address,' +
    ':location,' +
    ':note,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"),null);
    }
    var dealerId = result.insertId;
    return callback(null,dealerId);
  });

}

function getDealerById(dealerId, callback) {

  database.query({
    sql: "SELECT a.*,GROUP_CONCAT(b.name) as region_name  FROM qr_production_dealer a, qr_region b  WHERE (b.code = CONCAT(SUBSTRING(a.region_id,1,2),'0000') || b.code = CONCAT(SUBSTRING(a.region_id,1,4),'00') || b.code = a.region_id) AND a.id = :dealerId AND a.state = :state",
    params: {
      "dealerId": dealerId,
      "state": 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

function updateDealer(params, dealerId, callback) {
  var sql_head = "UPDATE qr_production_dealer SET ";
  var colums = [];
  for (var key in params) {
    colums.push("`" + key + "`" + "=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + dealerId;
  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}

function delDealerById(dealerId, callback){
  var sql = "UPDATE qr_production_dealer SET state = :state WHERE id = :dealerId";
  var params = {
    state : 0,
    dealerId : dealerId
  };
  database.query({
    sql:sql,
    params:params
  },function(err, result){
    if(err || !result){
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      return callback(err, true);
    }
  });
}
exports.getDealerListByCorpId = getDealerListByCorpId;
exports.addDealer = addDealer;
exports.getDealerById = getDealerById;
exports.updateDealer = updateDealer;
exports.delDealerById = delDealerById;
