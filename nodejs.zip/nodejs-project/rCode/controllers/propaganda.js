"use strict";
var express = require('express');
var router = express.Router();
var corpModel = require('../models/corpModel');
var departmentModel = require('../models/departmentModel');
var displaymenuModel = require('../models/displaymenuModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var dataTableObj = require('../middleware/dataTableObject');
var async = require("async");

router.get('/:qrcode', function(req, res, next) {
  var qrcode = req.params.qrcode;
  req.session.rcode = req.session.rcode ? req.session.rcode :{};
  if(req.session.rcode.corpData && req.session.rcode.corpData.index.qrcode == qrcode){
    return res.render('propaganda', {
      corpData:req.session.rcode.corpData,
      layout: "partial/wap_layout"
    });
  }else{
    var corpData = {};
    corpModel.getCorpByCode(qrcode, function(err, corp) {
      if (err) {
        return next(err);
      }else if(!corp){
        return next("Error: Page Not Found: /propaganda/"+qrcode);
      }else{
        var params = {
          corpId: corp.id,
          state: 1
        };
        corpData.index = corp;
        departmentModel.getDepartmentListByCorpId(params, function(departmentList) {
          corpData.department = departmentList.aaData;
          displaymenuModel.getDisplayMenuListByCorpId(params, function (displayMenuList) {
            displayMenuList.aaData && async.map(displayMenuList.aaData, function(item, cb){
              displaymenuModel.getNewsListByDisplayMenuId({displaymenuId:item.id,corpId: corp.id,state: 1}, function(newsList) {
                item.news = newsList.aaData;
                cb(null,item);
              });
            },function(err,results){
              corpData.menuList = results;
              req.session.rcode.corpData = corpData;
              return res.render('propaganda', {
                corpData:corpData,
                layout: "partial/wap_layout"
              });
            });
          });
        });
      }
    });
  }
});



module.exports = router;