$ sudo adduser bpuser --ingroup dev
