jQuery(function() {
  var $ = jQuery, // just in case. Make sure it's not an other libaray.
    uploader;

  if (!WebUploader.Uploader.support()) {
    alert('Web Uploader 不支持您的浏览器！如果你使用的是IE浏览器，请尝试升级 flash 播放器');
    throw new Error('WebUploader does not support the browser you are using.');
  }

  // 实例化
  uploader = WebUploader.create({
    pick: {
      id: '#filePicker_video',
      label: '选择视频'
    },
    accept: {
      title: 'Video',
      extensions: 'avi,wmv',
      mimeTypes: 'video/*'
    },

    // swf文件路径
    swf: '/bower_components/fex-webuploader/dist/Uploader.swf',

    disableGlobalDnd: true,

    // server: 'http://webuploader.duapp.com/server/fileupload.php',
    server: '/api/upload_file_video',
    fileNumLimit: 10,
    fileSizeLimit: 100 * 1024 * 1024, // 100 M
    fileSingleSizeLimit: 50 * 1024 * 1024 // 50 M
  });


  // 当有文件被添加进队列的时候
  uploader.on('fileQueued', function( file ) {
    $("#thelist").append('<div id="' + file.id + '" class="item">' +
    '<h4 class="info">' + file.name + '</h4>' +
    '<p class="state">等待上传...</p>' +
    '</div>');
  });

  uploader.on( 'uploadProgress', function( file, percentage ) {
    var $li = $('#' + file.id),
      $percent = $li.find('.progress .progress-bar');

    // 避免重复创建
    if (!$percent.length) {
      $percent = $('<div class="progress progress-striped active">' +
      '<div class="progress-bar" role="progressbar" style="width: 0%">' +
      '</div>' +
      '</div>').appendTo($li).find('.progress-bar');
    }

    $li.find('p.state').text('上传中');

    $percent.css('width', percentage * 100 + '%');
  });

  uploader.on( 'uploadSuccess', function( file ) {
    $( '#'+file.id ).find('p.state').text('已上传');
  });

  uploader.on( 'uploadError', function( file ) {
    $( '#'+file.id ).find('p.state').text('上传出错');
  });

  uploader.on( 'uploadComplete', function( file ) {
    $('#' + file.id).find('.progress').fadeOut();
  });

});