$ pip install -e ./logfilter-0.9.2
