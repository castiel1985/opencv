$ python manage.py loaddata polls.json
