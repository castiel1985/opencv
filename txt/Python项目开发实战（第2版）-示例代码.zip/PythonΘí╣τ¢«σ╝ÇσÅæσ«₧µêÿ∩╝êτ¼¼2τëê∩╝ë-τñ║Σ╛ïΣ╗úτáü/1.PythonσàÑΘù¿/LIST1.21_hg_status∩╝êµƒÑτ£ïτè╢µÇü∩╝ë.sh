$ touch test.txt
$ hg status

? test.txt
