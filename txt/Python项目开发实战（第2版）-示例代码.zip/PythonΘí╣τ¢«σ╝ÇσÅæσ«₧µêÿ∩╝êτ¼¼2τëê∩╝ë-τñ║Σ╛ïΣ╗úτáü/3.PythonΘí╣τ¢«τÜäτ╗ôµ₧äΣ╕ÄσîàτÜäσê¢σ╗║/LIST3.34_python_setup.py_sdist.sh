$ python setup.py sdist
running sdist
running egg_info
-（中间省略）-
warning: sdist: standard file not found: should have one of README, README.rst, README.txt

running check
warning: check: missing required meta-data: url

warning: check: missing meta-data: either (author and author_email) or (maintainer and maintainer_email) must be supplied

creating guestbook-0.0.0
-（中间省略）-
creating dist
Creating tar archive
removing 'guestbook-0.0.0' (and everything under it)

$ ls dist/
guestbook-0.0.0.tar.gz
