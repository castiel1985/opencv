"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require('./commonModel.js');

function getAdvertisementByCorpId( tableParams, callback){
  var sqlData = "SELECT a.* FROM qr_advertisement a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId and a.state = :state ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_advertisement a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId and a.state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.title like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_advertisement a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId and a.state = :state AND a.title like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getAdvertisementById( departmentId, callback){
  database.query({
    sql: "SELECT * FROM qr_advertisement " +
    " WHERE id =:id and state = 1",
    params: {
      "id": departmentId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function updateAdvertisementById( params, callback){
  database.query({
    sql: "UPDATE qr_advertisement SET `title`=:title,`content`=:content " +
    " WHERE id =:id",
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function addAdvertisement( params, callback){
  var sql = 'INSERT INTO qr_advertisement (' +
    '`corporation_id`,' +
    '`title`,' +
    '`content`, ' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(' +
    ':corporation_id,'+
    ':title,'+
    ':content,' +
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"),null);
    }
    var departmentId = result.insertId;
    logger.info("added qr_advertisement  id = %d", departmentId);
    return callback(null, departmentId);
  });
}

function deletAdvertisement(id, callback) {
  database.query({
    sql: "UPDATE qr_advertisement SET state = 0 WHERE id =:id",
    params: {
      "id": id
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

function getAdvertisementByCode(qrcode,callback){
  database.query({
    sql: "SELECT a.* FROM qr_advertisement a,qr_code b" +
    " WHERE a.corporation_id = b.corporation_id and b.qrcode = :qrcode",
    params: {
      "qrcode": qrcode
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows);
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

exports.getAdvertisementByCode = getAdvertisementByCode;
exports.deletAdvertisement = deletAdvertisement;
exports.addAdvertisement = addAdvertisement;
exports.getAdvertisementById = getAdvertisementById;
exports.updateAdvertisementById = updateAdvertisementById;
exports.getAdvertisementByCorpId = getAdvertisementByCorpId;
