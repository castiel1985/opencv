$ hg add test.txt
$ hg status

A test.txt
