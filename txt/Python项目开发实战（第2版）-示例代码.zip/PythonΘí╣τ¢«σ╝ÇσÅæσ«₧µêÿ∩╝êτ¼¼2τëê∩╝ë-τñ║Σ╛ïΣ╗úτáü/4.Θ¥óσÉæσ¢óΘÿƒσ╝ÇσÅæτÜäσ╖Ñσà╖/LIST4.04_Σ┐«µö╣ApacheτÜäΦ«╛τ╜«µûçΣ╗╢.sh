$ sudo vi /etc/apache2/sites-available/000-default.conf
