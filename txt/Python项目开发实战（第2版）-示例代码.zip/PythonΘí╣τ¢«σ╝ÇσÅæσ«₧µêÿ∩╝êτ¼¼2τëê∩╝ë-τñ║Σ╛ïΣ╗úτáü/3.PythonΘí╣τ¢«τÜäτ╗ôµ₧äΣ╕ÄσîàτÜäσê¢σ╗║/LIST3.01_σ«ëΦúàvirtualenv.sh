$ sudo pip install virtualenv
