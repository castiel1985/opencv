"use strict";
var express = require('express');
var router = express.Router();
var businesscardModel = require('../models/businesscardModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  var opt = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:businesscard"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:businesscard"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  messageUtils.getSessionMsg(req, res);
  return res.render('businesscard', {
    header: "名片宣传码管理"
  });
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;

  businesscardModel.getBusinessCardListByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {
  return res.render('businesscard/add', {
    header: "名片宣传码管理 > 添加名片",
    creator: req.session.rcode.user.id
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var corp = req.session.rcode.corporation;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    creator: usr.id,
    corporation_id: usr.corporation_id,
    name: req.body.name,
    position: req.body.position || '',
    qq: req.body.qq || '',
    mail: req.body.mail || '',
    mobile_phone: req.body.mobile_phone || '',
    hometown: req.body.hometown || '',
    location: req.body.location || '',
    profile: req.body.profile || '',
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  var files = req.session.rcode.uploadedFile;
  if(files){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.files = files;
  }

  businesscardModel.addBusinessCard(params,function(err, businesscardId){
    if(err){
      return res.render('businesscard/add', {
        header: "名片宣传码管理 > 添加名片",
        msg: messageUtils.msgError("名片添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var params = {
        qrcode: corp.qrcode + "." + commonUtils.padZero(parseInt(businesscardId), 8) + ".8"
      };
      businesscardModel.updateBusinessCardById(businesscardId,params,null,function (err,result){
        if(err){
          return res.render('businesscard/add', {
            header: "名片宣传码管理 > 添加名片",
            msg: messageUtils.msgError("名片添加失败"),
            creator: req.session.rcode.user.id
          });
        }else{
          var opt = {
            user_id:usr.id,
            url:nconf.get("url:businesscard"),
            action:nconf.get("action:add"),
            operate_type:nconf.get("operate_type:businesscard"),
            operate_id:businesscardId,
            content:{name:req.body.name},
            state:1,
            client_address: commonUtils.getClientIp(req)
          };
          logsModel.addOperateLog(opt);
          req.session.rcode.msg = messageUtils.msgSuccess("名片添加成功");
          return res.redirect('/corp_propaganda/businesscard');
        }
      });
    }
  });
});

router.get('/update/:id', function(req, res, next) {

  var id = req.params.id;
  businesscardModel.getBusinessCardById(id, function(err, row){
    if(err){
      next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('businesscard/update', {
      header: "名片宣传码管理 > 修改名片",
      businesscard: row,
      creator: req.session.rcode.user.id
    });
  });
});

router.post('/update/:id', function(req, res, next) {
  var id = req.params.id;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var delFileIds = req.body.delFileIds;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    name: req.body.name,
    position: req.body.position || '',
    qq: req.body.qq || '',
    mail: req.body.mail || '',
    mobile_phone: req.body.mobile_phone || '',
    hometown: req.body.hometown || '',
    location: req.body.location || '',
    profile: req.body.profile || '',
    desc: req.body.desc || ''
  };


  var files = req.session.rcode.uploadedFile;

  if(files){
    files[0].creator = creator;
    delete req.session.rcode.uploadedFile;
  }
  if(delFileIds){
    commonModel.updateFilesState({state:0}, delFileIds, function (err, result) {
      if(err || !result){
        req.session.rcode.msg = messageUtils.msgError("名片信息修改失败1");
        return res.redirect('/corp_propaganda/businesscard/update/'+id);
      }
    });
  }

  businesscardModel.updateBusinessCardById(id,params,files, function(err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError("名片信息修改失败2");
      return res.redirect('/corp_propaganda/businesscard/update/'+id);
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:businesscard"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:businesscard"),
        operate_id:id,
        content:{name:{old:req.body.old_name,new:req.body.name}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("名片信息修改成功");
      return res.redirect('/corp_propaganda/businesscard');
    }
  });
});

router.get('/delete/:id', function(req, res, next) {

  var id = req.params.id;
  businesscardModel.deletBusinessCard(id, function(err, brand){
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("名片删除失败");
      return res.redirect('/corp_propaganda/businesscard');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:businesscard"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:businesscard"),
        operate_id:id,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("名片删除成功");
      return res.redirect('/corp_propaganda/businesscard');
    }
  });
});


router.get('/view/:id', function(req, res, next) {
  var id = req.params.id;
  if(underscore.isNaN(id)){
    return next(new Error("Invalid Id"));
  }
  businesscardModel.getBusinessCardById(id, function(err, row) {
    if (err) {
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:businesscard"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:businesscard"),
      operate_id:id,
      content:{name:row.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('businesscard/view', {
      header: "产品详情",
      businesscard: row,
      layout: "partial/modal_layout"
    });
  });
});
module.exports = router;