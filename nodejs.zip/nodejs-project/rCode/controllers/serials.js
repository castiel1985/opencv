"use strict";
var express = require('express');
var _ = require('underscore');
var router = express.Router();
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var serialsModel = require('../models/serialsModel');
var productionModel = require('../models/productionModel');
var serialManufactureModel = require('../models/serialManufactureModel');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {
  var usr = req.session.rcode.user;
  var params;
  if (req.query["ajax"] === "1") {
    var corpId = usr.corporation_id ? usr.corporation_id : req.query["corpId"];
    params = {
      userId: usr.id,
      corpId: corpId,
      state: 1
    };
    serialsModel.getSerialsList(params, function (tableData) {
      return res.send(tableData.aaData);
    });
  } else {
    params = {
      user:usr,
      userId: usr.id,
      corpId: usr.corporation_id,
      state: 1
    };
    var opt = {
      user_id: usr.id,
      url: nconf.get("url:serials"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:serials"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('serials', {
      header: "批次管理"
    });
  }
});

router.get('/list', function (req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  serialsModel.getSerialsList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/anti_fake_update/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  var params = {
    is_anti_fake: req.query.is_anti_fake
  };
  serialsModel.updateSerial(params, serialId, function (err, result) {
    if (err) {
      return next(err);
    }
    var anti_fake = req.query['is_anti_fake'] == "1" ? "显示" : "不显示";
    var old_anti_fake = req.query['is_anti_fake'] == "1" ? "不显示" : "显示";
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:serials"),
      action:nconf.get("action:update"),
      operate_type:nconf.get("operate_type:serials"),
      operate_id:serialId,
      content:{serial_no:req.query['serial_no'],anti_fake:{old:anti_fake,new:old_anti_fake}},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.send(result);
  });
});

router.get('/base_id_update/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  var params = {
    base_id: req.query.base_id
  };
  serialsModel.updateSerial(params, serialId, function (err, result) {
    if (err) {
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:serials"),
      action:nconf.get("action:update"),
      operate_type:nconf.get("operate_type:serials"),
      operate_id:serialId,
      content:{serial_no:req.query['serial_no'],base_name:{old:req.query['old_base'],new:req.query['base']}},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.send(result);
  });
});


router.get('/add', function (req, res, next) {

  return res.render('serials/add', {
    header: "批次管理 > 添加批次"
  });

});

router.get('/update/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;

  serialsModel.getSerialsById(serialId, function (err,row){
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('serials/add',{
      header: "批次管理 > 修改批次",
      serial: row
    });
  });
});


router.post('/add', function (req, res, next) {

  var params = {
    production_id: req.body.production_id,
    serial_no: req.body.serial_no,
    base_id: req.body.base_id,
    creator: req.session.rcode.user.id,
    client_address: commonUtils.getClientIp(req)
  };

  serialsModel.addSerials(params, function (err, serialsId) {
    if (err) {
      return res.render('serials/add', {
        header: "批次管理 > 添加批次",
        msg: messageUtils.msgError("批次添加失败")
      });
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:serials"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:serials"),
        operate_id: serialsId,
        content: {production_name: req.body.production_name, serial_no: req.body.serial_no},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);

      var corp = req.session.rcode.corporation;
      if(corp && corp.manu_sort_flag){
        //serialManufactureModel.autoAddSerialManu({corpId:corp.id,userId:req.session.rcode.user.id,serialsId:serialsId}, function(err, result){
        req.session.rcode.msg = messageUtils.msgSuccess("批次添加成功");
        return res.redirect('/work_manage/serials_manage');
        //});
      }else{
        req.session.rcode.msg = messageUtils.msgSuccess("批次添加成功");
        return res.redirect('/work_manage/serials_manage');
      }
    }
  });

});

/**
 * TODO : 需要检查合法醒，是否伪装请求
 */
router.post('/update/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  var params = {
    production_id: req.body.production_id,
    base_id: req.body.base_id,
    serial_no: req.body.serial_no
  };
  serialsModel.updateSerial(params, serialId, function (err, result) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("批次修改失败");
      return res.redirect('/work_manage/serials_manage/update/'+serialId);
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:serials"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:serials"),
        operate_id: serialId,
        content: {
          production_name: {old: req.body.old_production_name, new: req.body.production_name},
          base_name: {old: req.body.old_base_name, new: req.body.base_name},
          serial_no: {old: req.body.old_serial_no, new: req.body.serial_no}
        },
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("批次修改成功");
      return res.redirect('/work_manage/serials_manage');
    }
  });

});

router.get('/bind_base/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  return res.render('serials/bind_base', {
    header: "批次管理 > 绑定生产基地 ",
    serialId: serialId
  });

});

router.post('/bind_base/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  var params = {
    serialId: serialId,
    productionBaseId: req.body.production_base_id
  };
  serialsModel.bindProductionbase(params, function (err, result) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("绑定生产基地失败");
      return res.redirect('/work_manage/serials_manage');
    } else {
      req.session.rcode.msg = messageUtils.msgSuccess("绑定生产基地成功");
      return res.redirect('/work_manage/serials_manage');
    }
  });

});


router.get('/list/:base_id', function (req, res, next) {

  var baseId = req.params.base_id;
  var params;
  if (req.query["ajax"] === "1") {
    params = {
      state: 1,
      baseId: baseId
    };
    serialsModel.getSerialsListByBaseId(params, function (tableData) {
      return res.send(tableData);
    });
  } else {
    params = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:base"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:serials"),
      operate_id: baseId,
      content: {base_name: req.query['baseName']},
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    return res.render('serials/simple_list', {
      header: "批次列表",
      baseId: baseId,
      layout: "partial/modal_layout"
    });
  }
});

router.get('/list/:base_id/list', function (req, res, next) {

  var baseId = req.params.base_id;

  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.baseId = baseId;
  serialsModel.getSerialsListByBaseId(tableParams, function (tableData) {
    messageUtils.getSessionMsg(req, res);
    tableData.aaData.forEach(function (item) {
      item.create_time_fmt = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });

});

//删除批次
router.get('/delete/:serial_id', function (req, res, next) {
  var serialId = req.params.serial_id;
  serialsModel.delSerialById(serialId, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("批次删除失败");
      return res.redirect('/work_manage/serials_manage');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:serials"),
        action: nconf.get("action:delete"),
        operate_type: nconf.get("operate_type:serials"),
        operate_id: serialId,
        content: {serial_no: req.query['serial_no']},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("批次删除成功");
      return res.redirect('/work_manage/serials_manage');
    }
  });
});


module.exports = router;