def is_last_of_month_now():
    return is_last_of_month(datetime.now())
