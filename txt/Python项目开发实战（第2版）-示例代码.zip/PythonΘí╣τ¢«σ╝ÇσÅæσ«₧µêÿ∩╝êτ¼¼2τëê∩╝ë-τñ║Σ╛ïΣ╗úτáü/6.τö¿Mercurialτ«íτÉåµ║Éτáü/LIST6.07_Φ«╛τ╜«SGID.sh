$ sudo chmod g+sw -R /var/hg/testrepo/.hg
