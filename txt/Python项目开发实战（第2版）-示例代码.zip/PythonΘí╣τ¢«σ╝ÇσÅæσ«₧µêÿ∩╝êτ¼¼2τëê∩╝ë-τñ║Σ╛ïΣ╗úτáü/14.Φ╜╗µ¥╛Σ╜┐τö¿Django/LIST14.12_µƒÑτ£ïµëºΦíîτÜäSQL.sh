$ python manage.py sqlmigrate application file_name_or_number
