"use strict";
var express = require('express');
var router = express.Router();
var salesModel = require('../models/salesModel');
var qrcodeModel = require('../models/qrcodeModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var async = require("async");


router.get('/', function (req, res, next) {
  var user = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params = {
      userId: user.id,
      corpId: user.corporation_id,
      state: 1
    };
    salesModel.getSoldRecordlist(params, function (tableData) {
      tableData.aaData && tableData.aaData.forEach(function (item) {
        item.sold_date = commonUtils.dateFormat(new Date(item.sold_date));
      });
      return res.send(tableData.aaData);
    });
  } else {
    var opt = {
      user_id: user.id,
      url: nconf.get("url:sales"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:sales"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('sales', {
      header: "销售管理"
    });
  }
});

router.get('/list', function (req, res, next) {
  var user = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = user.id;
  tableParams.corpId = user.corporation_id;
  tableParams.state = 1;
  salesModel.getSoldRecordlist(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.sold_date = commonUtils.dateFormat(new Date(item.sold_date));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {
  var corp = req.session.rcode.corporation;
  return res.render('sales/add', {
    header: "销售管理 > 申请销售",
    corpcode: corp.qrcode
  });

});


router.post('/add', function (req, res, next) {
  var qrcode_start_id = parseInt(req.body.qrcode_start);
  var qrcode_end_id = parseInt(req.body.qrcode_end);
  var apply_id = parseInt(req.body.apply_id);
  var count = qrcode_end_id - qrcode_start_id + 1;
  var params = {
    production_id: req.body.production,
    dealer_id: req.body.dealer,
    qrcode_apply_id: apply_id,
    qrcode_start_id: qrcode_start_id,
    sold_count: count,
    creator: req.session.rcode.user.id,
    status: 0,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  var corp = req.session.rcode.corporation;
  var statuscondition = "status = " + qrcodeModel.PRODUCTION_QRCODE_STATUS.packaged;
  var qrcode_prefix = corp.qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);
  var codeList = {
    startcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(qrcode_start_id) + 0, 8) + "." + 3,
    endcode: qrcode_prefix + "." + commonUtils.padZero(parseInt(qrcode_start_id + count - 1) + 0, 8) + "." + 3
  };
  qrcodeModel.getQrcodeByCode(codeList, statuscondition, function (err, tableData) {
    if (tableData.aaData.length < count) {
      return res.render('sales/add', {
        header: "销售管理 > 申请销售",
        corpcode: corp.qrcode,
        msg: messageUtils.msgError("申请销售失败,所选二维码可能已被使用")
      });
    }
    qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.saled, codeList, function (err, result) {
      if (err || !result) {
        return res.render('sales/add', {
          header: "销售管理 > 申请销售",
          corpcode: corp.qrcode,
          msg: messageUtils.msgError("申请销售失败")
        });
      } else {
        salesModel.addSoldRecord(params, function (err, soldrecordId) {
          if (err) {
            return res.render('sales/add', {
              header: "销售管理 > 申请销售",
              corpcode: corp.qrcode,
              msg: messageUtils.msgError("申请销售失败")
            });
          } else {
            var opt = {
              user_id: req.session.rcode.user.id,
              url: nconf.get("url:sales"),
              action: nconf.get("action:add"),
              operate_type: nconf.get("operate_type:sales"),
              operate_id: soldrecordId,
              content: {production_name: req.body.production_name, sold_count: count},
              state: 1,
              client_address: commonUtils.getClientIp(req)
            };
            logsModel.addOperateLog(opt);
            req.session.rcode.msg = messageUtils.msgSuccess("申请销售成功");
            return res.redirect('/work_manage/production_sales');
          }
        });
      }
    });
  });
});

router.get('/select_qrcode/:productionId', function (req, res, next) {
  var productionId = req.params.productionId;
  if (underscore.isNaN(productionId)) {
    return next(new Error("Invalid Parameters"));
  }
  return res.render('sales/select_qrcode', {
    header: "可用二维码查看",
    id: productionId,
    layout: "partial/modal_layout"
  });
});

router.get('/select_qrcode/:productionId/list', function (req, res, next) {
  var user =  req.session.rcode.user;
  var proId = req.params.productionId;
  var tableParams = dataTableObj.getParams(req);
  tableParams.productionId = proId;
  tableParams.userId = user.id;
  tableParams.status = 1;
  async.waterfall([
    function(cb){
      qrcodeModel.getProPackageList(proId, function(err, packages){
        cb(err, packages);
      });
    },
    function(packages, cb){
      qrcodeModel.getProSoldList(proId, function(err, sales){
        cb(err, packages, sales);
      });
    }
  ], function (err, packages, sales) {
    var tableData;
    if(!err){
      var obj = {};
      var obj1 = {};
      var start;
      var end;
      var key;
      var value;
      var last;

      //包装记录以 apply id分组整理成json
      packages && packages.forEach(function(item){
        key = "apply_" + item.qrcode_apply_id;
        start = item.qrcode_start_id;
        end = item.qrcode_start_id+item.package_count-1;
        if(obj[key]){
          value = obj[key];
          last = value.pop();
          if(last.end === item.qrcode_start_id - 1){
            start = last.start;
            end = item.qrcode_start_id+item.package_count-1;
          }else{
            value.push(last);
          }
        }else{
          value = [];
        }
        value.push({start:start,end:end});
        obj[key] = value;
      });

      //销售记录以 apply id分组整理成json
      sales && sales.forEach(function(item){
        key = "apply_" + item.qrcode_apply_id;
        start = item.qrcode_start_id;
        end = item.qrcode_start_id + item.sold_count - 1;
        if(obj1[key]){
          value = obj1[key];
          last = value.pop();
          if(last.end === item.qrcode_start_id - 1){
            start = last.start;
            end = item.qrcode_start_id+item.sold_count-1;
          }else{
            value.push(last);
          }
        }else{
          value = [];
        }
        value.push({start:start,end:end});
        obj1[key] = value;
      });

      var pack;
      var sale;
      var arr = [];
      var apply_id;
      var qrcode_prefix;
      var start_code;
      var end_code;
      var corporation_qrcode = req.session.rcode.corporation.qrcode;
      //根据包装记录和销售记录，将已包装，未销售的二维码段查找出来
      for(key in obj){
        pack = obj[key];
        sale = obj1[key];
        apply_id = key.split("_")[1];
        qrcode_prefix = corporation_qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);
        if(sale){
          //销售的二维码记录
          var p_start;
          var p_end;
          var s_start;
          var s_end;
          //循环每一个包装段
          pack && pack.forEach(function(p){
            p_start = p.start;
            p_end = p.end;
            var last = p_start - 1;
            var saleFlag = false;
            //循环每一个销售段
            sale.forEach(function(s, i){
              s_start = s.start;
              s_end = s.end;

              if(p_start <= s_start  && s_end <= p_end){
                //包装段中间有销售
                saleFlag = true;
                if(s_start > p_start){
                  //包装起始码 - 销售起始码
                  start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
                  end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(s_start-1), 8) + ".3";
                  arr.push({start_code:start_code,end_code:end_code});
                }
                last = s_end;
              }

              //如果有销售记录，销售结束码 - 包装结束码
              if(i == sale.length - 1 && saleFlag && s_end < p_end){
                start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(last+1), 8) + ".3";
                end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_end), 8) + ".3";
                arr.push({start_code:start_code,end_code:end_code});
              }
            });

            if(!saleFlag){
              //包装段中间没有销售
              start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_start), 8) + ".3";
              end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(p_end), 8) + ".3";
              arr.push({start_code:start_code,end_code:end_code});
            }
          });
        }else{
          //包装的二维码没有销售记录
          pack && pack.forEach(function(item){
            start_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.start), 8) + ".3";
            end_code = qrcode_prefix + "." + commonUtils.padZero(parseInt(item.end), 8) + ".3";
            arr.push({start_code:start_code,end_code:end_code});
          });
        }
      }

      var data = arr.slice(tableParams.start,tableParams.start+tableParams.length);
      tableData = {aaData:data,iTotalRecords:arr.length,iTotalDisplayRecords:arr.length};
      return res.send(tableData);
    }else{
      tableData = {aaData:[],iTotalRecords:0,iTotalDisplayRecords:0};
      return res.send(tableData);
    }
  });
});

router.get('/sold_record/:soldrecordId', function (req, res, next) {
  var recordId = req.params.soldrecordId;
  if (underscore.isNaN(recordId)) {
    return next(new Error("Invalid Parameters"));
  }
  var corp_qrcode = req.query["corp_qrcode"] || null;
  var filter_arr = req.query["filter_arr"] || null;

  return res.render('sales/sold_record', {
    header: "查看销售记录",
    recordId: recordId,
    layout: "partial/modal_layout",
    corp_qrcode:corp_qrcode,
    filter_arr:filter_arr
  });
});

router.get('/sold_record/:soldrecordId/list', function (req, res, next) {
  var recordId = req.params.soldrecordId;
  if (underscore.isNaN(recordId)) {
    return next(new Error("Invalid Parameters"));
  }
  salesModel.getSoldRecordById(recordId, function (err, rows) {
    if (err) {
      return next(err);
    } else {
      var recordList = [];
      var num = parseInt(rows.sold_count);
      var startId = parseInt(rows.qrcode_start_id);
      var corp = req.session.rcode.corporation;
      var corp_qrcode = corp && corp.qrcode ? corp.qrcode : req.query["corp_qrcode"];
      var qrcode_prefix = corp_qrcode + "." + commonUtils.padZero(parseInt(rows.qrcode_apply_id), 8);

      var filter_arr = req.query["filter_arr"] || null;
      var str = null;
      if(filter_arr){
        var filter_ids = [];
        var arr = filter_arr.split(",");
        arr.forEach(function(item){
          var start = item.split("-")[0];
          var end = item.split("-")[1];
          var obj = {
            start:qrcode_prefix + "." + commonUtils.padZero(parseInt(start) + 0, 8) + "." + 3,
            end:qrcode_prefix + "." + commonUtils.padZero(parseInt(end) + 0, 8) + "." + 3
          };
          filter_ids.push(obj);
        });

        if(filter_ids.length > 0){
          var str = " (";
          var conn = [];
          filter_ids.forEach(function(item){
            var start = item.start;
            var end = item.end;
            conn.push("(qrcode BETWEEN '"+start+"' AND '"+end+"')");
          });
          str += conn.join(" OR ");
          str += " ) ";
        }
      }

      var tableParams = dataTableObj.getParams(req);
      tableParams.startcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(startId) + 0, 8) + "." + 3;
      tableParams.endcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(startId + num - 1) + 0, 8) + "." + 3;
      tableParams.orderName = "qrcode";
      var params = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:sales"),
        action: nconf.get("action:view"),
        operate_type: nconf.get("operate_type:sales"),
        operate_id: recordId,
        content: {production_name: rows.production, sold_count: num},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(params);
      qrcodeModel.getQrcodeByCode(tableParams, str, function (err, tableData) {
        tableData.aaData && tableData.aaData.forEach(function (item) {
          item.production = rows.production;
          item.dealer_name = rows.dealer_name;
          item.sold_date = commonUtils.dateFormat(new Date(rows.sold_date));
        });
        return res.send(tableData);
      });
    }
  });
});

module.exports = router;