$(function() {

  try{
    $('#side-menu').metisMenu();
  }catch (e){

  }
  $('[data-toggle="tooltip"]').tooltip();
  //fix double active 
  // var $menu = $('#side-menu');
  // var $active = $menu.find("li.active").find("ul.collapse,.in");
  // console.log(location.pathname);
  // console.log($active.length);
  // $("a[data-url]").on("click",function(e){
  //   e.preventDefault();
  //   var $this = $(this);
  //   var _url = $this.data("url");
  //   if(!_.isEmpty(_url)){
  //     location.href = _url;   
  //   }
  // });

  

});

//Loads the correct sidebar on window load,
//collapses the sidebar on window resize.
// Sets the min-height of #page-wrapper to window size
$(function() {
  $(window).bind("load resize", function() {
    topOffset = 50;
    width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
    if (width < 768) {
      $('div.navbar-collapse').addClass('collapse');
      topOffset = 100; // 2-row-menu
    } else {
      $('div.navbar-collapse').removeClass('collapse');
    }

    height = ((this.window.innerHeight > 0) ? this.window.innerHeight : this.screen.height) - 1;
    height = height - topOffset;
    if (height < 1) height = 1;
    if (height > topOffset) {
      $("#page-wrapper").css("min-height", (height) + "px");
    }
  });

  var url = window.location;
  var href;
  var element = $('ul.sidebar-menu a').filter(function() {
    return (this.href == url || url.href.indexOf(this.href) == 0) && ($(this).attr("has-child") == '0');
  });
  element.addClass('active');
  if(element.parent().parent().is("ul.treeview-menu")){
    element.parent().parent().addClass('menu_open').parent().addClass('active');
  }
});

function getCookie(key){
  var arrStr = document.cookie.split(";");
  for(var i = 0;i < arrStr.length;i ++){
    var temp = arrStr[i].split("=");
    if(temp[0].trim() == key) {
      return temp[1]
    }
  };
}

function reqAjax(type, url, data, callback, options) {
  try {
    var tp = type || 'POST';
    $.ajax($.extend({
      type: tp,
      url: url,
      data: data,
      cache: false,
      timeout: 6000,
      success: function(data) {
        if (typeof callback == 'function') {
          callback(data);
        }
      },
      error: function() {

      }
    }, options));
  } catch (e) {

  }
}

function dialog(url, title, width, height){
  width = width || 1000;
  height = height || 430;
  var arr = [];
  arr.push('<div class="modal fade dialog" tabindex="-1" role="dialog" aria-labelledby="detail" aria-hidden="true">');
  arr.push('<div class="modal-dialog modal-lg">');
  arr.push('<div class="modal-content">');
  arr.push('<div class="modal-header">');
  arr.push('<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
  arr.push('<h4 class="modal-title" id="myModalLabel">');
  arr.push(title);
  arr.push('</h4></div>');
  arr.push('<div class="modal-body">');
  arr.push('<iframe src="'+url+'" height="'+ height +'px" width="100%" frameborder="no" border="0" allowtransparency="yes" style="background-color:transparent"></iframe>');
  arr.push('</div>');
  arr.push('<div class="modal-footer">');
  arr.push('<button type="button" class="btn btn-default" data-dismiss="modal">关闭</button></div>');
  arr.push('</div></div></div>');
  $("body").append(arr.join(" "));
  $(".dialog").modal({});
  $('.dialog').on('hidden.bs.modal', function (e) {
    $('.dialog').remove();
  });
  $(".dialog").find(".modal-dialog").css("width",width);
}

function comfirmer(info,top,width){
  /*var arr = [];
  arr.push('<div class="modal fade dialog" tabindex="-1" role="dialog" aria-labelledby="detail" aria-hidden="true">');
  arr.push('<div class="modal-dialog">');
  arr.push('<div class="modal-content">');
  arr.push('<div class="modal-header">');
  arr.push('<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
  arr.push('<h4 class="modal-title" id="myModalLabel">');
  arr.push('</h4></div>');
  arr.push('<div class="modal-body">');
  arr.push('<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>');
  arr.push(title);
  arr.push('</div>');
  arr.push('<div class="modal-footer">');
  arr.push('<button type="button" class="btn btn-default" data-dismiss="modal">关闭</button></div>');
  arr.push('</div></div></div>');
  $("body").append(arr.join(" "));
  $(".dialog").modal({});
  $('.dialog').on('hidden.bs.modal', function (e) {
    $('.dialog').remove();
  });
  $(".dialog").modal().css("padding-top",top);
  $(".dialog").find(".modal-dialog").css("width",width);*/
  swal({
    title: "错误!",
    text: info,
    type: "error",
    confirmButtonText: "确定"
  });
}

function delDialog(title, top , width, callback){
    /*top = top || 200;
    width = width || 350;
    title = title || "确定要删除吗？";
    var arr = [];
    arr.push('<div class="modal fade dialog" tabindex="-1" role="dialog" aria-labelledby="detail" aria-hidden="true">');
    arr.push('<div class="modal-dialog">');
    arr.push('<div class="modal-content">');
    arr.push('<div class="modal-header">');
    arr.push('<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
    arr.push('<h4 class="modal-title" id="myModalLabel">');
    arr.push('</h4></div>');
    arr.push('<div class="modal-body">');
    arr.push(title);
    arr.push('</div>');
    arr.push('<div class="modal-footer">');
    arr.push('<button type="button" class="btn btn-primary">确认</button>');
    arr.push('<button type="button" class="btn btn-default" data-dismiss="modal">取消</button></div>');
    arr.push('</div></div></div>');
    $("body").append(arr.join(" "));
    $(".dialog").modal({});
    $('.dialog').on('hidden.bs.modal', function (e) {
        $('.dialog').remove();
    })
    $(".dialog .btn-primary").on("click", function(){
        if(typeof callback == 'function'){
            callback();
        }
    })
    $(".dialog").modal().css("padding-top",top);
    $(".dialog").find(".modal-dialog").css("width",width);*/
  swal({
    title: "确定删除",
    text: title,
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "删除",
    cancelButtonText: "取消",
    closeOnConfirm: true
  },function(isConfirm){
    if(isConfirm){
      if(typeof callback == 'function'){
        callback();
      }
    }
  });
}

String.prototype.startWith = String.startWith || function(str) {
  if (str == null || str == "" || this.length == 0 || str.length > this.length) {
    return false;
  }
  if (this.substring(0, str.length) == str) {
    return true;
  } else {
    return false;
  }
}

String.prototype.endWith = String.endWith || function(str) {
  if (str == null || str == "" || this.length == 0 || str.length > this.length) {
    return false;
  }
  if (this.substring(this.length - str.length) == str) {
    return true;
  } else {
    return false;
  }
};