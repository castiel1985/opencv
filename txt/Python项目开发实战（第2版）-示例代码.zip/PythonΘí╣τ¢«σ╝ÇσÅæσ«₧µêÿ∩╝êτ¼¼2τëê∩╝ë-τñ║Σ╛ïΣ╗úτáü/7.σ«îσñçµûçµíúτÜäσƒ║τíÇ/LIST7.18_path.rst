================
AutoDoc范例
================

.. autofunction:: path.commonprefix
