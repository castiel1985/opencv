"use strict";
var express = require('express');
var router = express.Router();
var wapModel = require('../models/wapModel');
var messageUtils = require('../utils/Message');
var path = require('path');
var fs = require('fs'),
  nconf = require('nconf');
nconf.argv().env().file({
  file: path.join(__dirname, '../config.json')
});
var queryModel = require('../models/queryModel');
var qrcodeModel = require('../models/qrcodeModel');
var userModel = require('../models/userModel');
var transmitModel = require('../models/transmitModel');
var logger = require('../utils/winstonUtils').logger;
var commonUtils = require('../utils/Common');
var logsModel = require('../models/logsModel');
var QRcode = require('../middleware/qrcode.js');
var tabModel = require("../models/tabModel");
var async = require("async");
var productionModel = require('../models/productionModel');

router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  res.render('wap/trace', {
    layout: 'partial/wap_layout'
  });

});

router.get('/test', function(req, res, next) {
  res.render('wap/test', {
    layout: 'partial/wap_layout'
  });

});

//for public customer validate production is TRUE or FALSE
router.get('/trace/:qrcode', function (req, res, next) {
  var qrcode = req.params.qrcode;

  async.waterfall([
    function(cb){
      //验证二维码是否存在
      queryModel.getInfoByQrCode(qrcode, function (err, info) {
        if (err || !info) {
          return next(err);
        }
        if (!info.valid) {
          return res.render('wap/trace', {
            layout: 'partial/wap_layout'
          });
        } else {
          cb(err, info);
        }
      });
    },
    function(info, cb){
      if(!info.pack){//未打包的，无效二维码
        return res.render('wap/trace', {
          layout: 'partial/wap_layout'
        });
      }
      var corp = info.corp;
      queryModel.getTranRecursive(qrcode, function(err, rows){
        //得到所有运单号
        info.records = rows;
        cb(err, info);
      })
    },
    function(info, cb){
      var params = {
        scanning_times: info.valid.scanning_times + 1
      };
      //扫码次数加1
      qrcodeModel.updateCode(info.valid.qrcode, params, function (err, result) {
        if (err || !result) {
          return next(err);
        }else{
          cb(err,info);
        }
      });
    },
    function(info, cb){
      var corp = info.corp;
      productionModel.getProManuListByCorpId(corp.id, function(err, rows){
        var default_images = {};
        rows && rows.forEach(function(item){
          default_images["manu_"+item.id] = item.url;
        });
        cb(err, info, default_images);
      })
    },
    function(info, default_images, cb){
      var tab={};
      //哪些tab有权限显示
      if(info.tab){
        info.tab.forEach(function(item){
          if(item.state == 1){
            tab.none = 1;
            eval("tab."+item.tab_name+"="+item.state);
          }else{
            eval("tab."+item.tab_name+"= null");
          }
        });
      }else{
        tabModel.Initialize(info.valid.corporation_id, function(err, result){
          if(!result) {
            next("500");
          }
        });
        tab.initialize = 1;
      }

      var pack = info.pack[0];
      var proId = pack.production_id;
      var serialId = pack.serial_id;
      var subSerialId = pack.subserial_id;
      var tran = info.tran;
      var sale;
      var transmit_qrcode;

      if(info.sale){
        sale = info.sale[0];
      }

      if(tran){
        transmit_qrcode = tran[0].transmit_qrcode;
      }

      wapModel.getInfo(proId, serialId, subSerialId, qrcode, transmit_qrcode, function (err, result) {
        var mainInfo = result.mainInfo;
        var manu = mainInfo.manu;
        if(info.records){
          result.records = info.records;
        }
        manu && manu.forEach(function (item) {
          if (item.url) {
            var url = item.url.split(",");
            var urls = [];
            item.url.split(",").forEach(function (url) {
              urls.push({url: url});
            });
            item.urls = urls;
          }else{
            var default_image = default_images["manu_"+item.manufacture_id];
            if(default_image){
              var urls = [];
              default_image.split(",").forEach(function (url) {
                urls.push({url: url});
              });
              item.urls = urls;
            }
          }
          item.manu_date = commonUtils.dateFormat(item.manu_date);
        });
        cb(err, result, manu, pack, sale, tab, info.valid.scanning_times, info.valid.status, info.valid.id, info.valid.apply_id);
      });
    }
  ], function (err, result, manu, pack, sale, tab, scanning_times, status, qrcodeId, applyId) {
    if(err){
    }else{
      var production = result.pro;
      var advertisement = result.advertisement;
      var mainInfo = result.mainInfo;
      var corp = result.corp;
      var patrol = mainInfo.patrol;
      var base = mainInfo.base ? mainInfo.base[0] : "";
      var records = result.records;
      var comment = result.comment;

      advertisement && advertisement.forEach(function (item){
        item.create_time = commonUtils.dateFormat(item.create_time,"yyyy-MM-dd");
      });

      patrol && patrol.forEach(function (item) {
        if (item && item.url) {
          var url = item.url.split(",");
          var urls = [];
          item.url.split(",").forEach(function (url) {
            urls.push({url: url});
          });
          item.urls = urls;
        }
        item.patrol_date = commonUtils.dateFormat(item.patrol_date);
      });
      records && records.forEach(function (item) {
        item.scan_time = commonUtils.dateFormat(item.scan_time);
        item.scan_action = item.scan_action == 0 ? "上车" : "下车";
      });
      if(pack){
        pack.package_date = commonUtils.dateFormat(new Date(pack.package_date));
      }
      var expiry_time = new Date(pack.package_date);
      var newDate = new Date();
      if(production){
        var year = expiry_time.getFullYear();
        var month = expiry_time.getMonth();
        var day = expiry_time.getDate();
        if(production.expired_date.split(":").length > 1){
          var num =production.expired_date.split(":")[0];
          var suffix = production.expired_date.split(":")[1];
          if(suffix == 'y'){
            year = year + parseInt(num);
            production.expired_date = num + "年";
          }else if(suffix == 'm'){
            month = month + parseInt(num);
            production.expired_date = num + "月";
          }else{
            day = day + parseInt(num);
            production.expired_date = num + "天";
          }
        }
        expiry_time.setFullYear(year);
        expiry_time.setMonth(month);
        expiry_time.setDate(day);
      }
      if(expiry_time.getTime() < newDate.getTime()){//过期了
        status = (status === 2 ? "已使用" : "已过期");
        if(status !== 3){
          qrcodeModel.updateCode(qrcode, {status: qrcodeModel.PRODUCTION_QRCODE_STATUS.expire }, function (err, result) {
            if (err) {
              status = "无效";
            }
          });
        }
      }else{
        status = (status === 1 ? '未使用' : '已使用');
      }
      var comment1;
      var comment2;
      var comment3;
      var pages;
      var opt = {grade_5:0,grade_4:0,grade_3:0,grade_2:0,grade_1:0};
      if(comment.length > 2){
        comment1 = comment[0];
        comment2 = comment[1];
        comment3 = comment[2];

        opt["total_count"] = comment2[0].total_count;
        opt["average"] = comment2[0].average ? comment2[0].average.toFixed(1) : 0;

        comment3 && comment3.forEach(function(item){
          opt["grade_"+item.grade] = item.grade_count || 0;
        });
        pages = Math.ceil(opt.total_count/10);
      }

      comment1&&comment1.forEach(function(item){
        item.create_time = commonUtils.dateFormat(new Date(item.create_time));
        if(!item.linkman.trim()){
          item.linkman = "匿名用户";
        }
      });
      res.render('wap/trace', {
        production: production,
        base: base,
        manu: manu,
        patrol: patrol,
        sale: sale,
        corp: corp,
        advertisement: advertisement,
        records:records,
        qrcode:qrcode,
        qrcodeId: qrcodeId,
        applyId: applyId,
        scanning_times: scanning_times,
        status: status,
        pack:pack,
        comment:comment1,
        pages:pages,
        opt:opt,
        tab:tab,
        layout: 'partial/wap_layout'
      });
    }
  });
});

router.get('/demo', function(req, res, next) {
  res.render('wap/demo', {
    layout: 'partial/wap_layout'
  });

});

router.get('/complaint', function (req, res, next) {
  var qrcode = req.query['qrcode'];//getPackageByQrCode
  var qrcodeId = req.query['qrcodeId'];
  queryModel.getPackageByQrCode(qrcode, function(err, rows){
    if (err || !rows) {
      return next(err);
    }
    if(rows.length > 0){
      var pack = rows[0];
      var qrcode_id = qrcodeId;
      var dealer_id = pack.creator;
      var production_id = pack.production_id;
      var params = {
        production_id:production_id,
        dealer_id:dealer_id,
        qrcode_id: qrcode_id,
        type: 0,
        linkman: req.query['linkman'],
        event_content: req.query['content'],
        mobile: req.query['mobile'],
        grade: req.query['grade'],
        state: 1
      };
      wapModel.insertCustomEvent(params, function (err, result) {
        if(err || !result){
          return res.send(false);
        }else{
          return res.send(true);
        }
      });
    }
  });


});

router.get('/vip', function (req, res, next) {


  res.render('wap/index', {
    layout: 'partial/wap_layout'
  });

});


//var QRCODE_GENERATE_URL = "http://qr.liantu.com/api.php?el=l&w=200&m=10&text=";
var QRCODE_GENERATE_URL = "http://" + nconf.get("qr_service:host") + ":" + nconf.get("qr_service:port") + nconf.get("qr_service:path");

router.get('/qrcode/:code', function (req, res, next) {
  var code = req.params.code;
  var applyId = req.query['id'];
  var text;
  if(code && code.substr(-2,2) == ".3"){
    text = nconf.get("server_host") + "/wap/trace/" + code;
  }else if(code && code.split(".").length == 5){
    text = nconf.get("server_host") + "/propaganda/" + code;
  }else{
    text = code;
  }

  if(code && code.substr(-1,1) == QRcode.TYPE.TRANSMIT){
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:transmit"),
      action:nconf.get("action:download"),
      operate_type:nconf.get("operate_type:qrcode"),
      content:{qrcode:code},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
  }

  if(applyId){
    var params2 = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:qrcode"),
      action:nconf.get("action:download"),
      operate_type:nconf.get("operate_type:qrcode"),
      operate_id:applyId,
      content:{qrcode:code},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
  }

  var request_file = require('http').get(QRCODE_GENERATE_URL +  text, function (fileStream) {
    var contentType = fileStream.headers["content-type"] || "image/jpg";
    contentType = contentType.split(";")[0];
    var type = contentType.split("/").length > 1 ? contentType.split("/")[1] : "jpg";
    var filename = code + "." + type;
    res.setHeader('Content-type', contentType);
    res.set('Content-Disposition', 'attachment; filename=' + encodeURIComponent(filename));

    fileStream.pipe(res, {end: false});
    fileStream.on('end', function (err) {
      res.status(200);
      res.end();
    });

  });

  request_file.on('error', function (err) {
    logger.error('download qrcode %s error! %s', code, err.stack);
    return next(err);
  });
  request_file.end();
});

router.get('/fake_code', function(req, res, next){
  var qrcode = req.query['qrcode'];
  var fake_code = req.query['fake_code'];
  wapModel.fakeCodeConfirm(qrcode, fake_code, function(err, result){
    if(result){
      return res.send(true);
    }else{
      return res.send(false);
    }
  });
});

router.get('/comment', function (req, res, next) {
  var qrcode = req.query['qrcode'];
  var proId = req.query['proId'];
  var page = req.query['page'];
  var start = (parseInt(page)-1)*10;

  wapModel.getCommentsByProId(proId, start, 10, function(err,comment){
    if(comment && comment.length>0){

      var opt = {grade_5:0,grade_4:0,grade_3:0,grade_2:0,grade_1:0};
      if(comment.length > 2){
        var result = [];
        var comment1 = comment[0];
        var comment2 = comment[1];
        var comment3 = comment[2];

        opt["total_count"] = comment2[0].total_count;
        opt["average"] = comment2[0].average ? comment2[0].average.toFixed(1) : 0;

        comment3 && comment3.forEach(function(item){
          opt["grade_"+item.grade] = item.grade_count || 0;
        });
        comment1&&comment1.forEach(function(item){
          item.create_time = commonUtils.dateFormat(new Date(item.create_time));
          if(!item.linkman.trim()){
            item.linkman = "匿名用户";
          }
        });
        var pages = Math.ceil(opt.total_count/10);
        result = [pages,opt,comment[0]];
        res.send(result);
      }else{
        comment[0] && comment[0].forEach(function(item){
          item.create_time = commonUtils.dateFormat(new Date(item.create_time));
        });
        res.send([0,null,comment[0]]);
      }

    }else{
      res.send(null);
    }
  });
});

router.get('/app/download', function(req, res, next){
  var dir = path.join(__dirname, "../public/application/");
  var fileName = "app-release.apk";
  fs.exists(dir+fileName, function (exists) {
    if (exists) {
      res.download(dir + fileName, fileName);
    }else{
      return res.redirect('/?code=FILE_ERROR');
    }
  });
});

router.post('/transmit_add', function(req, res, next) {
  var productionId = req.body.productionId;
  var corpId = req.body.corpId;
  var qrcode = req.body.qrcode;
  var applyId = req.body.applyId;
  var corp_qrcode = req.body.corpQrcode;
  var soldRecord = [];
  var codeList = {
    startcode: qrcode,
    endcode: qrcode
  };
  userModel.getUsersByCorpId(corpId, null, function(err, userList){
    if(err ||  userList.length < 1){
      return res.send(false);
    }
    var params = {
      creator: userList[0].id,//0 系统
      sender: req.body.sender,
      sender_phone: req.body.sender_phone,
      departure: req.body.departure,
      destination: req.body.destination,
      receiver: req.body.receiver,
      receiver_phone: req.body.receiver_phone,
      sold_records: null,
      status: transmitModel.TRANSMIT_QRCODE_STATUS.no_send,
      client_address: commonUtils.getClientIp(req)
    };
    params.transmit_qrcode = QRcode.getTransmitCodeBySerial(commonUtils.date2Long(new Date()), qrcode, params.creator, corp_qrcode);
    queryModel.validQrCode(qrcode, function(err, codeInfo){
      if(err || codeInfo.status !== 1){
        return res.send(false);
      }
      transmitModel.newRecord(params, function (err, transmitId) {
        if (err) {
          return res.send(false);
        } else {
          qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.saled, codeList, function (err, result) {
            if(err){
              return res.send(false);
            }else{
              soldRecord = "("+transmitId+",null,"+productionId+","+applyId+",'"+parseInt(qrcode.split(".")[6])+"',1)";
              transmitModel.addSoldRecord(soldRecord,function (err, planRecordId){
                if(err){
                  return res.send(false);
                }
                return res.send(true);
              });
            }
          });
        }
      });
    });
  });
});

module.exports = router;
