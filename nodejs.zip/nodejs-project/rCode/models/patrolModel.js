"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;
var async = require('async');

function getPatrolList(tableParams, callback) {
  var sqlData = "select c.*, c.serial_id, a.name as production_name ,b.serial_no, ifnull(d.serial_no,'公用') as sub_serial_no from qr_production a, qr_serials b, qr_serials_patrol_info c left join qr_serials d on d.id = c.sub_serial_id " +
    "where a.id = b.production_id and c.state = :state  and b.id = c.serial_id " +
    "and b.id=:serialId ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_serials_patrol_info WHERE serial_id = :serialId AND state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true;
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.orderName == "desc"){
    orderStr = " ORDER BY c." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " and c.sub_serial_no like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_serials_patrol_info WHERE serial_id = :serialId AND state = :state AND sub_serial_no like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function addPatrol(params, callback) {
  var sql = 'INSERT INTO qr_serials_patrol_info (`sub_serial_id`,' +
    ' `serial_id`, ' +
    ' `creator`, ' +
    ' `desc`, ' +
    ' `state`,' +
    ' `client_address`) values ' +
    '(:sub_serial_id,' +
      ':serial_id,' +
      ':creator,' +
      ':desc,' +
      ':state,' +
      ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var patrolId = result.insertId;
    logger.info("added patrol id = %d", patrolId);

    if(params.pictureFiles) {
      params.pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = params.creator;
        item.type = 'patrol_picture_' + patrolId;
        commonModel.insertFiles(item, null);
      });
    }

    if(params.uploadedFileVideo) {
      params.uploadedFileVideo.forEach(function (item) {
        //insetrt to file
        item.creator = params.creator;
        item.type = 'patrol_video_' + patrolId;
        commonModel.insertFiles(item, null);
      });
    }
    return callback(null, patrolId);
  });

}



function updatePatrol(params, callback) {
  var sql = 'UPDATE qr_serials_patrol_info SET `sub_serial_id` =:sub_serial_id,' +
    ' `desc` =:desc,' +
    ' `creator` =:creator ' +
    'where id =:id';
  database.query({
    sql:sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      var patrolId = params.id;
      if(params.pictureFiles) {
        params.pictureFiles.forEach(function (item) {
          //insetrt to file
          item.creator = params.creator;
          item.type = 'patrol_picture_' + patrolId;
          commonModel.insertFiles(item, null);
        });
      }
      if (result.affectedRows) {
        return callback(null, patrolId);
      } else {
        return callback(null, null);
      }
    }
  });
}

function getPatrolById(patrolId, callback) {
  database.query({
    sql: "SELECT a.*,IFNULL(b.serial_no,'公用') AS sub_serial_no FROM qr_serials_patrol_info a LEFT JOIN qr_serials b ON b.id = a.sub_serial_id WHERE a.id =:patrolId and a.state = 1",
    params: {
      "patrolId": patrolId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE (type =:pictureType or type =:videoType) and state = 1",
        params: {
          "pictureType": "patrol_picture_" + patrolId,
          "videoType": "patrol_video_" + patrolId
        }
      }, function(err, rows2){
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = [];
        row.videoFiles = [];
        if(!!rows2 && rows2.length > 0){
          rows2.forEach(function(item){
            if(item.type.indexOf("patrol_picture_") >= 0 ){
              row.pictureFiles.push(item);
            }
            if(item.type.indexOf("patrol_video_") >= 0 ){
              row.videoFiles.push(item);
            }
          });
        }
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }
  });
}

function delPatrolById(patrolId, callback){
    database.query({
        sql: "UPDATE qr_serials_patrol_info SET state = 0 WHERE id =:id",
        params: {
            "id": patrolId
        }
    }, function(err, result) {
        if (err) {
            logger.error(err ? err.stack : "row is null");
            return callback(new global.ServerError("Can't connect MySQL"), null);
        }else if (result.affectedRows) {
            return callback(null, true);
        } else {
            return callback(null, null);
        }
    });
}


exports.getPatrolList = getPatrolList;
exports.addPatrol = addPatrol;
exports.updatePatrol = updatePatrol;
exports.getPatrolById = getPatrolById;
exports.delPatrolById = delPatrolById;

