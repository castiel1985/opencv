"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require("./commonModel.js");

var models = {};

models.TRANSMIT_QRCODE_STATUS = {
  no_send: 0,
  sending: 1,
  received: 2
};

/**
 * status 未发货 0 /物流中 1/已收货 2
 * @param status
 * @param callback
 */

models.getTransmitList = function(tableParams, callback) {
  var sqlData = "SELECT a.* FROM qr_transmit a,qr_user b,qr_corporation c" +
    " WHERE a.creator =b.id and c.id = b.corporation_id and ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) and a.state =:state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_transmit a,qr_user b,qr_corporation c WHERE a.creator =b.id and c.id = b.corporation_id and ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and (receiver like :search OR destination like :search OR sender like :search) " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_transmit a,qr_user b,qr_corporation c WHERE a.creator =b.id and c.id = b.corporation_id and ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) and a.state =:state AND (receiver like :search OR destination like :search OR sender like :search) ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
};

models.getTransmitById = function(transmitId, callback) {
  database.query({
    sql: "SELECT * FROM qr_transmit " +
    " WHERE id =:id and state = 1",
    params: {
      "id": transmitId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
};

models.updateTransmitById = function(transmitId, params,  callback) {
  var sql_head = "UPDATE qr_transmit SET ";
  var colums = [];
  for(var key in params){
    colums.push("`"+key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + transmitId;
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
};

models.newRecord = function(options, callback) {
  var sql_head = "insert into qr_transmit (";
  var colums = [];
  var params = [];
  for(var key in options){
    colums.push(key);
    params.push(":" + key);
  }
  var sql = sql_head + colums.join(',') + " ) values (" + params.join(',') + ")";
  database.query({
    sql:sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var transmitId = result.insertId;
    logger.info("update transmit id = %d", transmitId);
    return callback(null, transmitId);
  });

};


models.newScanRecord = function(options, callback) {
  var sql_head = "INSERT INTO qr_transmit_record (";
  var colums = [];
  var params = [];
  for(var key in options){
    colums.push(key);
    params.push(":" + key);
  }
  var sql = sql_head + colums.join(',') + " ) values (" + params.join(',') + ")";
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var scanId = result.insertId;
    logger.info("added scan transmit record id = %d", scanId);
    return callback(null, scanId);
  });
};

models.getTransmitRecordByCode = function(qrcode, callback) {
  database.query({
    sql: "SELECT * FROM qr_transmit" +
    " WHERE transmit_qrcode =:transmit_qrcode and state = :state",
    params: {
      "transmit_qrcode": qrcode,
      "state":1
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
};

models.getScanRecordByCode = function(qrcode, callback) {
  database.query({
    sql: "SELECT a.*,b.name FROM qr_transmit_record a, qr_user b WHERE b.id = a.scan_user AND a.transmit_qrcode =:transmit_qrcode order by a.scan_time asc",
    params: {
      "transmit_qrcode": qrcode
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
};


models.addTransmitPlan = function(params, callback){
  var sql = "INSERT INTO qr_transmit_plan (`transmit_id`,`destination`,`sold_records`,`creator` ,`client_address`) values " +
    "(:transmit_id,:destination,:sold_records,:creator,:client_address)";
  database.query({
    sql: sql,
    params:params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var planId = result.insertId;
    logger.info("added scan transmit record id = %d", planId);
    return callback(null, planId);
  });
};

models.getTransmitPlanByTransmitId = function (transmitId, callback){
  database.query({
    sql: "SELECT * FROM qr_transmit_plan WHERE transmit_id =:transmit_id and state = 1",
    params: {
      "transmit_id": transmitId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.getTransmitListByCorpId = function(corpId, callback){
  database.query({
    sql: "SELECT a.sold_records FROM qr_transmit a,qr_user b WHERE b.id = a.creator and b.corporation_id =:corpId  and a.state = 1 and plan_id = 0 ",
    params: {
      "corpId": corpId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.delTransmitPlanByTransmitId = function(transmitId, callback){
  database.query({
    sql: "UPDATE qr_transmit_plan SET state = 0 where transmit_id =:transmitId ",
    params: {
      transmitId:transmitId
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

models.getTransmitPlanById = function(planId, callback){
  database.query({
    sql: "SELECT * FROM qr_transmit_plan WHERE id =:id and state = 1",
    params: {
      "id": planId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows[0]);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

models.getTransmitByPlanId = function(planId, callback){
  database.query({
    sql: "SELECT * FROM qr_transmit WHERE plan_id =:planId and state = 1",
    params: {
      "planId": planId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.addSoldRecord = function (values, callback){
  var sql = "INSERT INTO qr_transmit_plan_record (`transmit_id`,`plan_id`,`production_id`,`apply_id`,`qrcode_start`,`sold_count` ) values " + values;
  database.query({
    sql: sql
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var planRecordId = result.insertId;
    logger.info("added scan transmit record id = %d", planRecordId);
    return callback(null, planRecordId);
  });
}

models.getPlanRecordListByCorpId = function (corpId, callback){
  database.query({
    sql: "SELECT c.* FROM qr_transmit a,qr_user b ,qr_transmit_plan_record c WHERE a.id = c.transmit_id and b.id = a.creator and b.corporation_id =:corpId  and a.state = 1 and a.plan_id = 0  order by c.apply_id, c.qrcode_start",
    params: {
      "corpId": corpId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.getPlanRecordListByTransmitId = function (transmitId, callback){
  database.query({
    sql: "SELECT * from qr_transmit_plan_record  WHERE transmit_id =:transmitId and state = 1 order by apply_id, qrcode_start",
    params: {
      "transmitId": transmitId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}


models.updatePlanRecordByTransmitId =function(transmitId, callback){
  database.query({
    sql: "UPDATE qr_transmit_plan_record SET state = 0 where transmit_id =:transmitId ",
    params:{transmitId: transmitId}
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

models.getPlanRecordListByTransmitPlan = function (transmitId, callback){
  database.query({
    sql: "SELECT b.destination,a.* from qr_transmit_plan_record a,qr_transmit_plan b WHERE a.plan_id = b.id and  b.transmit_id =:transmitId and a.state = 1 order by a.apply_id, a.qrcode_start",
    params: {
      "transmitId": transmitId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.getPlanRecordListByPlanId = function (planId, callback){
  database.query({
    sql: "SELECT * from qr_transmit_plan_record  WHERE plan_id =:planId and state = 1 order by apply_id, qrcode_start",
    params: {
      "planId": planId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.getPlanRecordListByPlanTransmit = function (planId, callback){
  database.query({
    sql: "SELECT a.* from qr_transmit_plan_record a,qr_transmit b WHERE b.plan_id =:planId and  a.transmit_id = b.id and b.state = 1 order by a.apply_id, a.qrcode_start",
    params: {
      "planId": planId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {

      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

models.getPlanRecordListByTransmitRecordId = function (recordId, action, callback){
  var sql = "SELECT c.*,d.name AS production_name FROM qr_transmit_record a ";
  if(action == "0"){
    sql += "LEFT JOIN qr_transmit b ON b.transmit_qrcode = a.transmit_qrcode AND a.plan_id IS NULL LEFT JOIN qr_transmit_plan_record c ON c.transmit_id = b.id LEFT JOIN qr_production d ON d.id = c.production_id ";
  } else{
    sql += "LEFT JOIN qr_transmit_plan b ON b.id = a.plan_id LEFT JOIN qr_transmit_plan_record c ON c.plan_id = b.id LEFT JOIN qr_production d ON d.id = c.production_id ";
  }
  sql += " WHERE a.id = :recordId ORDER BY c.production_id,c.apply_id";
  database.query({
    sql: sql,
    params: {
      "recordId": recordId
    }
  }, function(err, rows) {
    if (err) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows && rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

module.exports = models;