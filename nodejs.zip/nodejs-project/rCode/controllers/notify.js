"use strict";
var express = require('express');
var router = express.Router();
var messageUtils = require('../utils/Message');


router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req,res);

  res.render('notify',{header:"系统提示"});
});

router.get('/noauth', function(req,res,next) {
  return res.render("noauth");
});


module.exports = router;