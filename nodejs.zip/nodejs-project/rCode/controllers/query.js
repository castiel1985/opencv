"use strict";
var express = require('express');
var router = express.Router();
var logger = require('../utils/winstonUtils').logger;
var queryModel = require('../models/queryModel');
var messageUtils = require('../utils/Message');
var commonUtils = require('../utils/Common');
var corpModel = require('../models/corpModel');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var productionModel = require('../models/productionModel');
var dataTableObj = require('../middleware/dataTableObject');
var async = require("async");
var serialManuModel = require('../models/serialManufactureModel');

router.get('/', function(req, res, next) {

  messageUtils.getSessionMsg(req, res);
  var qrcode = req.session.rcode.qrcode || "";
  var opt = {
    user_id:req.session.rcode.user.id,
    url:nconf.get("url:query"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:query"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  return res.render('query/result', {
    header: "数据查询",
    search: false,
    qrcode:qrcode,
    advanceFlag:false
  });
});

router.get('/bk', function(req, res, next) {
  return res.render('query/result_bk', {
    header: "数据查询"
  });
});

router.get('/search', function(req, res, next) {
  return res.redirect('/data_query');
});

router.post("/search", function(req, res, next){
  var advanceFlag = req.body.advance_flag;
  var usr = req.session.rcode.user;
  // 0:二维码搜索  1:高级搜索
  var params={};
  if(advanceFlag == "0"){
    var qrcode = req.body.qrcode;
    if(!qrcode){
      req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在或未销售");
      return res.redirect('/data_query');
    }
    params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:query"),
      action:nconf.get("action:search"),
      operate_type:nconf.get("operate_type:query"),
      content:{qrcode:req.body.qrcode},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);

    async.waterfall([
      function(cb){
        queryModel.getInfoByQrCode(qrcode, function(err, info){
          cb(err, info);
        });
      },
      function(info, cb){
        if(!info){
          req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在或未包装");
          req.session.rcode.qrcode = qrcode;
          return res.redirect('/data_query');
        }
        if(!info.valid){
          req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在");
          req.session.rcode.qrcode = qrcode;
          return res.redirect('/data_query');
        }
        if(usr && !usr.isSupervisor && usr.corporation_id && usr.corporation_id != info.valid.corporation_id){
          req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在或没有权限");
          req.session.rcode.qrcode = qrcode;
          return res.redirect('/data_query');
        }
        if(!info.pack || info.pack.length <= 0){
          req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在或没有权限");
          req.session.rcode.qrcode = qrcode;
          return res.redirect('/data_query');
        }

        var sale = info.sale;
        var pack = info.pack;
        var apply = info.apply;
        var tran = info.tran;
        var corp = info.corp;
        var serialId = pack[0].serial_id;
        var subSerialId = pack[0].subserial_id;
        var corp_qrcode = apply[0].corp_qrcode;

        if(sale && sale[0] && sale[0].creator != usr.id && !usr.isSupervisor){
          req.session.rcode.msg = messageUtils.msgSuccess("二维码不存在或没有权限");
          req.session.rcode.qrcode = qrcode;
          return res.redirect('/data_query');
        }

        var opt = {serialId:serialId,subSerialId:subSerialId,state:1};
        queryModel.getMainInfo(opt, function(err, info){
          info.sale = sale;
          info.pack = pack;
          info.apply = apply;
          info.approve = apply;
          info.tran = tran;
          if(corp && corp.manu_sort_flag){
            info.corp = corp;
          }
          cb(err, info, corp_qrcode);
        });
      },
      function(info,corp_qrcode, cb){
        queryModel.sortInfo(info, corp_qrcode, serialId, function(err, rows){
          cb(err, rows);
        });
      }
    ], function (err, rows) {
      if(!err){
        return res.render('query/result', {
          header: "数据查询",
          rows:rows,
          qrcode:qrcode,
          search:true,
          advanceFlag:false
        });
      }else{
        req.session.rcode.msg = messageUtils.msgSuccess("数据查询有误");
        req.session.rcode.qrcode = qrcode;
        return res.redirect('/data_query');
      }

    });
  }else{
    var corpId = req.body.corporation_id;
    var proId = req.body.production_id;
    var serialId = req.body.serial_id;
    var subSerialId = req.body.subserial_id;
    var corpName = req.body.corporation_name;
    var proName = req.body.production_name;
    var serialName = req.body.serial_name;
    var subSerialName = req.body.subserial_name;

    var opt = {
      corpId:corpId,
      proId:proId,
      serialId:serialId,
      subSerialId:subSerialId,
      corpName:corpName,
      proName:proName,
      serialName:serialName,
      subSerialName:subSerialName
    };

    params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:query"),
      action:nconf.get("action:search"),
      operate_type:nconf.get("operate_type:query"),
      content:{
        corporation_name:corpName,
        production_name:proName,
        serial_name:serialName,
        sub_serial_name:subSerialName
      },
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);

    async.waterfall([
      function(cb){
        corpModel.getCorpById(corpId, function(err, corp){
          cb(err, corp);
        });
      },
      function(corp, cb){
        queryModel.getAdvanceColumns(function(err, rows){
          cb(err, corp, rows);
        });
      }
    ], function (err, corp, rows) {
      if(!err){
        return res.render('query/result', {
          header: "数据查询",
          rows:rows,
          qrcode:qrcode,
          search:false,
          advanceFlag:true,
          advanceOpt:opt,
          corp_qrcode:corp.qrcode
        });
      }else{
        req.session.rcode.msg = messageUtils.msgSuccess("数据查询有误");
        req.session.rcode.qrcode = qrcode;
        return res.redirect('/data_query');
      }
    });

  }
});

router.get('/search/tran', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getTranInfo(tableParams,function(tableData){
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/search/sale', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getSaleInfo(tableParams,function(tableData){
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.sold_date = commonUtils.dateFormat(new Date(item.sold_date));
    });
    return res.send(tableData);
  });
});

router.get('/search/package', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getPackageInfo(tableParams,function(tableData){
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.package_date = commonUtils.dateFormat(new Date(item.package_date));
    });
    return res.send(tableData);
  });
});

router.get('/search/apply', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getApplyInfo(tableParams,function(tableData){
    var apply_ids = [];
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.apply_time = commonUtils.dateFormat(new Date(item.apply_time));
      apply_ids.push(item.id);
    });
    var arr=[];
    apply_ids.forEach(function(apply_id){
      arr.push("(SELECT create_time FROM qr_code WHERE apply_id = " + apply_id + " LIMIT 1)");
    });
    var sql = arr.join(" UNION ");
    queryModel.geResultBySql(sql, function(err, rows){
      tableData && tableData.aaData && tableData.aaData.forEach(function(item,i){
        item.approve_time = commonUtils.dateFormat(new Date(rows[i].create_time));
      });
      return res.send(tableData);
    })
  });
});

router.get('/search/report', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getSerialsReportInfo(tableParams,function(tableData){
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.report_date = commonUtils.dateFormat(new Date(item.report_date));
    });
    return res.send(tableData);
  });
});

router.get('/search/patrol', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.serialId = serialId;
  tableParams.subSerialId = subSerialId;
  queryModel.getSerialsPatrolInfo(tableParams,function(tableData){
    tableData && tableData.aaData && tableData.aaData.forEach(function(item){
      item.patrol_date = commonUtils.dateFormat(new Date(item.patrol_date));
    });
    return res.send(tableData);
  });
});

router.get('/search/manu', function(req, res, next) {
  var serialId = req.query['serialId'];
  var subSerialId = req.query['subSerialId'];
  var corpId = req.query['corpId'];

  corpModel.getCorpById(corpId, function(err, corp){
    var tableParams = dataTableObj.getParams(req);
    tableParams.state = 1;
    tableParams.serialId = serialId;
    tableParams.subSerialId = subSerialId;
    tableParams.status = 1;
    queryModel.getSerialsManuInfo(tableParams,function(tableData){
      tableData && tableData.aaData && tableData.aaData.forEach(function(item){
        item.manu_date = commonUtils.dateFormat(new Date(item.manu_date));
      });
      return res.send(tableData);
    });
  })

});

router.get('/corporations', function(req, res, next) {
  var usr = req.session.rcode.user;
  corpModel.getCorpsByUserRole(usr, function(err,rows){
    return res.send(rows);
  });
});

router.get('/productions/:corpId', function(req, res, next) {
  var corpId = req.params.corpId;
  var usr = req.session.rcode.user;
  var params={
    user:usr,
    userId:usr.id,
    corpId:corpId,
    state:1
  };
  if(usr.isSupervisor){
    queryModel.getProductionList(params, function(err, tableData) {
      return res.send(tableData);
    });
  }else{
    productionModel.getProductionList(params, function(err, tableData) {
      return res.send(tableData);
    });
  }

});

router.get('/serials/:proId', function(req, res, next) {
  var proId = req.params.proId;
  var params={
    user:req.session.rcode.user,
    proId:proId,
    state:1
  };
  queryModel.getSerialsList(params, function(err, tableData) {
    return res.send(tableData);
  });
});
module.exports = router;