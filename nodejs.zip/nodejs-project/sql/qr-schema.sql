#sequence
drop table if exists `qr_seq_common`;
CREATE TABLE `qr_seq_common` (
  `user_id` bigint(11) NOT NULL,
  `seq_name` varchar(50) NOT NULL,
  `current_val` bigint(11) NOT NULL,
  `increment_val` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`seq_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `qr_seq_code_section`;
CREATE TABLE `qr_seq_code_section` (
  `user_id` bigint(11) NOT NULL,
  `code_start` bigint(11) NOT NULL,
  `code_end` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#区域字典表
drop table if exists `qr_dic_region`;
CREATE TABLE `qr_dic_region` (
  `code` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(80) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#用户表
drop table if exists `qr_user`;
CREATE TABLE `qr_user` (
  `id` BIGINT(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(20) NOT NULL DEFAULT '',
  `name` VARCHAR(20) NOT NULL DEFAULT '',
  `corporation_id` bigint(20) DEFAULT NULL,
  `passwd` VARCHAR(80) NOT NULL DEFAULT '',
  `salt` VARCHAR(10) NOT NULL DEFAULT '',
  `mail` VARCHAR(50) DEFAULT '',
  `mobile_phone` VARCHAR(15) DEFAULT '',
  `status` BIGINT(20) DEFAULT 1 COMMENT '未审批0,已审批1,拒绝审批2,禁用3',
  `state` BOOLEAN DEFAULT false,
  `client` SMALLINT NOT NULL DEFAULT 0 COMMENT '通用0,app端1,web端2',
  `create_date` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_user`  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#APP登录之后存储的token
drop table if exists `qr_user_token`;
CREATE TABLE `qr_user_token` (
  `id` BIGINT(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(20) NOT NULL DEFAULT '',
  `user_id` BIGINT(11) NOT NULL ,
  `token` VARCHAR(50) NOT NULL DEFAULT '',
  `expired_date` VARCHAR(50) DEFAULT '',
  `create_date` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_user_token`  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#角色表
drop table if exists `qr_role`;
CREATE TABLE `qr_role` (
  `id` BIGINT(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL DEFAULT '',
  `identity` varchar(10)  DEFAULT NULL,
  `desc` varchar(50) DEFAULT '',
  `state` BOOLEAN DEFAULT false,  
  `create_date` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  `corporation_id` BIGINT(20) DEFAULT NULL,
  constraint `pk_role`  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#权限表
drop table if exists `qr_permissions`;
CREATE TABLE `qr_permissions` (
  `id` BIGINT(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL DEFAULT '',
  `url` VARCHAR(50) NOT NULL DEFAULT '',
  `identity` VARCHAR(50) NOT NULL DEFAULT '',
  `parent_id` BIGINT ,
  `ancestor_ids` VARCHAR(20)  DEFAULT '' ,
  `weight` smallint NOT NULL DEFAULT 0,
  `icon` VARCHAR(20) NOT NULL DEFAULT '',
  `state` BOOLEAN DEFAULT false,
  `has_child` smallint(6) DEFAULT '0' COMMENT '1：有子菜单，0：无子菜单',
  `create_date` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_permissions`  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#user-role
# type = user/group
drop table if exists `qr_auth`;
CREATE TABLE `qr_auth` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `role_ids` varchar(100) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  constraint `pk_auth`   PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;

#role-permissions
drop table if exists `qr_role_permission`;
CREATE TABLE `qr_role_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL,
  `permission_id` bigint(20) DEFAULT NULL,
  constraint `pk_role_permission`   PRIMARY KEY (`id`),
  UNIQUE KEY `unique_qr_role_permission` (`role_id`,`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;


#文件表
drop table if exists `qr_file`;
CREATE TABLE `qr_file` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `url` VARCHAR(200) DEFAULT '',
  `type` VARCHAR(50) DEFAULT '', #production,brand etc.
  `mime` VARCHAR(20) DEFAULT '',
  `creator` BIGINT(20) DEFAULT NULL,
  `state` BOOLEAN DEFAULT false,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_file` PRIMARY KEY (`id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#品牌表
drop table if exists `qr_brand`;
CREATE TABLE `qr_brand` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) DEFAULT '',
  `desc` VARCHAR(4000) DEFAULT '',
  `logo_file_id` BIGINT(20) DEFAULT NULL COMMENT '指向qr_file表',
  `attachment_file_id` BIGINT(20) DEFAULT NULL COMMENT '指向qr_file表',
  `other` VARCHAR(4000) DEFAULT '',
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_brand` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#区域品牌表
drop table if exists `qr_region`;
CREATE TABLE `qr_region` (
  `code` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(80) NOT NULL DEFAULT '',
  `grade` TINYINT(1) DEFAULT NULL,
  `parent_code` VARCHAR(20) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `qr_region_brand`;
CREATE TABLE `qr_region_brand` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `region_id` varchar(50) NOT NULL DEFAULT '',
  `brand_id` BIGINT(20),
  `production_id` BIGINT(20),
  `status` SMALLINT(6) DEFAULT NULL COMMENT '未审核 0 /审核通过 1/审核不通过 2',
  `state` BOOLEAN DEFAULT false,
  `apply_user_id` BIGINT(20) DEFAULT NULL,
  `superior_user_id` BIGINT(20) DEFAULT NULL,
  `apply_time` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_region_brand` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#企业信息表
drop table if exists `qr_corporation`;
CREATE TABLE `qr_corporation` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `superior_id` BIGINT(20) DEFAULT NULL,
  `name` VARCHAR(50) DEFAULT '',
  `region_id` VARCHAR(50) DEFAULT NULL,
  `qrcode` VARCHAR(255) DEFAULT '',
  `is_show_anti_fake` BOOLEAN DEFAULT NULL,
  `contact` VARCHAR(15) DEFAULT '',
  `telephone` VARCHAR(100) DEFAULT '',
  `email` VARCHAR(40) DEFAULT '',
  `address` VARCHAR(100) DEFAULT '',
  `desc`  varchar(4000) NULL DEFAULT '' ,
  `video_id`  bigint(20) NULL DEFAULT NULL COMMENT '指向qr_file表' ,
  `state` BOOLEAN DEFAULT false,
  `share` BOOLEAN DEFAULT true,
  `is_auto_approve` BOOLEAN DEFAULT false COMMENT '自动审批true,手动审批false',
  `manu_sort_flag` BOOLEAN DEFAULT false COMMENT '生产加工过程是否有顺序限制',
  `creator` BIGINT(20) UNSIGNED DEFAULT NULL,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_corporation` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#产品信息表
drop table if exists `qr_production`;
CREATE TABLE `qr_production` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `brand_id` BIGINT(20) DEFAULT NULL,
  `parent_id` BIGINT(20) DEFAULT NULL,
  `name` VARCHAR(100) DEFAULT '',
  `category` VARCHAR(100) DEFAULT '',
  `short_name` VARCHAR(50) DEFAULT '',
  `pinyin` VARCHAR(20) DEFAULT '',
  `clazz` VARCHAR(20) DEFAULT '',
  `standard` VARCHAR(20) DEFAULT '',
  `unit` VARCHAR(20) DEFAULT '',
  `count` FLOAT(9,3) DEFAULT NULL,
  `identity` VARCHAR(100) DEFAULT '' COMMENT '产品代码',
  `status` SMALLINT(6) DEFAULT NULL COMMENT '产品类型，标志产品是半成品、成品等',
  `expired_date` VARCHAR(20) DEFAULT '' COMMENT '产品有效期' ,
  `attribute` VARCHAR(1000) DEFAULT '' COMMENT '产品属性，存键值对，用\",\"分割',
  `desc` VARCHAR(4000) DEFAULT '',
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL, 
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_production` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#经销商管理表
drop table if exists `qr_production_dealer`;
CREATE TABLE `qr_production_dealer` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `region_id` VARCHAR(50) DEFAULT NULL,
  `name` VARCHAR(50) DEFAULT '',
  `type` SMALLINT(6) DEFAULT NULL COMMENT '高 中 低',
  `address` VARCHAR(50) DEFAULT '',
  `location` VARCHAR(100) DEFAULT '' COMMENT '地图定位，存经纬度',
  `note` VARCHAR(4000) DEFAULT '',
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL, 
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_production_dealer` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#生产/加工类型管理表
drop table if exists `qr_manufacture`;
CREATE TABLE `qr_manufacture` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) DEFAULT '',
  `type` SMALLINT(6) DEFAULT NULL COMMENT '生产/加工',
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL,
  `corporation_id` BIGINT(20) DEFAULT NULL,
  `sort` BIGINT(20) DEFAULT NULL,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_manufacture` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#生产基地管理
drop table if exists `qr_production_base`;
CREATE TABLE `qr_production_base` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) DEFAULT '',
  `desc` VARCHAR(4000) DEFAULT '',
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL, 
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_production_base` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#批次管理表
drop table if exists `qr_serials`;
CREATE TABLE `qr_serials` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `production_id` BIGINT(20) DEFAULT NULL,
  `parent_serial_id` BIGINT(20) DEFAULT NULL,
  `serial_no` VARCHAR(50) DEFAULT '',
  `base_id` BIGINT(20) DEFAULT '-1' COMMENT '生产基地',
  `is_anti_fake` BOOLEAN DEFAULT false,
  `state` BOOLEAN DEFAULT false,
  `creator` BIGINT(20) DEFAULT NULL, 
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_serials` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#巡检信息表
drop table if exists `qr_serials_patrol_info`;
CREATE TABLE `qr_serials_patrol_info` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sub_serial_id` INT(11) NULL DEFAULT NULL,
  `serial_id` INT(11) NULL DEFAULT NULL,
  `patrol_date` TIMESTAMP default CURRENT_TIMESTAMP,
  `desc` VARCHAR(4000) DEFAULT '',
  `patrol_image_id` BIGINT(20) DEFAULT NULL,
  `patrol_vedio_id` BIGINT(20) DEFAULT NULL,
  `creator` BIGINT(20) DEFAULT NULL, 
  `state` BOOLEAN DEFAULT false,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_serials_patrol_info` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#检验检测报告表
drop table if exists `qr_serials_test_report`;
CREATE TABLE `qr_serials_test_report` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sub_serial_id` INT(11) NULL DEFAULT NULL,
  `serial_id` INT(11) NULL DEFAULT NULL,
  `report_date` TIMESTAMP default CURRENT_TIMESTAMP,
  `title` VARCHAR(100) DEFAULT '',
  `desc` VARCHAR(4000) DEFAULT '',
  `report_image_id` BIGINT(20) DEFAULT NULL,
  `creator` BIGINT(20) DEFAULT NULL, 
  `state` BOOLEAN DEFAULT false,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_serials_test_report` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




#生产加工信息表
drop table if exists `qr_serials_manufacture`;
CREATE TABLE `qr_serials_manufacture` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sub_serial_id` INT(11) NULL DEFAULT NULL,
  `serial_id` INT(11) NULL DEFAULT NULL,
  `manufacture_id` BIGINT(20) DEFAULT NULL COMMENT '指向qr_manufacture',
  `manu_date` TIMESTAMP default CURRENT_TIMESTAMP,
  `desc` VARCHAR(4000) DEFAULT '',
  `manu_image_id` BIGINT(20) DEFAULT NULL,
  `manu_vedio_id` BIGINT(20) DEFAULT NULL,
  `creator` BIGINT(20) DEFAULT NULL,
  `state` BOOLEAN DEFAULT false,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_serial_manufacture` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#产品信息表
DROP TABLE IF EXISTS `qr_industry`;
CREATE TABLE `qr_industry` (
  `code` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(80) NOT NULL DEFAULT '',
  `grade` tinyint(1) DEFAULT '0',
  `desc` varchar(4000) NOT NULL DEFAULT '',
  `parent_code` varchar(20) DEFAULT '',
  `state` tinyint(1) DEFAULT '1',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#二维码申请表
drop table if exists `qr_code_apply`;
CREATE TABLE `qr_code_apply` (
    `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  	`production_id` BIGINT(20) NULL DEFAULT NULL,
  	`apply_count` INT(11) NULL DEFAULT NULL,
  	`generate_count` INT(11) NULL DEFAULT NULL,
  	`qrcode_start` BIGINT(20) NULL DEFAULT '1',
  	`apply_user_id` BIGINT(20) NULL DEFAULT NULL,
  	`approve_user_id` BIGINT(20) NULL DEFAULT NULL,
  	`status` SMALLINT(6) NULL DEFAULT NULL COMMENT '0 未审核/1 审批拒绝/2 审核完成',
  	`corporation_id` BIGINT(20) NULL DEFAULT NULL,
  	`state` TINYINT(1) NULL DEFAULT '0',
  	`create_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  	`client_address` varchar(30) DEFAULT NULL,
  	constraint `pk_code_apply` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




#二维码使用表
drop table if exists `qr_code`;
CREATE TABLE `qr_code` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `corporation_id` BIGINT(20) NULL DEFAULT NULL,
  `apply_id` BIGINT(20) NULL DEFAULT NULL,
  `corporation_qrcode` VARCHAR(50) NULL DEFAULT NULL,
  `qrcode` VARCHAR(50) NULL DEFAULT '',
  `fake_code` VARCHAR(8) NULL DEFAULT '',
  `type` SMALLINT(6) NULL DEFAULT NULL COMMENT '生产基地码 1/生产加工类型码 2/销售码 3/产品码 4/物流码 5',
  `status` SMALLINT(6) NULL DEFAULT '0' COMMENT '未使用 0 /包装 1/销售 2',
  `scanning_times` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_scan_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_2` (`apply_id`),
  KEY `Index_3` (`qrcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#生产加工类型，生产基地二维码使用表
drop table if exists `qr_base_code`;
CREATE TABLE `qr_base_code` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `corporation_id` BIGINT(20) NULL DEFAULT NULL,
  `production_base_id` BIGINT(20) NULL DEFAULT NULL,
  `manufacture_id` BIGINT(20) NULL DEFAULT NULL,
  `qrcode` VARCHAR(50) NULL DEFAULT '',
  `type` SMALLINT(6) NULL DEFAULT NULL COMMENT '生产基地码 1/生产加工类型码 2/销售码 3/产品码 4',
  `state` tinyint(1) DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_scan_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#物流表
drop table if exists `qr_transmit`;
CREATE TABLE `qr_transmit` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sender` VARCHAR(500) default NULL COMMENT '发件人',
  `sender_phone` VARCHAR(500) default NULL COMMENT '发件人联系方式',
  `receiver` VARCHAR(500) default NULL COMMENT '收件人',
  `receiver_phone` VARCHAR(500) default NULL COMMENT '收件人联系方式',
  `carrier` VARCHAR(500) default NULL COMMENT '物流商',
  `departure` VARCHAR(50) default NULL COMMENT '出发地',
  `destination` VARCHAR(50) default NULL COMMENT '目的地',
  `sold_records`  varchar(500) default NULL COMMENT '所选销售记录，存id数组' ,
  `plan_id`  int(20) DEFAULT '0' COMMENT '子配送所有属性，存分配记录id',
  `status`  smallint(6) NULL DEFAULT 0 COMMENT '未发货 0/物流中 1 /已收货 2' ,
  `creator`  bigint(20) NULL DEFAULT NULL ,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `state` tinyint(1) DEFAULT '1',
  `transmit_qrcode` VARCHAR(100) NOT NULL COMMENT '运单号,系统自动生成',
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_qr_transmit` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `qr_transmit_record`;
CREATE TABLE `qr_transmit_record` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `transmit_qrcode` VARCHAR(100) NOT NULL COMMENT '运单号',
  `scan_action` VARCHAR(500) default NULL COMMENT '扫描的内容：0 上车,1 下车,2 发货,3 收货',
  `scan_user` VARCHAR(50) default NULL COMMENT '操作人',
  `scan_location` VARCHAR(100) default NULL COMMENT '扫描的地址',
  `scan_latlng` VARCHAR(50) default NULL COMMENT '由app获取的设备经纬度',
  `plan_id` BIGINT(20)  default NULL COMMENT '对应下货记录的id',
  `scan_time` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_qr_transmit_record` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#产品销售表
drop table if exists `qr_sold_record`;
CREATE TABLE `qr_sold_record` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`sold_date`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`production_id`  bigint(20) NULL DEFAULT NULL ,
`qrcode_apply_id`  bigint(20) NULL DEFAULT NULL ,
`qrcode_start_id`  bigint(20) NULL DEFAULT NULL COMMENT '起始码id' ,
`sold_count`  bigint(20) NOT NULL COMMENT '二维码使用数量' ,
`dealer_id`  bigint(20) NULL DEFAULT NULL COMMENT '经销商' ,
`creator`  bigint(20) NULL DEFAULT NULL ,
`status`  bigint(20) NULL DEFAULT 0 COMMENT '未发货0   已发货1   已收货2' ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#产品包装表
drop table if exists `qr_package`;
CREATE TABLE `qr_package` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`package_date`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`production_id`  bigint(20) NULL DEFAULT NULL ,
`serial_id`  bigint(20) NULL DEFAULT NULL ,
`subserial_id`  bigint(20) NULL DEFAULT NULL COMMENT '二维码使用数量' ,
`qrcode_apply_id`  bigint(20) NULL DEFAULT NULL ,
`qrcode_start_id`  bigint(20) NULL DEFAULT NULL COMMENT '起始码id' ,
`package_count`  bigint(20) NOT NULL ,
`creator`  bigint(20) NULL DEFAULT NULL ,
`status`  bigint(20) NULL DEFAULT 0 COMMENT '' ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#产品投诉建议表
drop table if exists `qr_custom_events`;
CREATE TABLE `qr_custom_events` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `production_id` BIGINT(20) DEFAULT NULL,
  `qrcode_id` BIGINT(20) DEFAULT NULL COMMENT '二维码',
  `dealer_id` BIGINT(20) DEFAULT NULL COMMENT '经销商',
  `type` bigint(20) DEFAULT NULL COMMENT '品牌投诉0  质量投诉1',
  `linkman` VARCHAR(15) DEFAULT '' COMMENT '联系人',
  `event_content` VARCHAR(500) DEFAULT '',
  `mobile` VARCHAR(15) DEFAULT '',
  `grade` smallint(6) DEFAULT 5,
  `state` BOOLEAN DEFAULT false,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  constraint `pk_custom_events` PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



#部门表
drop table if exists `qr_department`;
CREATE TABLE  `qr_department` (
`id`  bigint(11) NOT NULL AUTO_INCREMENT ,
`corporation_id`  bigint(20) NOT NULL ,
`name`  varchar(20) NOT NULL ,
`desc`  varchar(4000) NULL ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`creator`  bigint(20) NULL ,
`create_time`  TIMESTAMP default CURRENT_TIMESTAMP ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#自定义栏目表
drop table if exists `qr_displaymenu`;
CREATE TABLE `qr_displaymenu`(
`id`  bigint(11) NOT NULL AUTO_INCREMENT ,
`corporation_id`  bigint(20) NOT NULL ,
`name`  varchar(20) NOT NULL ,
`weight`  smallint(6) NOT NULL DEFAULT 0 ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`creator`  bigint(20) NULL ,
`create_time`  TIMESTAMP default CURRENT_TIMESTAMP ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#栏目新闻表
drop table if exists `qr_displaymenu_news`;
CREATE TABLE `qr_displaymenu_news` (
`id`  bigint(11) NOT NULL AUTO_INCREMENT ,
`displaymenu_id`  bigint(20) NOT NULL ,
`title`  varchar(20) NOT NULL ,
`news`  varchar(4000) NULL ,
`status`  tinyint(1) NULL DEFAULT 0 COMMENT '1为置顶 0为默认' ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`creator`  bigint(20) NULL ,
`create_time`  TIMESTAMP default CURRENT_TIMESTAMP ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#宣传名片表
drop table if exists `qr_businesscard`;
CREATE TABLE `qr_businesscard` (
`id`  bigint(11) NOT NULL AUTO_INCREMENT ,
`corporation_id`  bigint(20) NOT NULL ,
`head_photo_id`  bigint(20) NULL DEFAULT NULL COMMENT '指向qr_file',
`name`  varchar(20) NOT NULL ,
`position`  varchar(50) NULL ,
`qq`  varchar(20) NULL ,
`mail`  varchar(50) NULL ,
`mobile_phone`  varchar(20) NULL ,
`hometown`  varchar(50) NULL ,
`location`  varchar(50) NULL ,
`profile`  varchar(500) NULL ,
`desc`  varchar(1000) NULL ,
`qrcode`  varchar(255) NULL DEFAULT '' ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`creator`  bigint(20) NULL ,
`create_time`  TIMESTAMP default CURRENT_TIMESTAMP ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#用户日志表
drop table if exists `qr_logs`;
CREATE TABLE `qr_logs` (
  `id` BIGINT(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT(11) NOT NULL,
  `url` VARCHAR(50) NOT NULL DEFAULT '',
  `action` VARCHAR(20) DEFAULT NULL COMMENT '增加0,修改1,删除2,查看一览3,查看详细4,下载5,审批6,拒绝审批7,用户禁用8,用户启用9,密码重置10,登录11,数据查询12',
  `operate_type` varchar(10) NOT NULL DEFAULT '' COMMENT '类型',
  `operate_id` BIGINT(11) DEFAULT NULL COMMENT '操作id',
  `content` VARCHAR(1000) DEFAULT NULL COMMENT '修改的内容',
  `state` BOOLEAN DEFAULT false,
  `create_time` TIMESTAMP default CURRENT_TIMESTAMP,
  `client_address` varchar(30) DEFAULT NULL,
  constraint `pk_logs`  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#公告表
CREATE TABLE `qr_advertisement` (
`id`  bigint(11) NOT NULL AUTO_INCREMENT ,
`corporation_id`  bigint(20) NOT NULL ,
`title`  varchar(20) NOT NULL ,
`content`  varchar(200)  NULL DEFAULT NULL ,
`state`  tinyint(1) NULL DEFAULT 0 ,
`creator`  bigint(20) NULL DEFAULT NULL ,
`create_time`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`client_address` varchar(30) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#流程角色表
CREATE TABLE `qr_role_manufacture` (
`id`  bigint(20)  NOT NULL AUTO_INCREMENT ,
`role_id`  bigint(20) NULL DEFAULT NULL ,
`manufacture_id`  bigint(20) NULL DEFAULT NULL ,
`state`  tinyint(1) NULL DEFAULT 1 ,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

#用户绑定角色
CREATE TABLE `qr_user_manufacture` (
`id`  bigint(20)  NOT NULL AUTO_INCREMENT ,
`role_id`  bigint(20) NULL DEFAULT NULL ,
`user_id`  bigint(20) NULL DEFAULT NULL ,
`state`  tinyint(1) NULL DEFAULT 1 ,
`creator`  bigint(20) NULL DEFAULT NULL ,
`create_time`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`client_address`  varchar(30)  NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

#追溯信息表
CREATE TABLE `qr_tab` (
`id`  bigint(20)  NOT NULL AUTO_INCREMENT ,
`corporation_id`  bigint(20) NOT NULL ,
`tab_name`  varchar(20)  NOT NULL ,
`state`  tinyint(1)  NULL DEFAULT 1 ,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `qr_transmit_plan` (
`id`  bigint(20) NOT NULL AUTO_INCREMENT ,
`transmit_id`  bigint(20) NULL DEFAULT NULL ,
`destination`  varchar(50)  NULL DEFAULT NULL ,
`sold_records`  varchar(500)  NULL DEFAULT NULL ,
`record_count` varchar(10)  NULL DEFAULT NULL ,
`state`  tinyint(1) NULL DEFAULT 1 ,
`creator`  bigint(20) NULL DEFAULT NULL ,
`create_time`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`client_address`  varchar(30)  NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `qr_transmit_plan_record` (
`id`  bigint(20) NOT NULL AUTO_INCREMENT ,
`transmit_id`  bigint(20) NULL DEFAULT NULL ,
`plan_id`  bigint(20) NULL DEFAULT NULL ,
`production_id`  bigint(20) NULL DEFAULT NULL ,
`apply_id`  bigint(20) NULL DEFAULT NULL ,
`qrcode_start`  varchar(50)  NULL DEFAULT NULL ,
`sold_count`  bigint(20)  NULL DEFAULT NULL ,
`state`  tinyint(1) NULL DEFAULT 1,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;