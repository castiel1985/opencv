"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require('./commonModel.js');
var logger = require('../utils/winstonUtils').logger;
var async = require('async');

var PRODUCTION_QRCODE_STATUS = {
  no_use: 0,
  packaged: 1,
  saled: 2,
  expire: 3 //过期
};
/**
 * status 未审核 0 /审核完成 1/打包完成 2
 * @param corpId
 * @param status
 * @param callback
 */
function getQrcodeApplyList(tableParams,callback) {
  var sql1 = tableParams.status == null ? '' : " and a.status = " + tableParams.status + " ";
  var sqlData = "select a.*,c.name as corporation_name from qr_code_apply a, qr_corporation c where a.corporation_id = c.id  " + sql1 +" and ((c.share is true AND a.corporation_id = :corpId) || (c.share is false AND a.apply_user_id = :userId)) ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords from qr_code_apply a, qr_corporation c where a.corporation_id = c.id " + sql1 +" and ((c.share is true AND a.corporation_id = :corpId) || (c.share is false AND a.apply_user_id = :userId)) ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr="";
  if(tableParams.orderName == "corporation_name"){
    orderStr = " ORDER BY c.name " + tableParams.orderDir;
  }else if(tableParams.orderName == "apply_time"){
    orderStr = " ORDER BY a.create_time " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.apply_count like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords from qr_code_apply a, qr_corporation c where a.corporation_id = c.id " + sql1 +" and ((c.share is true AND a.corporation_id = :corpId) || (c.share is false AND a.apply_user_id = :userId)) AND a.apply_count like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function applyCode(options, callback) {
  var sql = 'INSERT INTO qr_code_apply (`production_id`,' +
    ' `status`, ' +
    ' `apply_count`, ' +
    ' `corporation_id`, ' +
    ' `apply_user_id`, ' +
    ' `qrcode_start`, ' +
    '`state`,' +
    'client_address) values ' +
    '(:production_id,' +
      ':status,' +
      ':apply_count,' +
      ':corporation_id,' +
      ':apply_user_id,' +
      ':qrcode_start,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var applyId = result.insertId;
    logger.info("added apply id = %d", applyId);
    return callback(null, applyId);
  });

}

function approveCode(params, callback) {
  var sql = 'update qr_code_apply set generate_count=:generate_count,approve_user_id=:approve_user_id,status=:status where id=:id';
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"));
    }
    return callback(null);
  });

}

function queryApprovedQrcode(tableParams,callback){
  var sqlData = "SELECT * FROM qr_code WHERE state = :state ";
  var sqlCount = "SELECT :apply_count as iTotalRecords ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY qrcode "+ tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    if(tableParams.page_startcode){
      sqlData = sqlData + " and qrcode >= :page_startcode and apply_id = :applyId and qrcode like :search " + orderStr + " limit 0,:length ";
    }else{
      sqlData = sqlData + "  and apply_id = :applyId and qrcode like :search " + orderStr + " limit :start,:length";
    }
    sqlFilterCount = "SELECT count(id) as iTotalDisplayRecords FROM qr_code WHERE apply_id = :applyId AND state = :state AND qrcode like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    if(tableParams.page_startcode){
      sqlData = sqlData + " and qrcode >= :page_startcode  and apply_id = :applyId " + orderStr + " limit 0,:length ";
    }else{
      sqlData = sqlData + " and apply_id = :applyId" + orderStr + " limit :start,:length ";
    }
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlData = sqlData + " and apply_id = :applyId ORDER BY qrcode asc";
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });

}

function querySoldRecores(tableParams,callback){
  var sqlData = "SELECT b.*, c.name as dealer_name from qr_code_apply a, qr_sold_record b, qr_production_dealer c where b.qrcode_start_id >= a.qrcode_start AND b.qrcode_start_id < (a.qrcode_start+a.generate_count) AND c.id = b.dealer_id AND a.id=:applyId AND b.state=:state ";
  var sqlCount = "SELECT count(b.id) as iTotalRecords from qr_code_apply a, qr_sold_record b, qr_production_dealer c where b.qrcode_start_id >= a.qrcode_start AND b.qrcode_start_id < (a.qrcode_start+a.generate_count) AND c.id = b.dealer_id AND a.id=:applyId AND b.state=:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr="";
  if(tableParams.orderName == "dealer_name"){
    orderStr = " ORDER BY c.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY b." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND b.sold_count like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(b.id) as iTotalDisplayRecords from qr_code_apply a, qr_sold_record b, qr_production_dealer c where b.qrcode_start_id >= a.qrcode_start AND b.qrcode_start_id < (a.qrcode_start+a.generate_count) AND c.id = b.dealer_id AND a.id=:applyId AND b.state=:state AND b.sold_count like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);

  });
}

function queryTransmitRecores(applyId,callback){
  var sql = "SELECT * FROM qr_transmit_record";
  database.query({
    sql: sql
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

//插入qrcode
function insertQrcode(sql, callback){
  database.query({
    sql: sql
  }, function(err, result) {
    if(err){
      return callback(err, null);
    }else{
      return callback(null, result);
    }
  });
}

function updateCodeStatus(status,codeList,callback){
  var sql = "UPDATE qr_code SET status =:status WHERE qrcode BETWEEN :startcode AND :endcode";
  database.query({
    sql:sql,
    params:{
      status:status,
      startcode:codeList.startcode,
      endcode:codeList.endcode
    }
  },function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(result);
    return callback(null, result);
  });
}

function updateCode( qrcode, params, callback){
  var sql_head = "UPDATE qr_code SET ";
  var colums = [];
  for(var key in params){
    colums.push("`"+key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE qrcode = '" + qrcode+"'";
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function getQrcodeByCode(tableParams,statuscondition,callback){
  var condition = "(a.qrcode BETWEEN :startcode AND :endcode)";
  if(statuscondition){
    condition += " and " + statuscondition.replace("status","a.status");
  }
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  var sql = "";
  if(tableParams.search){
    if(tableParams.page_startcode){
      sql = " and qrcode >= :page_startcode and qrcode  like :search " + orderStr + " limit 0,:length ";
    }else{
      sql = " and qrcode  like :search " + orderStr + " limit :start,:length ";
    }
  }else if(tableParams.length){
    if(tableParams.page_startcode){
      sql = " and qrcode >=  :page_startcode " + orderStr + " limit 0,:length ";
    }else{
      sql = orderStr + " limit 0,:length ";
    }
  }
  var sqlData = "SELECT a.*,e.serial_no,f.serial_no as subserial_no,c.name as package_creator " +
    "FROM (SELECT * FROM qr_code a WHERE " + condition + sql +") a left join (qr_package b,qr_user c,qr_serials e,qr_serials f) on (substr(a.qrcode,-10,8) >= b.qrcode_start_id and substr(a.qrcode,-10,8) < ( b.qrcode_start_id + b.package_count) and a.apply_id = b.qrcode_apply_id) and b.creator = c.id and b.serial_id = e.id and b.subserial_id = f.id ";
  var sqlCount;
  if(tableParams.package_count){
    sqlCount = "SELECT :package_count as iTotalRecords";
  }else{
    sqlCount = "SELECT count(id) as iTotalRecords FROM qr_code a WHERE "+condition;
  }
  var sqlFilterCount = "";
  var sqlArr = [];

  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlFilterCount = "SELECT count(id) as iTotalDisplayRecords FROM qr_code a WHERE  "+condition+" AND qrcode like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlData = "SELECT id FROM qr_code a WHERE " + condition;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(err,tableData);
  });
}

function getQrcodeByCorpId(tableParams,callback){
  var sqlData = "SELECT * FROM (SELECT b.apply_id,min(b.code) as start_code,max(b.code) as end_code "+
    "FROM ( SELECT a.*, BINARY (a.CODE - rownum) c FROM ( SELECT *,(@rownum := @rownum + 1) as rownum FROM "+
    "( SELECT @rownum := 0,apply_id,SUBSTRING(qrcode, -10, 8) AS code FROM qr_code WHERE apply_id IN ( SELECT a.id FROM qr_code_apply a,qr_corporation b WHERE a.corporation_id = b.id and (((b.share is true || :all) AND a.corporation_id =:corporationId) || (b.share is false AND a.apply_user_id = :userId)) and a.status = 2) AND `status` =:status) t "+
    " ORDER BY apply_id, CODE) a) b GROUP BY b.apply_id, b.c) q ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM (SELECT b.apply_id,min(b. CODE) as start_code,max(b. CODE) as end_code "+
    "FROM ( SELECT a.*, BINARY (a.CODE - rownum) c FROM ( SELECT *,(@rownum := @rownum + 1) as rownum FROM "+
    "( SELECT @rownum := 0,apply_id,SUBSTRING(qrcode, -10, 8) AS code FROM qr_code WHERE apply_id IN ( SELECT a.id FROM qr_code_apply a,qr_corporation b WHERE a.corporation_id = b.id and (((b.share is true || :all) AND a.corporation_id =:corporationId) || (b.share is false AND a.apply_user_id = :userId)) and a.status = 2) AND `status` =:status) t "+
    " ORDER BY apply_id, CODE) a) b GROUP BY b.apply_id, b.c) q ";
  var sqlFilterCount = "";
  var sqlArr = [];
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " WHERE q.start_code like :search limit :start,:length";
    sqlFilterCount = " SELECT count(*) as iTotalDisplayRecords FROM (SELECT b.apply_id,min(b. CODE) as start_code,max(b. CODE) as end_code "+
    "FROM ( SELECT a.*, BINARY (a. CODE - rownum) c FROM ( SELECT *,(@rownum := @rownum + 1) as rownum FROM "+
    "( SELECT @rownum := 0,apply_id,SUBSTRING(qrcode, -10, 8) AS code FROM qr_code WHERE apply_id IN ( SELECT a.id FROM qr_code_apply a,qr_corporation b WHERE a.corporation_id = b.id and (((b.share is true || :all) AND a.corporation_id =:corporationId) || (b.share is false AND a.apply_user_id = :userId)) and a.status = 2) AND `status` =:status) t "+
    " ORDER BY apply_id, CODE) a) b GROUP BY b.apply_id, b.c) q WHERE q.start_code like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getApproveList(user, tableParams, callback) {
  var sql1 = tableParams.status == null ? '' : " and a.status = " + tableParams.status + " ";
  var sqlData = "select a.*,c.name as corporation_name, c.id as corporation_id, c.qrcode as qrcode from qr_code_apply a, qr_corporation c where a.corporation_id = c.id "+sql1+" and c.superior_id = :corpId ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords from qr_code_apply a, qr_corporation c where a.corporation_id = c.id "+sql1+" and c.superior_id = :corpId ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr="";
  if(tableParams.orderName == "corporation_name"){
    orderStr = " ORDER BY c.name " + tableParams.orderDir;
  }else if(tableParams.orderName == "apply_time"){
    orderStr = " ORDER BY a.create_time " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND (c.name like :search  OR a.apply_count like :search) " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords from qr_code_apply a, qr_corporation c where a.corporation_id = c.id "+sql1+" and c.superior_id = :corpId AND (c.name like :search  OR a.apply_count like :search) ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function geApplyById(applyId, callback) {

  database.query({
    sql: "SELECT a.*,b.qrcode AS corporation_qrcode FROM qr_code_apply a LEFT JOIN qr_corporation b ON b.id = a.corporation_id WHERE a.id = :applyId AND a.state = :state",
    params: {
      "applyId": applyId,
      "state": 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }
  });
}

/*
 * 查看一段二维码中，有哪些二维码是属于 某个子批次的。
 * 参数：sub_id:子批次id，start:起始二维码id, end:结束二维码id
 * 返回值: [1-10,31-50] 数组记录起始二维码id
 * */
function getSerialQrcodes(subId, start, end, callback){
  var sql = "SELECT * FROM qr_package WHERE state = :state AND ((qrcode_start_id <= :start AND qrcode_start_id+package_count > :start) OR " +
    "(qrcode_start_id <= :end AND qrcode_start_id+package_count >=:end) OR " +
    "(qrcode_start_id >= :start AND qrcode_start_id+package_count <=:end)) ORDER BY qrcode_start_id";
  database.query({
    sql:sql,
    params:{start:start,end:end,state:1}
  },function(err, rows){
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(null);
    }
    var currStart = start;
    var subSerialId;
    var arr = [];
    var key;
    rows && rows.forEach(function(item){
      subSerialId = item.subserial_id;
      var start_id = item.qrcode_start_id;
      var end_id = item.qrcode_start_id+item.package_count-1;

      if(end > end_id){
        key = currStart+"-"+end_id;
      }else{
        key = currStart+"-"+end;
      }
      currStart = end_id + 1;
      if(subId == subSerialId){
        arr.push(key);
      }
    });
    callback(arr);
  });
}

function getProPackageList(proId, callback) {
  database.query({
    sql: "SELECT * FROM qr_package WHERE production_id = :proId AND state = :state ORDER BY qrcode_apply_id,qrcode_start_id",
    params: {
      "proId": proId,
      "state": 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function getProSoldList(proId, callback) {
  database.query({
    sql: "SELECT * FROM qr_sold_record WHERE production_id = :proId AND state = :state ORDER BY qrcode_apply_id,qrcode_start_id",
    params: {
      "proId": proId,
      "state": 1
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

exports.getQrcodeByCorpId = getQrcodeByCorpId;
exports.getQrcodeByCode = getQrcodeByCode;
exports.updateCodeStatus = updateCodeStatus;
exports.updateCode = updateCode;
exports.queryApprovedQrcode = queryApprovedQrcode;
exports.getQrcodeApplyList = getQrcodeApplyList;
exports.applyCode = applyCode;
exports.approveCode = approveCode;
exports.querySoldRecores = querySoldRecores;
exports.queryTransmitRecores = queryTransmitRecores;
exports.insertQrcode = insertQrcode;
exports.getApproveList = getApproveList;
exports.PRODUCTION_QRCODE_STATUS = PRODUCTION_QRCODE_STATUS;
exports.geApplyById = geApplyById;
exports.getSerialQrcodes = getSerialQrcodes;
exports.getProPackageList = getProPackageList;
exports.getProSoldList = getProSoldList;
