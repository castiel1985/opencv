(venv)$ deactivate
$ python -c "import sys; print sys.executable"
/usr/local/bin/python
