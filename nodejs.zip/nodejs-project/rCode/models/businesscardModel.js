"use strict";
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require('./commonModel.js');

function getBusinessCardListByCorpId(tableParams,callback){
  var sqlData = "SELECT a.* FROM qr_businesscard a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId AND a.state = :state ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_businesscard a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId AND a.state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_businesscard a,qr_corporation b WHERE b.id = a.corporation_id and a.corporation_id = :corpId AND a.state = :state AND a.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function addBusinessCard(options, callback){
  var sql = 'INSERT INTO qr_businesscard (`corporation_id`,' +
    ' `name`, ' +
    ' `position`, ' +
    '`qq`, ' +
    '`mail`, ' +
    '`mobile_phone`, ' +
    '`hometown`, ' +
    '`location`, ' +
    '`profile`, ' +
    '`desc`, ' +
    '`creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:corporation_id,'+
    ':name,' +
    ':position,' +
    ':qq,' +
    ':mail,' +
    ':mobile_phone,' +
    ':hometown,' +
    ':location,' +
    ':profile,' +
    ':desc,' +
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var businesscardId = result.insertId;
    logger.info("added businesscard  id = %d", businesscardId);

    if(options.files) {
      options.files.forEach(function (item) {
        item.creator = options.creator;
        item.type = 'head_photo_' + businesscardId;
        insertFiles(item, businesscardId, callback);
      });
    }
    return callback(null, businesscardId);
  });
}

function insertFiles(opts, businesscardId, callback){
  var insert = "insert into qr_file (name,url,`type`,mime,creator,`state`) values (:filename,:url,:type,:mimetype,:creator,true)";
  database.query({
    sql: insert,
    params: opts
  },function(err, result){
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    updateHeadFileId(businesscardId, result.insertId, null);
  });
}

function updateHeadFileId(businesscardId, headFileId, callback){
  var update = "update qr_businesscard set head_photo_id =:headFileId where id =:id";
  database.query({
    sql: update,
    params: {
      id: businesscardId,
      headFileId: headFileId
    }
  },null); //just ignore errors! //TODO
}

function getBusinessCardById(id, callback){
  database.query({
    sql: "select a.*,b.url,b.name as filename,b.id as fileid from qr_businesscard a LEFT JOIN qr_file b on a.head_photo_id = b.id and b.state = 1 where " +
    " a.id =:id ",
    params: {
      "id": id
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function updateBusinessCardById(businesscardId, params,files, callback){
  var sql_head = "UPDATE qr_businesscard SET ";
  var colums = [];
  for(var key in params){
    colums.push("`"+key + "`=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + businesscardId;
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      files && files.forEach(function (item) {
          item.type = 'head_photo_' + businesscardId;
          insertFiles(item, businesscardId, callback);
        });
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function deletBusinessCard( id, callback){
  database.query({
    sql: "UPDATE qr_businesscard SET state = 0 WHERE id =:id",
    params: {
      "id": id
    }
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      if (result.affectedRows) {
        return callback(null, true);
      } else {
        return callback(null, null);
      }
    }
  });
}

exports.deletBusinessCard = deletBusinessCard;
exports.updateBusinessCardById = updateBusinessCardById;
exports.getBusinessCardById = getBusinessCardById;
exports.addBusinessCard = addBusinessCard;
exports.getBusinessCardListByCorpId = getBusinessCardListByCorpId;
