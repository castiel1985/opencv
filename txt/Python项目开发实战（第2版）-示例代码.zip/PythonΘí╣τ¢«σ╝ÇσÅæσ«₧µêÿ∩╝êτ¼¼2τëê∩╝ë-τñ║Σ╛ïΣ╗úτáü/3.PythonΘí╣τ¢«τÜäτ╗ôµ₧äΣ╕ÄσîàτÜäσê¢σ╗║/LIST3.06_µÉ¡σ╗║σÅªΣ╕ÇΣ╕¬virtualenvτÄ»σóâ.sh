$ virtualenv another-venv
$ ls -F
another-venv/   venv/
