$ sphinx-quickstart
Welcome to the Sphinx 1.3 quickstart utility.

-（中间省略）-

> Root path for the documentation [.]: sw-project

-（中间省略）-

> Project name: SW-Project
> Author name(s): BeProud

-（中间省略）-

> Project version: 1.0

-（中间省略）-

$ ls sw-project
_build  conf.py  index.rst  make.bat  Makefile  _static  _templates
