$ sudo userdel -r bpuser
