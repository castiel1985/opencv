"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require('./commonModel');



function getCorporationByUserId(userId, callback) {
  database.query({
    sql: "SELECT * FROM qr_corporation " +
      " WHERE creator =:userId",
    params: {
      "userId": userId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function getCorpListByRole(tableParams, callback) {
  var sqlData;
  var sqlCount;
  var user = tableParams.user;
  if(user && user.isAdmin){
    sqlData = "SELECT * FROM qr_corporation WHERE superior_id IS NULL AND creator = :userId AND state = :state ";
    sqlCount = "SELECT count(id) as iTotalRecords FROM qr_corporation WHERE superior_id IS NULL AND creator = :userId AND state = :state ";
  }else{
    sqlData = "SELECT * FROM qr_corporation WHERE superior_id =:superiorId AND state = :state ";
    sqlCount = "SELECT count(id) as iTotalRecords FROM qr_corporation WHERE superior_id =:superiorId AND state = :state ";
  }

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  var pagFlag = true; //是否分页
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND name like :search " + orderStr +" limit :start,:length";
    if(user && user.isAdmin){
      sqlFilterCount = "SELECT count(id) as iTotalDisplayRecords FROM qr_corporation WHERE superior_id IS NULL AND creator = :userId AND state = :state AND name like :search ";
    }else{
      sqlFilterCount = "SELECT count(id) as iTotalDisplayRecords FROM qr_corporation WHERE superior_id =:superiorId AND state = :state AND name like :search ";
    }

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function getSuperiorById(id, callback) {
  database.query({
    sql: "SELECT * FROM qr_corporation " +
    " WHERE id =:id",
    params: {
      "id": id
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

/**
 * 根据区域编号获取名称
 * @param code
 * @param callback
 */
function getRegionNameByCode(code, callback){
  database.query({
    sql: "SELECT * FROM qr_region " +
      " WHERE code =:code",
    params: {
      "code": code
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

/**
 * 根据区域名称获取编号
 * @param code
 * @param callback
 */
function getRegionCodeByName(name, callback){
  database.query({
    sql: "SELECT * FROM qr_region " +
      " WHERE name =:name",
    params: {
      "name": name
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

/**
 * 根据多个区域编号获取全名
 * @param code
 * @param callback
 */
function getRegionNameByCodes(codes, callback){
  if(codes == null || codes.length == 0){
    return callback(null, null);
  }
  var regionArray = codes.split("-");
  var codeArray = [];
  for(var i=0,len=regionArray.length; i<len; i++){
    codeArray[i] = "'" + regionArray[i] + "'";
  }
  database.query({
    sql: "SELECT * FROM qr_region " +
      " WHERE code in (" + codeArray.join(",") + ")"
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function updateCorporation(params, callback) {
  database.query({
    sql: "UPDATE qr_corporation SET `is_show_anti_fake`=:anti_fake, " +
      " `contact`=:contact, " +
      " `email`=:email , " +
      " `telephone`=:telephone, " +
      " `address`=:address, " +
      " `share`=:share," +
      " `is_auto_approve`=:is_auto_approve," +
      " `manu_sort_flag`=:manu_sort_flag" +
    " WHERE `id` =:id",
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }
  });
}

function updateIntroduction(params, callback) {
  database.query({
    sql: "UPDATE qr_corporation SET `desc` = :desc," +
    "contact = :contact," +
    "telephone = :telephone," +
    "email = :email," +
    "address = :address  " +
    " WHERE id = :corporationid",
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      if(params.pictureFiles) {
        params.pictureFiles.forEach(function (item) {
          item.creator = params.creator;
          item.type = 'corp_picture_' + params.corporationid;
          //insertFiles(item, params.corporationid, callback);
          commonModel.insertFiles(item, null);
        });
      }
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

/*function insertFiles(opts, corporationid, callback){
  var insert = "insert into qr_file (name,url,`type`,mime,creator,`state`) values (:filename,:url,:type,:mimetype,:creator,true)";
  database.query({
    sql: insert,
    params: opts
  },function(err, result){
    if (err) {
      logger.error(err.stack);
      return callback(new DBError("MySQL Error"), null);
    }
    updateVideoId(corporationid, result.insertId, null);
  });
}

function updateVideoId(corporationid, videoId, callback){
  var update = "update qr_corporation set video_id =:videoId where id =:id ";
  database.query({
    sql: update,
    params: {
      id: corporationid,
      videoId: videoId
    }
  },null); //just ignore errors! //TODO
}*/

function insertCorporation(params, callback) {
  var sql = 'INSERT INTO qr_corporation (`creator`,' +
    '`superior_id`, ' +
    '`name`, ' +
    '`region_id`, ' +
    '`qrcode`, ' +
    '`is_show_anti_fake`, ' +
    '`contact`, ' +
    '`telephone`, ' +
    '`address`, ' +
    '`email`, ' +
    '`share`, ' +
    '`is_auto_approve`, ' +
    '`manu_sort_flag`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:creator,'+
    ':superior_id,' +
    ':name,' +
    ':region_id,' +
    ':qrcode,' +
    ':is_show_anti_fake,' +
    ':contact,' +
    ':telephone,' +
    ':address,' +
    ':email,' +
    ':share,' +
    ':is_auto_approve,' +
    ':manu_sort_flag,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql:sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, result);
    } else {
      return callback(null, null);
    }
  });
}

function getCorpById(corpId, callback){
  var sql = "SELECT a.*,c.name AS superior_name,c.id AS superior_id FROM qr_corporation a  LEFT JOIN qr_corporation c ON c.id = a.superior_id "+
    "WHERE  a.id =:corpId AND a.state =:state";
  database.query({
    sql: sql,
    params: {corpId:corpId, state:1}
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:pictureType and state = 1",
        params: {
          "pictureType": "corp_picture_" + corpId
        }
      }, function(err, rows2){
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = [];
        if(!!rows2 && rows2.length > 0){
          rows2.forEach(function(item){
            if(item.type.indexOf("corp_picture_") >= 0 ){
              row.pictureFiles.push(item);
            }
          });
        }
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }

  });
}

function getCorpByCode(qrcode, callback){
  var sql = "SELECT * FROM qr_corporation WHERE  qrcode = :qrcode  AND state = :state";
  database.query({
    sql: sql,
    params: {qrcode:qrcode, state:1}
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:pictureType and state = 1",
        params: {
          "pictureType": "corp_picture_" + row.id
        }
      }, function(err, rows2){
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = [];
        if(!!rows2 && rows2.length > 0){
          rows2.forEach(function(item){
            if(item.type.indexOf("corp_picture_") >= 0 ){
              row.pictureFiles.push(item);
            }
          });
        }
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }

  });
}

function delCorpById(corpId, callback){
  var sql = "UPDATE qr_corporation SET state=:state WHERE id=:corpId";
  database.query({
    sql: sql,
    params: {corpId:corpId, state:0}
  }, function(err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, true);

  });
}

function getCorpsByUserRole(user, callback){
  var sql;
  if(user.isAdmin){
    sql = "SELECT * FROM qr_corporation WHERE creator =:userId AND state = :state";
  }else if(user.isSupervisor){
    sql = "SELECT * FROM qr_corporation WHERE superior_id =:corpId AND state = :state";
  }else{
    sql = "SELECT * FROM qr_corporation WHERE id=:corpId AND state=:state";
  }
  database.query({
    sql: sql,
    params: {userId:user.id,corpId:user.corporation_id, state:1}
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getAllSuperiors(callback){
  var sql = "SELECT * FROM qr_corporation WHERE superior_id IS NULL AND creator IS NOT NULL AND state=:state";
  database.query({
    sql: sql,
    params: {state:1}
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function covRegionToName(regions, callback){
  var sql = "SELECT * FROM qr_region WHERE code IN ("+regions.join(",")+") ORDER BY code";
  var names = [];

  for(var i=0;i<regions.length;i++){
    commonModel.getRegionNameByCode(regions[i], function(err, rows){
      if (err || !rows) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }

      if (rows.length > 0) {
        var name="";
        for(var j=0;j<rows.length;j++){
          name += rows[j].name;
        }
        names.push(name);

        if(names.length == regions.length){
          callback(null, names);
        }
      }
    });
  }
}

exports.updateIntroduction = updateIntroduction;
exports.updateCorporation = updateCorporation;
exports.getSuperiorById = getSuperiorById;
exports.getCorporationByUserId = getCorporationByUserId;
exports.getRegionNameByCode = getRegionNameByCode;
exports.getRegionCodeByName = getRegionCodeByName;
exports.getRegionNameByCodes = getRegionNameByCodes;
exports.insertCorporation = insertCorporation;
exports.getCorpListByRole = getCorpListByRole;
exports.getCorpById = getCorpById;
exports.getCorpByCode = getCorpByCode;
exports.delCorpById = delCorpById;
exports.getCorpsByUserRole = getCorpsByUserRole;
exports.getAllSuperiors = getAllSuperiors;
exports.covRegionToName = covRegionToName;