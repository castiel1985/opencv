$ pip install wheel
Downloading/unpacking wheel
  Downloading wheel-0.24.0-py2.py3-none-any.whl (63kB): 63kB downloaded
  Installing collected packages: wheel
  Successfully installed wheel
  Cleaning up...
