"use strict";
var express = require('express');
var router = express.Router();
var nconf = require('nconf');
var logger = require('../utils/winstonUtils').logger;
var dataTableObj = require('../middleware/dataTableObject');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logsModel = require('../models/logsModel');
var tabModel = require('../models/tabModel');

router.get('/',function(req, res, next){
  messageUtils.getSessionMsg(req, res);
  var usr = req.session.rcode.user;
  var params2 = {
    user_id:usr.id,
    url:nconf.get("url:tab"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:tab"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params2);

  var tableParams={
    corpId:usr.corporation_id
  };
  tabModel.getTabByCorpId(tableParams, function(tableData) {
    if(!tableData.aaData[0]){
      tabModel.Initialize(usr.corporation_id, function(err, result) {
        var msg;
        if (!result) {
          msg = messageUtils.msgError("初始化失败");
        } else {
          msg = messageUtils.msgSuccess("初始化成功");
        }
        console.log(result);
        return res.render('tab', {
          header: "追溯信息管理",
          msg: msg
        });
      });
    }else{
      return res.render('tab', {
        header: "追溯信息管理"
      });
    }
  });
});

router.get('/list', function(req, res, next) {

  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId = usr.corporation_id;

  tabModel.getTabByCorpId(tableParams, function(tableData) {
    return res.send(tableData);
  });
});

router.get('/update/:id/:state',function(req, res, next){
  var id=  req.params.id;
  var usr = req.session.rcode.user;
  var params = {
    id: id,
    state: req.params.state
  };
  tabModel.updateTabById(params, function(err, result){
    if(err){
      req.session.rcode.msg = messageUtils.msgError("修改失败");
      return res.redirect('/system/trace_tab');
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:tab"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:tab"),
        operate_id:id,
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("修改成功");
      return res.redirect('/system/trace_tab');
    }
  })
});

module.exports = router;
