var mysql = require("mysql"),
  logger = require('../utils/winstonUtils').logger,
  nconf = require('nconf');

var mysqlPool = null;

/**
 * init mysql pool
 * @return {null}
 */
function initMysqlPool() {
  mysqlPool = mysql.createPool({
            "host"      : nconf.get("mysql:host"),
            "user"      : nconf.get("mysql:user"),
            "password"  : nconf.get("mysql:password"),
            "database"  : nconf.get("mysql:database")
        });
}

/**
 * do mysql query
 * @param  {object}   sqlReq   the sql request obj
 * @param  {Function} callback the callback func
 * @return {null}
 */
exports.query = function(sqlReq, callback) {
  //sql, params
  if (!mysqlPool) {
    initMysqlPool();
  }

  if (!sqlReq) {
    throw new DBError("the sqlReq is null");
  }

  var sql_pattern = sqlReq.sql || "";
  if (sql_pattern.length === 0) {
    throw new DBError("the sql is empty");
  }

  mysqlPool.getConnection(function(err, connection) {

    if (err) {
      throw err;
    }

    connection.config.queryFormat = function(query, values) {
      if (!values) return query;
      return query.replace(/\:(\w+)/g, function(txt, key) {
        if (values.hasOwnProperty(key)) {
          return this.escape(values[key]);
        }
        return txt;
      }.bind(this));
    };

    connection.query(sql_pattern, sqlReq.params, function(err, rows) {
      logger.info(sql_pattern)
      logger.info(sqlReq.params ||'NO PARAMS');
      connection.release();
      return callback ? callback(err, rows): null;
    });
  });
};

/**
 * get mysql-connection for transaction
 * @param  {Function} callback the cb func
 * @return {null}
 */
exports.processTransaction = function(callback) {
  if (!mysqlPool) {
    initMysqlPool();
  }

  mysqlPool.getConnection(function(err, connection) {

    if (err) {
      throw err;
    }

    connection.config.queryFormat = function(query, values) {
      if (!values) return query;
      return query.replace(/\:(\w+)/g, function(txt, key) {
        if (values.hasOwnProperty(key)) {
          return this.escape(values[key]);
        }
        return txt;
      }.bind(this));
    };

    return callback(connection);
  });
};