$ pip --version
pip 1.5.6 from /usr/local/lib/python2.7/dist-packages/ (python 2.7)
