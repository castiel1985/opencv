"use strict";
var express = require('express');
var router = express.Router();
var patrolModel = require('../models/patrolModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {

  var serialId = req.serial_id;
  if (req.query["ajax"] === "1") {
    var params = {
      serialId: serialId,
      state: 1
    };
    patrolModel.getPatrolList(params, function (tableData) {
      return res.send(tableData.aaData);
    });
  } else {
    var opt = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:patrol"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:patrol"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('patrol', {
      header: "批次管理  > 巡检信息管理",
      serialId: serialId
    });
  }
});

router.get('/list', function (req, res, next) {

  var tableParams = dataTableObj.getParams(req);
  tableParams.serialId = req.serial_id;
  tableParams.state = 1;
  patrolModel.getPatrolList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.patrol_date = commonUtils.dateFormat(new Date(item.patrol_date));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {

  var serialId = req.serial_id;

  return res.render('patrol/add', {
    header: "批次管理  > 巡检信息管理 > 添加巡检信息",
    serialId: serialId
  });

});


router.post('/add', function (req, res, next) {
  var usr = req.session.rcode.user;
  var serialId = req.serial_id;

  var params = {
    creator: usr.id,
    serial_id: serialId,
    sub_serial_id: req.body.sub_serial_id,
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var images = [];
  pictureFiles && pictureFiles.forEach(function (item) {
    images.push(item.filename);
  });

  patrolModel.addPatrol(params, function (err, patrolId) {
    if (err) {
      return res.render('patrol/add', {
        header: "批次管理  > 巡检信息管理 > 添加巡检信息",
        msg: messageUtils.msgError("添加巡检信息失败"),
        serialId: serialId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:patrol"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:patrol"),
        operate_id: patrolId,
        content: {desc: req.body.desc, images: images.join(",")},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("添加巡检信息成功");
      return res.redirect("/work_manage/serials_manage/"+serialId+"/patrol/");
    }
  });


});


router.get('/view/:patrol_id', function (req, res, next) {
  var patrolId = req.params.patrol_id;
  if (underscore.isNaN(patrolId)) {
    return next(new Error("Invalid patrolId"));
  }
  patrolModel.getPatrolById(patrolId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    if (!!row) {
      row.patrol_time_fmt = commonUtils.dateFormat(new Date(row.patrol_date));
    }
    var opt = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:patrol"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:patrol"),
      operate_id: patrolId,
      content: {desc: row.desc},
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('patrol/view', {
      header: "巡检详情",
      patrol: row,
      layout: "partial/modal_layout"
    });
  });
});


router.get('/update/:patrol_id', function (req, res, next) {
  var serialId = req.serial_id;
  var patrolId = req.params.patrol_id;
  patrolModel.getPatrolById(patrolId, function (err, patrol) {
    if (err) {
      next(err);
    }
    var images = [];
    patrol.pictureFiles && patrol.pictureFiles.forEach(function(image){
      images.push(image.name);
    });

    return res.render('patrol/update', {
      header: "批次管理  > 巡检信息管理 > 修改巡检信息",
      serialId: serialId,
      patrol: patrol,
      images:images.join(",")
    });
  });
});

router.post('/update', function (req, res, next) {
  var serialId = parseInt(req.serial_id);
  var patrolId = req.body.patrolId;
  var usr = req.session.rcode.user;
  var delFileIds = req.body.delFileIds;

  var params = {
    id: patrolId,
    sub_serial_id: req.body.sub_serial_id || '',
    creator: usr.id,
    desc: req.body.desc || ''
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var old_images = req.body.old_images || "";
  var images = req.body.images || "";
  if(images == ","){
    images = "";
  }
  pictureFiles && pictureFiles.forEach(function (item) {
    if(images != ""){
      images += ","+item.filename;
    }else{
      images += item.filename;
    }
  });

  if (delFileIds) {
    commonModel.updateFilesState({state: 0}, delFileIds, function (err, result) {
      if (err || !result) {
        return res.render('patrol/update', {
          header: "批次管理  > 巡检信息管理 > 修改巡检信息",
          msg: messageUtils.msgError("巡检信息更新失败"),
          creator: req.session.rcode.user.id
        });
      }
    });
  }

  patrolModel.updatePatrol(params, function (err, patrolId) {
    if (err) {
      return res.render('patrol/update', {
        header: "批次管理  > 巡检信息管理 > 修改巡检信息",
        msg: messageUtils.msgError("巡检信息更新失败"),
        creator: req.session.rcode.user.id
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:patrol"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:patrol"),
        operate_id: patrolId,
        content: {desc: {old:req.body.old_desc,new:req.body.desc}, images: {old:old_images,new:images}},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("巡检信息更新成功");
      return res.redirect("/work_manage/serials_manage/"+serialId+"/patrol/");
    }
  });
});

router.get('/delete/:patrol_id', function (req, res, next) {
  var patrolId = req.params.patrol_id;
  var serialId = req.serial_id;
  patrolModel.delPatrolById(patrolId, function (err, row) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("巡检信息删除失败");
      return res.redirect("/work_manage/serials_manage/"+serialId+"/patrol/");
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:patrol"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:patrol"),
        operate_id:patrolId,
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("巡检信息删除成功");
      return res.redirect("/work_manage/serials_manage/"+serialId+"/patrol/");
    }
  });
});

module.exports = router;