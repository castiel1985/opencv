'use strict';
var express = require('express');
var session = require('express-session');
var path = require('path');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes');
var commonError = require("./utils/Error");
var commonUtils = require('./utils/Common');
var busboy = require("connect-busboy");
var logger = require('./utils/winstonUtils').logger;


var fs = require('fs'),
  nconf = require('nconf');

var app = express();

nconf.argv().env().file(
  { file: path.join(__dirname, '/config.json')},
  { file: path.join(__dirname, '/operate_logs.json')}
);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');
app.set('layout', 'layout');
//app.set('partials', {title:'i.Code'});
//app.enable('view cache');
app.engine('html', require('hogan-express'));

app.use(favicon(__dirname + '/public/images/favicon.ico'));
//app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public'), {
  dotfiles: 'ignore',
  extendtions: ['js', 'css', 'lang', 'ico', 'gif', 'png', 'jpg']
}));

app.use(busboy({
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB
  }
}));

app.use(session({
  resave: false,
  saveUninitialized: true,
  secret: nconf.get('secret'),
  key: "qrcode.sid",
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * parseInt(7, 10)
  }
}));

//REDIS INIT
/*require('./database/redis').init(function(err){
  if(err){
    logger.error(err.stack);
    process.exit();
  }
  routes(app);
});*/
routes(app);



//business code


// // catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Page Not Found: ' + req.url);
  err.status = 404;
  next(err);
});

function logErrors(err, req, res, next) {
  logger.info("reqIp: %s",commonUtils.getClientIp(req));
  logger.error(err.stack);
  next(err);
}

function clientErrorHandler(err, req, res, next) {
  if (req.xhr) {
    res.status(500);
    res.render('error', {
      error: "client Error"
    });
  } else {
    next(err);
  }
}

function errorHandler(err, req, res, next) {
  res.status(500);
  res.render('error', {
    error: err,
    layout: "partial/modal_layout"
  });

}



// error handlers
app.use(logErrors);
app.use(clientErrorHandler);
app.use(errorHandler);


module.exports = app;