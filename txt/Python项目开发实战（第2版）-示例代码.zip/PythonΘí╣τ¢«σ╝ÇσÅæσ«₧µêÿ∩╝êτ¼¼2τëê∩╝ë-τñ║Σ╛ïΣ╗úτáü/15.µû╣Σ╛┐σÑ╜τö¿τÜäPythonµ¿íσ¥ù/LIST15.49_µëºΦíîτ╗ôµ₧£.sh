$ python requests_get.py
{u'args': {u'foo': u'bar'},
 u'headers': {u'Accept': u'*/*',
              u'Accept-Encoding': u'gzip, deflate',
              u'Connection': u'keep-alive',
              u'Content-Length': u'',
              u'Content-Type': u'',
              u'Host': u'127.0.0.1:5000',
              u'User-Agent': u'python-requests/2.5.0 CPython/2.7.8 Linux/3.13.0-35-generic'},
 u'origin': u'127.0.0.1',
 u'url': u'http://127.0.0.1:5000/get?foo=bar'}
