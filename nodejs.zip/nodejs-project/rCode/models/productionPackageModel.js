"use strict";
/**
 * Created by dell on 2015/3/31.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;

function getPackagelist(tableParams,callback){
  var sqlData = "SELECT a.*,b.name as production_name,b.id as production_id,e.serial_no,f.serial_no as subserial_no,c.name as package_creator FROM qr_package a,qr_production b,qr_user c,qr_corporation d,qr_serials e,qr_serials f" +
    " WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and a.state =:state and a.serial_id = e.id and a.subserial_id = f.id ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_package a,qr_production b,qr_user c,qr_corporation d WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and b.name like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_package a,qr_production b,qr_user c,qr_corporation d WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and a.state =:state AND b.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function addPackage(options,callback){
  var sql='INSERT INTO qr_package (`production_id`,' +
    ' `serial_id`, ' +
    '`subserial_id` ,' +
    '`qrcode_apply_id` ,' +
    '`qrcode_start_id` ,' +
    '`package_count`,'+
    '`creator` ,' +
    '`state`,' +
    '`client_address`) values ' +
    '(:production_id,'+
    ':serial_id, ' +
    ':subserial_id ,' +
    ':qrcode_apply_id ,' +
    ':qrcode_start_id ,' +
    ':package_count,'+
    ':creator ,' +
    ':state ,' +
    ':client_address)';
  database.query({
    sql:sql,
    params:options
  },function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var packageId = result.insertId;
    logger.info("added production_package id = %d", packageId);
    return callback(null, packageId);
  });
}

function getPackageById(packageId,callback){
  var sql = "SELECT a.*,c.name as production,d.id as apply_id FROM qr_package a,qr_production c,qr_code_apply d"+
    " WHERE a.production_id=c.id and d.id = a.qrcode_apply_id and a.id = :packageId and a.state = :state";
  database.query({
    sql: sql,
    params: {
      packageId:packageId,
      state:1
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    logger.info(rows);
    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function getCorpApplyIds(corpId,callback){
  var sql = "SELECT id,qrcode_start,apply_count FROM qr_code_apply WHERE corporation_id = :corpId AND status = :status AND state = :state";
  database.query({
    sql: sql,
    params: {
      corpId:corpId,
      status:2,
      state:1
    }
  }, function(err, rows) {
    if (err || !rows) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function getApplyPackages(ids,callback){
  var sql = "SELECT id,qrcode_apply_id,qrcode_start_id,package_count FROM qr_package WHERE qrcode_apply_id IN ("+ids+") AND state = :state ORDER BY qrcode_apply_id,qrcode_start_id";
  database.query({
    sql: sql,
    params: {
      state:1
    }
  }, function(err, rows) {
    if (err || !rows) {
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

exports.getPackagelist = getPackagelist;
exports.addPackage = addPackage;
exports.getPackageById = getPackageById;
exports.getCorpApplyIds = getCorpApplyIds;
exports.getApplyPackages = getApplyPackages;