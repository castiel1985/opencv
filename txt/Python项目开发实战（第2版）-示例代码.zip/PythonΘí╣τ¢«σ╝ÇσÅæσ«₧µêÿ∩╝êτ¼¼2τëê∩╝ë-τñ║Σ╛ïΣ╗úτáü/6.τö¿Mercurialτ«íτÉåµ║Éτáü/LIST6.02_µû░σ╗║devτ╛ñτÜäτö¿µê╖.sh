$ sudo useradd -g dev <username>
