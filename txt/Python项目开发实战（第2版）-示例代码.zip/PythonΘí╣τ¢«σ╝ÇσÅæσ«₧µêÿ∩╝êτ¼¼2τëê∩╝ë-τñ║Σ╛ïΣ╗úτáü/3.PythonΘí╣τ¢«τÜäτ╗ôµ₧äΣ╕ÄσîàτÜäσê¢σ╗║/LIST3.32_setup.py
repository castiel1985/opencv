from setuptools import setup
setup(name='guestbook')
