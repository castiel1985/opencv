$ sudo apt-get install -y apache2 libapache2-mod-passenger
