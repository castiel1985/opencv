$ sudo gem install bundler --no-rdoc --no-ri
