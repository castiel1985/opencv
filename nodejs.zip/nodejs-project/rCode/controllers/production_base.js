"use strict";
var express = require('express');
var router = express.Router();
var productionModel = require('../models/productionModel');
var baseCodeModel = require('../models/baseCodeModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var nconf = require('nconf');
var fs = require("fs");
var codezip = require("../middleware/codezip");
var path = require('path');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');

router.get('/', function (req, res, next) {
  var usr = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params = {
      user:usr,
      userId: usr.id,
      corpId: usr.corporation_id,
      state: 1
    };
    productionModel.getProductionBaseList(params, function (tableData) {
      return res.send(tableData);
    });
  } else {
    var params2 = {
      user_id: usr.id,
      url: nconf.get("url:base"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:base"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
    messageUtils.getSessionMsg(req, res);
    return res.render('production_base', {
      header: "生产基地管理"
    });
  }
});

router.get('/list', function (req, res, next) {

  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;

  productionModel.getProductionBaseList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    if (!!tableData) {
      var corpQrCode = req.session.rcode.corporation.qrcode;
      tableData.aaData.forEach(function (item) {
        item.create_time = commonUtils.dateFormat(new Date(item.create_time));
        var qrcode = corpQrCode + "." + commonUtils.padZero(parseInt(item.id), 8) + "." + 1;
        item.qrcode = qrcode;
      });
    }
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {

  return res.render('production_base/add', {
    header: "生产基地管理 > 添加生产基地",
    creator: req.session.rcode.user.id
  });

});


router.post('/add', function (req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    creator: usr.id,
    name: req.body.name,
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  productionModel.addProductionBase(params, function (err, proBaseId) {
    if (err) {
      return res.render('production_base/add', {
        header: "生产基地管理  > 添加生产基地",
        msg: messageUtils.msgError("产品添加失败"),
        creator: req.session.rcode.user.id
      });
    } else {
      var corp = req.session.rcode.corporation;
      var codeparams = {
        corporation_id: corp.id,
        production_base_id: proBaseId,
        qrcode: corp.qrcode + "." + commonUtils.padZero(parseInt(proBaseId), 8) + ".1",
        type: 1,
        state: 1
      };
      baseCodeModel.insertQrCode(codeparams, null);

      productionModel.getProductionManufactureList({corpId: corp.id, state: 1, userId: usr.id,user:usr}, function (err, rows) {
        if (rows) {
          var codeparamsArr = [];
          rows.forEach(function (item) {
            var data = [];
            data.push(corp.id);
            data.push("'" + proBaseId + "'");
            data.push("'" + item.id + "'");
            data.push("'" + corp.qrcode + "." + commonUtils.padZero(parseInt(proBaseId), 8) + "." + commonUtils.padZero(parseInt(item.id), 8) + ".2" + "'");
            data.push(2);
            data.push(1);
            codeparamsArr.push("(" + data.join(",") + ")");
          });
          if (codeparamsArr.length > 0) {
            baseCodeModel.insertPatchQrCode(codeparamsArr);
          }
        }
      });
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:base"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:base"),
        operate_id: proBaseId,
        content: {name: req.body.name},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("生产基地添加成功");
      return res.redirect('/corp_info/base_manage');
    }
  });


});


router.get('/view/:production_id', function (req, res, next) {
  var productionId = req.params.production_id;
  productionModel.getProductionById(productionId, function (err, rows) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('production/view', {
      header: "生产基地详情",
      production: rows,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/view_qr_code/:production_base_id', function (req, res, next) {
  var productionBaseId = req.params.production_base_id;
  productionModel.getProductionBaseQrcode(productionBaseId, function (err1, baseQrcode) {
    if (err1) {
      return next(err1);
    }
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:base"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:manufacture_qrcode"),
      operate_id:productionBaseId,
      content:{name:baseQrcode.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    productionModel.getProductionManuQrcodeList(productionBaseId, function (err2, rows) {
      if (err2) {
        return next(err2);
      }
      messageUtils.getSessionMsg(req, res);
      return res.render('production_base/view_qrcode', {
        header: "生产/加工类型码",
        productionManufactureList: rows,
        baseQrCode: baseQrcode,
        layout: "partial/modal_layout"
      });

    });
  });

});

router.get('/delete/:production_base_id', function (req, res, next) {
  var productionBaseId = req.params.production_base_id;
  productionModel.delProductionBaseById(productionBaseId, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("生产基地删除失败");
      return res.redirect('/corp_info/base_manage');
    } else {
      req.session.rcode.msg = messageUtils.msgSuccess("生产基地删除成功");
      return res.redirect('/corp_info/base_manage');
    }
  });
});

router.get('/update/:production_base_id', function (req, res, next) {
  var productionBaseId = req.params.production_base_id;
  productionModel.getProductionBaseById(productionBaseId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('production_base/update', {
      header: "生产/加工类型管理 > 修改生产/加工类型",
      creator: req.session.rcode.user.id,
      proBase: row
    });
  });
});

router.post('/update/:production_base_id', function (req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var productionBaseId = req.params.production_base_id;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    name: req.body.name,
    desc: req.body.desc || ''
  };

  productionModel.updateProductionBase(params, productionBaseId, function (err, proBaseId) {
    if (err) {
      return res.render('production_base/update', {
        header: "生产基地管理  > 修改生产基地",
        msg: messageUtils.msgError("产品修改失败"),
        creator: req.session.rcode.user.id
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:base"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:base"),
        operate_id: productionBaseId,
        content: {name: {old: req.body.old_name, new: req.body.name}},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("生产基地修改成功");
      return res.redirect('/corp_info/base_manage');
    }
  });
});

router.get('/download/:production_base_id', function (req, res, next) {
  var productionBaseId = req.params.production_base_id;
  var dir = path.join(__dirname, "../public/qrcodedownload/manucode/");
  var zipName;
  var fullName;
  var contents = [];
  productionModel.getProductionBaseQrcode(productionBaseId, function (err1, baseQrcode) {
    if (err1) {
      return next(err1);
    }
    zipName = baseQrcode.name + "_生产加工类型码.zip";
    fullName = dir + zipName;
    productionModel.getProductionManuQrcodeList(productionBaseId, function (err2, rows) {
      if (err2) {
        return next(err2);
      }
      if (rows) {
        var params = {
          user_id:req.session.rcode.user.id,
          url:nconf.get("url:base"),
          action:nconf.get("action:download"),
          operate_type:nconf.get("operate_type:manufacture_qrcode"),
          operate_id:productionBaseId,
          content:{filename:zipName},
          state:1,
          client_address: commonUtils.getClientIp(req)
        };
        logsModel.addOperateLog(params);
        rows.forEach(function (item) {
          contents.push({name: item.name, value: item.qrcode});
        });
        codezip.qrCodeToZip(dir, zipName, contents, function (err, result) {
          if (result) {
            fs.exists(fullName, function (exists) {
              if (exists) {
                res.download(fullName, zipName);
              } else {
                req.session.rcode.msg = messageUtils.msgSuccess("文件生成中，请稍后再下载");
                return res.redirect('/corp_info/base_manage');
              }
            });
          } else {
            req.session.rcode.msg = messageUtils.msgSuccess("下载失败");
            return res.redirect('/corp_info/base_manage');
          }
        });
      } else {
        req.session.rcode.msg = messageUtils.msgSuccess("无可下文件");
        return res.redirect('/corp_info/base_manage');
      }
    });
  });
});

module.exports = router;