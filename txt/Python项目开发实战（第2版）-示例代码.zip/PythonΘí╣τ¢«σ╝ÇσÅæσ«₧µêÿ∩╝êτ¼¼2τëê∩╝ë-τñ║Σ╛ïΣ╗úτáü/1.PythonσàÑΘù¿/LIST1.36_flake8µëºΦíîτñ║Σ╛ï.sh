$ flake8 sample.py
sample.py:1:12: E401 multiple imports on one line
sample.py:1:17: E703 statement ends with a semicolon
sample.py:3:1: E302 expected 2 blank lines, found 1
sample.py:4:5: E265 block comment should start with '# '
sample.py:4:80: E501 line too long (83 > 79 characters)
sample.py:5:15: E225 missing whitespace around operator
