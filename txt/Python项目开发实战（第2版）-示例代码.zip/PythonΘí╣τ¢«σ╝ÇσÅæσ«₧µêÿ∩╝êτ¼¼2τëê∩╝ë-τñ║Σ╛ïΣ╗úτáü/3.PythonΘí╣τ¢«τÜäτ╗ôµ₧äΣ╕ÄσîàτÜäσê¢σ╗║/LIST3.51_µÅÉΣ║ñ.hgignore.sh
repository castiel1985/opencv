$ hg add .hgignore
$ hg ci -m "add ignore list"
