"use strict";
/**
 * Created by eric on 2015/3/30.
 */
var logger = require('../utils/winstonUtils').logger;
var commonUtils = require('../utils/Common');
var database = require('../database/mysql.js');
var path = require('path');
var fs = require('fs'), nconf = require('nconf');
nconf.argv().env().file({
  file:  path.join(__dirname, '../config.json')
});
var qrcodeModel = require('../models/qrcodeModel');
var codezip = require('./codezip');
var qrcodes = [];

function generateQRcodeList (corporation_id, corporation_qrcode, apply_id, code_start, code_number, code_type) {
  var list = [];
  var qrcode_prefix = corporation_qrcode + "." + commonUtils.padZero(parseInt(apply_id), 8);
  for (var i = 0; i < code_number; i++) {
    var qrcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(code_start) + i, 8) + "." + code_type;
    var fake_code = commonUtils.generateFakeCode(6);
    qrcodes.push({name:qrcode,value:qrcode,fake_code:fake_code});
    var code = [];
    code.push(corporation_id);
    code.push(apply_id);
    code.push("'" + corporation_qrcode + "'");
    code.push("'" + qrcode + "'");
    code.push("'" + fake_code + "'");
    code.push(code_type);
    code.push(1);
    list.push("(" + code.join(",") + ")");
  }
  return list;
}

function insertPatchQrCode(apply_id, vals) {
  if(vals && vals.length > 0) {
    var sqlPrex = "INSERT INTO qr_code (corporation_id, apply_id, corporation_qrcode, qrcode, fake_code, type, state) values ";
    var val;
    var start;
    var end;
    var sql;
    var total = Math.ceil((vals.length) / 1000);
    var num = 0;

    for (var i = 0; i < total; i++) {
      start = i * 1000;
      end = (i + 1) * 1000;
      if (i == total - 1) {
        val = vals.slice(start);
      } else {
        val = vals.slice(start, end);
      }
      sql = sqlPrex + val.join(",");
      qrcodeModel.insertQrcode(sql, function(err, result){
        if(err || !result){
          logger.error("add qr_code error ", err);
        }
        num += 1;
        if(num == total){
          toTxt(apply_id);
        }
      });
    }
    //toZip(apply_id);  图片压缩
  }
}

function getQrCodes(apply_id){
  qrcodeModel.queryApprovedQrcode({applyId:apply_id,state:1}, function(result){
    var codes = result.aaData;
    qrcodes = [];
    codes && codes.forEach(function(qrcode){
      qrcodes.push({name:qrcode.qrcode,value:qrcode.qrcode,fake_code:qrcode.fake_code});
    });
    toTxt(apply_id);
    //toZip(apply_id);  图片压缩
  });
}

function toZip(apply_id){
  var filePath = path.join(__dirname, "../public/qrcodedownload/productioncode/");
  var fileName = "apply_"+apply_id+".zip";
  var tmpName = "apply_"+apply_id+".tmp.zip";
  codezip.qrCodeToZip(filePath, tmpName,qrcodes, function(err, result){
    if(result){
      var oldName = path.join(filePath, tmpName);
      var newName = path.join(filePath, fileName);
      fs.renameSync(oldName,newName);
      process.send("kill child process");
    }
  });
}

function toTxt(apply_id){
  var filePath = path.join(__dirname, "../public/qrcodedownload/productioncode/");
  var txtName = "apply_"+apply_id+".txt";
  var txtTmpName = "apply_"+apply_id+".tmp.text";
  codezip.qrCodeTxt(filePath, txtTmpName, qrcodes, function (err, result){
    if(result){
      var oldName = path.join(filePath, txtTmpName);
      var newName = path.join(filePath, txtName);
      fs.renameSync(oldName,newName);
      process.send("kill child process");
    }
  });
}

var args = process.argv.splice(2);
if(args.length < 6){
  getQrCodes(args[0]);
}else{
  insertPatchQrCode(args[2], generateQRcodeList(args[0], args[1], args[2], args[3], args[4], args[5]));
}