(function($) {

  var UploaderFile = function($wrap,opts){
    var defaults = {
      maxFileNum: 10,
      btnLabel: "点击选择文件",
      continueBtnLabel: "继续添加",
      fileCount : 0
    }
    this.options = $.extend(defaults, opts);

    this.$wrap = $wrap;

    this.$list = this.$wrap.find(".filelist");
    this.$btn = this.$wrap.find('.ctxBtn');
    this.state = 'pending';
    this.uploader;
  }

  UploaderFile.prototype = {

    _init : function(){
      var _self = this;

      _self.uploader = WebUploader.create({
        resize: false,
        swf: '/bower_components/fex-webuploader/dist/Uploader.swf',
        server: '/api/upload_file',
        pick: {
          id: _self.$wrap.find('.picker')
        },
        accept: _self.options.accept,
        fileNumLimit: _self.options.fileNumLimit,
        fileSizeLimit: 100 * 1024 * 1024, // 100 M
        fileSingleSizeLimit: 50 * 1024 * 1024 // 50 M
      });

      // 当有文件添加进来的时候
      _self.uploader.on( 'fileQueued', function( file ) {
        _self.$list.append( '<div id="' + file.id + '" class="item">' +
        '<h4 class="info">' + file.name + '</h4>' +
        '<p class="state">等待上传...</p>' +
        '</div>' );
      });

      // 文件上传过程中创建进度条实时显示。
      _self.uploader.on( 'uploadProgress', function( file, percentage ) {
        var $li = $( '#'+file.id ),
          $percent = $li.find('.progress .progress-bar');

        // 避免重复创建
        if ( !$percent.length ) {
          $percent = $('<div class="progress progress-striped active">' +
          '<div class="progress-bar" role="progressbar" style="width: 0%">' +
          '</div>' +
          '</div>').appendTo( $li ).find('.progress-bar');
        }

        $li.find('p.state').text('上传中');

        $percent.css( 'width', percentage * 100 + '%' );
      });

      _self.uploader.on( 'uploadSuccess', function( file ) {
        $( '#'+file.id ).find('p.state').text('已上传');
      });

      _self.uploader.on( 'uploadError', function( file ) {
        $( '#'+file.id ).find('p.state').text('上传出错');
      });

      _self.uploader.onError = function(err) {
        var text;
        switch (err) {
          case 'Q_TYPE_DENIED':
            text = '文件格式不对，目前支持：MP4';
            break;
          case 'Q_EXCEED_NUM_LIMIT':
            text = '文件已超过限制总数';
            break;
          case 'F_EXCEED_SIZE':
            text = '单个文件超过50M限制大小';
            break;
          case 'Q_EXCEED_SIZE_LIMIT':
            text = '文件总和超过100M限制大小';
            break;
          case 'F_DUPLICATE':
            text = '文件重复';
            break;
          default:
            text = '文件错误，请重新选择';
            break;
        }
        alert(text);
      };

      _self.uploader.on( 'uploadComplete', function( file ) {
        $( '#'+file.id ).find('.progress').fadeOut();
      });

      _self.uploader.on( 'all', function( type ) {
        if ( type === 'startUpload' ) {
          _self.state = 'uploading';
        } else if ( type === 'stopUpload' ) {
          _self.state = 'paused';
        } else if ( type === 'uploadFinished' ) {
          _self.state = 'done';
        }

        if ( _self.state === 'uploading' ) {
          _self.$btn.text('暂停上传');
        } else {
          _self.$btn.text('开始上传');
        }
      });

      _self.$btn.on( 'click', function() {
        if ( _self.state === 'uploading' ) {
          _self.uploader.stop();
        } else {
          _self.uploader.upload();
        }
      });
    }
  };

  $.fn.uploaderFile = function(arg1, arg2) {
    var results = [];
    this.each(function () {
      var $this = $(this);
      var uploadObj = $this.data( "upload-box" );

      // Initialize a new tags input
      if (!uploadObj ) {
        uploadObj = new UploaderFile($this, arg1);
        $this.data( "upload-box", uploadObj );
        uploadObj._init();
      } else {
        var val;
        if(arg2 || arg2 === 0){
          val = uploadObj[arg1](arg2);
        }else{
          val = uploadObj[arg1]();
        }
        if(val) {
          results.push( val );
        }
      }
    });

    if (typeof arg1 === "string") {
      return ( results.length > 1 ) ? results : results[0];
    }
    return results;
  };
})(jQuery);
