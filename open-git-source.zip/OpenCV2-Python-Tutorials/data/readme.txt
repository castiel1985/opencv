This folder contains data files used in these tutorials.

Not all files are available. I had to format my system and lost many files. Some are taken from internet and I have put them in this folder. Some files are my own, so no way to recover them. 

Some video files are also missing.

Image
-------
lena.jpg
butterfly.jpg
home.jpg
messi5.jpg
left.jpg
right.jpg

Feature Matching	-	https://github.com/Itseez/opencv/blob/master/samples/c/box.png
			-	https://github.com/Itseez/opencv/blob/master/samples/c/box_in_scene.png

Background subtraction	-	https://github.com/Itseez/opencv/blob/master/samples/gpu/768x576.avi
