"use strict";

var logger = require('../utils/winstonUtils').logger;
var http = require("http");
var path = require('path');
var async = require("async");
var fs = require('fs'),
  nconf = require('nconf');

nconf.argv().env().file({
  file: path.join(__dirname, '../config.json')
});

var archiver = require('archiver');

//删除文件夹
function rmDir(folder) {
  var files = [];
  if( fs.existsSync(folder) ) {
    files = fs.readdirSync(folder);
    files.forEach(function(file,index){
      var curPath = path.join(folder, file);
      if(fs.statSync(curPath).isDirectory()) {
        rmDir(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(folder);
  }
}

function makeZipCollect(fullName,tmpDir, callback){
  var files = fs.readdirSync(tmpDir);
  var archive = archiver('zip');
  var output = fs.createWriteStream(fullName);
  archive.pipe(output);
  files.forEach(function(file){
    archive.append(fs.readFileSync(path.join(tmpDir, file)), {'name':file});
  });
  archive.finalize();
  output.on('close', function() {
    rmDir(tmpDir);
    callback(null, true);
  });
}

function makeZipBatch(fullName, tmpDir, contents, perNum, isBatch, callback){
  var params = {
    host: nconf.get("qr_service:host"),
    port: nconf.get("qr_service:port"),
    method: 'GET'
  };
  var archive = archiver('zip');
  var length = contents.length;
  var batchNum = Math.min(length, perNum);
  var batchContents = contents.splice(0, batchNum);
  var zipName;
  var start = parseInt(batchContents[0].value.substr(-10, 8));  //起始二维码名
  var to = parseInt(batchContents[batchNum - 1].value.substr(-10, 8));   //结束二维码名
  if(isBatch){
    zipName = path.join(tmpDir, start+"-"+to+".zip");
  }else{
    zipName = fullName;
  }
  var output = fs.createWriteStream(zipName);
  archive.pipe(output);
  async.map(batchContents, function(item, cb){
    if(item.value.substr(-2,2) == ".3"){
      params.path = nconf.get("qr_service:path") + nconf.get("server_host") + "/wap/trace/" + item.value ;
    }else{
      params.path = nconf.get("qr_service:path") + nconf.get("server_host") + item.value ;
    }
    var request = http.request(params, function (response) {
      var dataArr = [], len = 0;
      var contentType = response.headers["content-type"] || "image/jpg";
      contentType = contentType.split(";")[0];
      var type = contentType.split("/").length > 1 ? contentType.split("/")[1] : "jpg";
      response.on('data', function (chunk) {
        dataArr.push(chunk);
        len += chunk.length;
      });
      response.on('end', function (){
        cb(null,{"name":item.name +"." + type, "dataBuf": Buffer.concat(dataArr, len) });
      });
    });
    request.end();
  },function(err,results){
    results.forEach(function(result){
      archive.append(result.dataBuf,{'name':result.name});
    });
    archive.finalize();
    output.on('close', function() {
      if(contents.length > 0){
        makeZipBatch(fullName, tmpDir, contents, perNum, true, callback);
      }else{
        return callback(null, true);
      }
    });
  });
}


//统计二维码的个数，每1000个打包
function qrCodeToZip(filePath, fileName, contents, callback) {
  var total = contents.length;
  var fullName = path.join(filePath, fileName);
  var perNum = 1000;
  var folderName = fileName.replace(".zip","");
  var tmpDir = path.join(filePath, folderName);
  var isBatch = total > perNum ? true :false;  //是否超过1000
  if(!fs.existsSync(tmpDir) && total > perNum){
    fs.mkdirSync(tmpDir);
  }

  makeZipBatch(fullName, tmpDir, contents, perNum, isBatch, function(err, result){
    if(result && isBatch){
      makeZipCollect(fullName, tmpDir, function(err, result){
        return callback(null, result);
      });
    }else{
      return callback(null, true);
    }
  });
}

function qrCodeTxt(filePath, txtName, contents, callback){
  //contents 二维数组 存有二维码内容和防伪码
  var str = "";
  contents && contents.forEach(function ( item, index){
    if(item.value.substr(-2,2) == ".3"){
      item.value = nconf.get("server_host") + "/wap/trace/" + item.value;
    }
    if(index == (contents.length - 1)){
      str = str + item.value+","+item.fake_code;
    }else{
      str = str + item.value+","+item.fake_code+"\r\n";
    }
  });
  fs.writeFile(path.join(filePath, txtName), str, function (err){
    if(err) {
      return callback(null, err);
    }else{
      return callback(null, true);
    }
  });
}

exports.qrCodeTxt = qrCodeTxt;
exports.qrCodeToZip=qrCodeToZip;
exports.rmDir = rmDir;