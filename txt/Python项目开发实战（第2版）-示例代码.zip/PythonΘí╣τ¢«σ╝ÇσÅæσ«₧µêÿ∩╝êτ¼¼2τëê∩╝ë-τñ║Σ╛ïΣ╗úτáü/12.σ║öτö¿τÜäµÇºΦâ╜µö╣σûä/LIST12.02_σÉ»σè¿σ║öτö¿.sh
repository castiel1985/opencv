$ python guestbook.py
 * Running on http://127.0.0.1:8000/
 * Restarting with reloader
