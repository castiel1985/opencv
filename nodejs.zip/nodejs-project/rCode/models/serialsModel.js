"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;
var async = require('async');


function getSerialsList(tableParams, callback) {
  var sqlData = "select a.name as production_name ,b.* from qr_production a, qr_serials b, qr_user c, qr_corporation d where a.id = b.`production_id` and b.state = true " +
    " and b.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId))  ";
  var sqlCount = "SELECT count(*) as iTotalRecords from qr_production a, qr_serials b, qr_user c, qr_corporation d where a.id = b.`production_id` and b.state = true and a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.orderName == "production_name"){
    orderStr = " ORDER BY a.name " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and (b.serial_no like :search OR a.name like :search) " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords from qr_production a, qr_serials b, qr_user c, qr_corporation d where a.id = b.`production_id` and b.state = true and a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) AND (b.serial_no like :search OR a.name like :search) ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getSerialsListByProductionId(productionId, callback) {
  database.query({
    sql: "select a.name as production_name ,b.* from qr_production a, qr_serials b where a.id = b.`production_id` and b.state = :state " +
    " and a.id =:productionId order by b.create_time DESC ",
    params: {
      "productionId": productionId,
      state: 1
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getSerialsListByQrcode(qrcode, callback) {
  var sql = "";
  if(qrcode){
    if(qrcode.substr(-2,2) == ".1" || qrcode.substr(-2,2) == ".2"){
      sql = "select a.name as production_name, b.* from qr_production a, qr_serials b,qr_base_code c " +
      "where a.id=b.production_id and b.state=:state and c.production_base_id=b.base_id " +
      "and c.qrcode=:qrcode order by b.create_time DESC";
    }else if(qrcode.substr(-2,2) == ".3"){
      sql = "select a.name as production_name, b.* from qr_production a, qr_serials b,qr_code c,qr_code_apply d " +
      "where a.id=b.production_id and b.state=:state and a.id=d.production_id and c.apply_id=d.id " +
      "and c.qrcode=:qrcode order by b.create_time DESC";
    }else{
      return callback(null , null);
    }
    database.query({
      sql: sql,
      params: {
        "qrcode": qrcode,
        "state": 1
      }
    }, function(err, rows) {
      if (err || !rows) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }

      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    });
  }else{
    return callback(null , null);
  }
}

function getSerialsListByManufactureId(manufactureId, callback) {
  var sql = "select a.name as production_name, b.* from qr_production a, qr_serials b,qr_base_code c " +
    "where a.id=b.production_id and b.state=:state and c.production_base_id=b.base_id " +
    "and c.manufacture_id=:manufactureId order by b.create_time DESC";
  database.query({
    sql: sql,
    params: {
      "manufactureId": manufactureId,
      "state": 1
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function addSerials(options, callback) {
  var sql = 'INSERT INTO qr_serials (`production_id`,' +
    ' `serial_no`,' +
    ' `base_id`,' +
    ' `creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:production_id,' +
      ':serial_no,' +
      ':base_id,' +
      ':creator,' +
      'true,' +
      ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var serialsId = result.insertId;
    logger.info("added serials id = %d", serialsId);
    return callback(null, serialsId);
  });

}


function updateSerial(params,serialId, callback) {
  var sql_head = "UPDATE qr_serials SET ";
  var colums = [];
  for(var key in params){
    colums.push(key + "=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + serialId ;
  database.query({
    sql:sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}


function getSubSerialsList(tableParams, callback) {
  var sqlData = "SELECT * FROM qr_serials WHERE parent_serial_id = :parentSerialId AND state = :state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_serials WHERE parent_serial_id = :parentSerialId AND state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and serial_no like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_serials WHERE parent_serial_id = :parentSerialId AND state = :state AND serial_no like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function getSubSerials(id, callback) {
    database.query({
        sql: "select * from qr_serials where id = :id and state = :state ",
        params: {
            "id": id,
            "state" : 1
        }
    }, function(err, row) {
        if (err || !row) {
            logger.error(err ? err.stack : "row is null");
            return callback(new global.ServerError("Can't connect MySQL"), null);
        }

        if (row.length > 0) {
            return callback(null, row[0]);
        } else {
            return callback(null, null);
        }

  });
}

function addSubSerials(options, callback) {
  var sql = 'INSERT INTO qr_serials (`parent_serial_id`,' +
    ' `serial_no`, ' +
    ' `creator`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:parentSerialId,' +
    ':serial_no,' +
    ':creator,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var serialsId = result.insertId;
    logger.info("added serials id = %d", serialsId);
    return callback(null, serialsId);
  });

}

function bindProductionbase(params, callback) {
  var sql = "UPDATE qr_serials SET base_id=:productionBaseId where id=:serialId";
  database.query({
    sql:sql,
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "bind production base error!");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}

function getSerialsListByBaseId(tableParams, callback) {
  var sqlData = "select a.name as production_name ,b.* from qr_production a, qr_serials b where a.id = b.`production_id` and b.state = :state and b.base_id =:baseId ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords from qr_production a, qr_serials b where a.id = b.`production_id` and b.state = :state and b.base_id =:baseId ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr="";
  var pagFlag = true; //是否分页
  if(tableParams.orderName == "production_name"){
    orderStr = " ORDER BY a.name " + tableParams.orderDir;
  }else if(tableParams.orderName == "create_time_fmt"){
    orderStr = " ORDER BY b.create_time " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY b." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND b.serial_no like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords from qr_production a, qr_serials b where a.id = b.`production_id` and b.state = :state and b.base_id =:baseId AND b.serial_no like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(tableData.aaData);
    }
  });
}


function delSerialById(id,callback){
    database.query({
        sql: "UPDATE qr_serials SET state = 0 WHERE id = :id",
        params: {
            "id": id
        }
    }, function(err, result) {
        if (err || !result) {
            logger.error(err ? err.stack : "row is null");
            return callback(new global.ServerError("Can't connect MySQL"), null);
        }

        return callback(null, true);
    });
}

function getSerialsById(serilId, callback) {
  database.query({
    sql: "select a.*,b.name as base_name,c.name as production_name from qr_serials a,qr_production_base b,qr_production c " +
    "where a.base_id = b.id and a.production_id = c.id and a.state = 1 and a.id =:serilId ",
    params: {
      "serilId": serilId
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}




exports.updateSerial = updateSerial;
exports.addSerials = addSerials;
exports.getSerialsList = getSerialsList;
exports.addSubSerials = addSubSerials;
exports.getSubSerialsList = getSubSerialsList;
exports.getSubSerials = getSubSerials;
exports.bindProductionbase = bindProductionbase;
exports.getSerialsListByBaseId = getSerialsListByBaseId;
exports.delSerialById = delSerialById;
exports.getSerialsListByProductionId = getSerialsListByProductionId;
exports.getSerialsListByQrcode = getSerialsListByQrcode;
exports.getSerialsById = getSerialsById;
exports.getSerialsListByManufactureId = getSerialsListByManufactureId;