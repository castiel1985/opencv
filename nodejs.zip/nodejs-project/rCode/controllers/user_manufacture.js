"use strict";
var express = require('express');
var router = express.Router();
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var userManufactureModel = require('../models/userManufactureModel');
var userModel = require('../models/userModel');

router.get('/', function(req, res, next) {
  var usr = req.session.rcode.user;
  messageUtils.getSessionMsg(req, res);
  var params = {
    user_id:usr.id,
    url:nconf.get("url:user_manufacture"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:user_manufacture"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  return res.render('user_manufacture', {
    header: "流程权限管理"
  });
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId =usr.corporation_id;
  tableParams.state = 1;
  userManufactureModel.getUserManufactureByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {
  return res.render('user_manufacture/add', {
    header: " 流程权限管理 > 添加权限",
    creator: req.session.rcode.user.id
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    creator: usr.id,
    user_id: req.body.user_id,
    role_id: req.body.role_id,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  userManufactureModel.addUserManufacture( params, function ( err, id){
    if(err){
      return res.render('user_manufacture/add', {
        header: "流程权限管理 > 添加权限",
        msg: messageUtils.msgError("权限添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:user_manufacture"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:user_manufacture"),
        operate_id:id,
        content:{name:req.body.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("权限添加成功");
      return res.redirect('/system/user_manufacture');
    }
  });
});

router.get('/update/:id', function(req, res, next) {
  var id = req.params.id;
  userManufactureModel.getUserManufactureById(id, function(err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('user_manufacture/add', {
      header: " 流程权限管理 > 修改权限",
      creator: req.session.rcode.user.id,
      user_manufacture: row
    });
  });
});

router.post('/update/:id', function(req, res, next) {
  var usr = req.session.rcode.user;
  var id = req.params.id;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    id: id,
    user_id: req.body.user_id || "",
    role_id: req.body.role_id || ""
  };

  userManufactureModel.updateUserManufactureById( params, function ( err, result){
    if(err){
      return res.render('user_manufacture/add', {
        header: "流程权限管理 > 修改权限",
        msg: messageUtils.msgError("权限修改失败"),
        creator: creator
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:user_manufacture"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:user_manufacture"),
        operate_id:id,
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("权限修改成功");
      return res.redirect('/system/user_manufacture');
    }
  });
});

router.get('/delete/:id', function(req, res, next){
  var id = req.params.id;
  userManufactureModel.deleteUserManufactureById(id, function(err, result){
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("权限删除失败");
      return res.redirect('/system/user_manufacture');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:user_manufacture"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:user_manufacture"),
        operate_id:id,
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("权限删除成功");
      return res.redirect('/system/user_manufacture');
    }
  });
});

router.get('/user/:roleId', function (req, res, next){
  var usr = req.session.rcode.user;
  var role_id = req.params.roleId
  var params = {
    state: 1,
    corporationId: usr.corporation_id,
    roleId: role_id
  };
  userModel.getUsersByCorpIdAndRole(params, function(err, userlist){
    if(userlist){
      return res.send(userlist);
    }
  });
});


module.exports = router;