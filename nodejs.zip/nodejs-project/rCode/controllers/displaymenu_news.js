"use strict";
var express = require('express');
var router = express.Router();
var displaymenuModel = require('../models/displaymenuModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  messageUtils.getSessionMsg(req, res);
  return res.render('displaymenu_news', {
    header: "自定义栏目管理 > 新闻管理",
    displaymenuId: displaymenuId
  });
});

router.get('/list', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.displaymenuId = displaymenuId;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  var params = {
    user_id: usr.id,
    url: nconf.get("url:displaymenu_news"),
    action: nconf.get("action:view"),
    operate_type: nconf.get("operate_type:displaymenu_news"),
    operate_id: displaymenuId,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  displaymenuModel.getNewsListByDisplayMenuId(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/update/:newsId', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  var newsId = req.params.newsId;
  displaymenuModel.getNewsById(newsId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('displaymenu_news/update', {
      header: "自定义栏目管理 > 新闻管理 > 新闻修改",
      creator: req.session.rcode.user.id,
      displaymenuId: displaymenuId,
      news: row
    });
  });
});

router.post('/update/:newsId', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  var newsId = req.params.newsId;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    title: req.body.title,
    news: req.body.news || ''
  };

  displaymenuModel.updateNewsById(newsId, params, function (err, result) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("新闻修改失败");
      return res.redirect('/corp_propaganda/displaymenu/' + displaymenuId + '/displaymenu_news/update/' + newsId);
    } else {
      var params = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:displaymenu_news"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:displaymenu_news"),
        operate_id: newsId,
        content: {title: {old: req.body.old_title, new: req.body.title}},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(params);
      req.session.rcode.msg = messageUtils.msgSuccess("新闻修改成功");
      return res.redirect('/corp_propaganda/displaymenu/'+displaymenuId+'/displaymenu_news');    }
  });
});

router.get('/add', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  return res.render('displaymenu_news/add', {
    header: "自定义栏目管理 > 新闻管理 > 添加新闻",
    creator: req.session.rcode.user.id,
    displaymenuId: displaymenuId
  });
});

router.post('/add', function (req, res, next) {
  var displaymenuId = req.displaymenuId;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    creator: usr.id,
    displaymenu_id: displaymenuId,
    title: req.body.title,
    news: req.body.news || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  displaymenuModel.addNews(params, function (err, newsId) {
    if (err) {
      return res.render('department/add', {
        header: "自定义栏目管理 > 新闻管理 > 添加新闻",
        msg: messageUtils.msgError("新闻添加失败"),
        creator: req.session.rcode.user.id,
        displaymenuId: displaymenuId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:displaymenu_news"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:displaymenu_news"),
        operate_id: newsId,
        content: {title: req.body.title},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("新闻添加成功");
      return res.redirect('/corp_propaganda/displaymenu/'+displaymenuId+'/displaymenu_news');    }
  });
});

router.get('/view/:id', function (req, res, next) {
  var newsId = req.params.id;
  if (underscore.isNaN(newsId)) {
    return next(new Error("Invalid brandId"));
  }
  displaymenuModel.getNewsById(newsId, function (err, row) {
    if (err) {
      return next(err);
    }
    var params = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:displaymenu_news"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:displaymenu_news"),
      operate_id: newsId,
      content: {title: row.title},
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    messageUtils.getSessionMsg(req, res);
    return res.render('displaymenu_news/view', {
      header: "新闻详情",
      news: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/delete/:id', function (req, res, next) {
  var news = req.params.id;
  var displaymenuId = req.displaymenuId;
  displaymenuModel.deletNews(news, function (err, brand) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("新闻删除失败");
      return res.redirect('/corp_propaganda/displaymenu/displaymenu_news/' + displaymenuId);
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:displaymenu_news"),
        action: nconf.get("action:delete"),
        operate_type: nconf.get("operate_type:displaymenu_news"),
        operate_id: displaymenuId,
        content: {title: req.query['title']},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("新闻删除成功");
      return res.redirect('/corp_propaganda/displaymenu/'+displaymenuId+'/displaymenu_news');
    }
  });
});

router.get('/update/:newsId/status/:status', function (req, res, next) {
  var status = req.params.status;
  var newsId = req.params.newsId;
  var params = {
    status: status
  };

  var str = status === "1" ? "置顶" : "不置顶";

  displaymenuModel.updateNewsById(newsId, params, function (err, result) {
    if (err) {
      logger.info("置顶失败");
    } else {
      logger.info("置顶成功");
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:displaymenu_news"),
      action:nconf.get("action:update"),
      operate_type:nconf.get("operate_type:displaymenu_news"),
      operate_id:newsId,
      content:{status:str},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.send(result);
  });
});

module.exports = router;