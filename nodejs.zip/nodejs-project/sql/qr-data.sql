LOCK TABLES `qr_user` WRITE;
/*!40000 ALTER TABLE `qr_user` DISABLE KEYS */;

INSERT INTO `qr_user` (`id`,`name`, `corporation_id`, `username`, `passwd`, `salt`, `mail`, `mobile_phone`, `state`, `create_date`)
VALUES
  (1,'超级管理员',1,'admin','bf8e52421efc8e74c5f4ed1eadf8dd02d88bb729efaace0d4f0924339a090dc2','bdacea8e','admin@czinfo.com','18098987178',1,'2015-02-18 21:43:02');

/*!40000 ALTER TABLE `qr_user` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `qr_auth` WRITE;
/*!40000 ALTER TABLE `qr_auth` DISABLE KEYS */;

INSERT INTO `qr_auth` (`id`, `user_id`, `role_ids`, `type`)
VALUES
  (1,1,'1','user');

/*!40000 ALTER TABLE `qr_auth` ENABLE KEYS */;
UNLOCK TABLES;

/*!40000 ALTER TABLE `qr_corporation` DISABLE KEYS */;
INSERT INTO `qr_corporation` (`id`,`superior_id`,`name`,`region_id`,`qrcode`,`is_show_anti_fake`,`contact`,`telephone`,`email`,`address`,`state`,`share`,`is_auto_approve`,`creator`,`create_time`) VALUES
 (1,null,'管理员企业','321084','i.1.321084.032.0303020299',0,'黄先生','17717890987','huang@czinfo.com','琵琶东路 瑞和阳光城附近',1,1,0,null,'2015-05-26 21:35:07'),
 (2,null,'公共企业','321084','i.1.321084.032.2130596583',0,'黄先生','17717890987','huang@czinfo.com','琵琶东路 瑞和阳光城附近',1,0,1,null,'2015-05-26 21:35:07');
/*!40000 ALTER TABLE `qr_corporation` ENABLE KEYS */;

LOCK TABLES `qr_permissions` WRITE;
/*!40000 ALTER TABLE `qr_permissions` DISABLE KEYS */;

INSERT INTO `qr_permissions` (`id`, `name`, `url`, `identity`, `parent_id`, `ancestor_ids`, `weight`, `icon`, `state`,`has_child`, `create_date`)
VALUES
 (1,'系统管理','/system','',0,'',0,'fa-gears',1,1,'2015-02-24 19:21:35'),
 (2,'用户管理','/system/user_manage','user manage',1,'0/1',1,'',1,0,'2015-02-24 19:22:22'),
 (3,'用户审批','/system/user_approve','user approve',1,'0/1',2,'',1,0,'2015-02-24 19:22:22'),
 (4,'角色管理','/system/role_manage','role manage',1,'0/1',3,'',1,0,'2015-02-24 19:23:58'),
 (5,'追溯信息管理','/system/trace_tab','trace  manage',1,'0/1',4,'',1,0,'2015-02-24 19:23:58'),
 (6,'流程角色管理','/system/role_manufacture','role manufacture',1,'0/1',5,'',1,0,'2015-02-24 19:23:58'),
 (7,'流程权限管理','/system/user_manufacture','user manufacture',1,'0/1',6,'',1,0,'2015-02-24 19:23:58'),
 (10,'品牌管理','/brand','brand',0,'',1,'fa-building',1,0,'2015-02-24 19:26:49'),
 (20,'企业信息','/corp_info','corporation information',0,NULL,2,'fa-leaf',1,1,'2015-02-24 19:30:49'),
 (21,'产品管理','/corp_info/production_manage','production manage',20,'0/20',1,'',1,0,'2015-02-24 19:30:49'),
 (22,'经销商管理','/corp_info/dealer_manage','dealer manage',20,'0/20',2,'',1,0,'2015-03-08 11:21:54'),
 (23,'生产/加工类型管理','/corp_info/manufacture_manage','manufacture manage',20,'0/20',3,'',1,0,'2015-03-08 11:24:41'),
 (24,'生产基地管理','/corp_info/base_manage','base manage',20,'0/20',4,'',1,0,'2015-03-08 11:21:54'),
 (30,'防伪追溯','/work_manage','work manage',0,NULL,3,'fa-map-marker',1,1,'2015-02-24 19:31:42'),
 (31,'批次管理','/work_manage/serials_manage','serials manage',30,'0/30',1,'',1,0,'2015-02-24 19:32:36'),
 (32,'产品包装','/work_manage/production_package','production package',30,'0/30',2,'',1,0,'2015-02-24 19:32:36'),
-- (33,'产品销售','/work_manage/production_sales','production sales',30,'0/30',3,'',1,0,'2015-02-24 19:33:33'),
 (33,'配送管理','/work_manage/production_transmit','production_transmit',30,'0/30',3,'',1,0,'2015-02-24 19:33:33'),
 (40,'二维码管理','/qrcode','qrcode',0,NULL,4,'fa-qrcode',1,1,'2015-02-24 19:35:02'),
 (41,'二维码审批','/qrcode/approve','qrcode approve',40,'0/40',1,'',1,0,'2015-02-24 19:35:21'),
 (42,'二维码申请','/qrcode/apply','qrcode apply',40,'0/40',2,'',1,0,'2015-02-24 19:43:14'),
 (50,'企业宣传','/corp_propaganda','corporation propaganda',0,NULL,5,'fa-mobile',1,1,'2015-02-24 19:44:34'),
 (51,'基本信息','/corp_propaganda/introduction','introduction',50,'0/50',1,'',1,0,'2015-02-24 19:44:49'),
 (52,'公告管理','/corp_propaganda/advertisement','advertisement',50,'0/50',2,'',1,0,'2015-02-24 19:44:50'),
 (53,'栏目管理','/corp_propaganda/displaymenu','displaymenu',50,'0/50',3,'',1,0,'2015-02-24 19:44:50'),
 (54,'部门管理','/corp_propaganda/department','department',50,'0/50',4,'',1,0,'2015-02-24 19:44:51'),
 (55,'名片管理','/corp_propaganda/businesscard','businesscard',50,'0/50',5,'',1,0,'2015-02-24 19:44:52'),
 (60,'企业管理','/corp_manage','corporation manage',0,NULL,2,'fa-leaf',1,0,'2015-02-24 19:30:49'),
 (70,'数据查询','/data_query','data query',0,NULL,5,'fa-search',1,0,'2015-05-06 19:44:34'),
 (80,'日志审计','/operate_logs','operation logs',0,NULL,5,'fa-file',1,0,'2015-05-06 19:44:34');

/*!40000 ALTER TABLE `qr_permissions` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `qr_role` WRITE;
/*!40000 ALTER TABLE `qr_role` DISABLE KEYS */;

INSERT INTO `qr_role` (`id`, `name`, `identity`, `desc`, `state`, `create_date`)
VALUES
  (1,'管理员','admin','系统超级管理员',1,'2015-02-24 22:02:10'),
  (2,'企业管理员','corp-admin','企业管理员',1,'2015-02-24 22:02:47'),
  (3,'企业用户','corp','企业会员用户',1,'2015-02-24 22:02:47'),
  (4,'监管部门','supervisor','监管部门用户',1,'2015-02-24 22:03:25');

/*!40000 ALTER TABLE `qr_role` ENABLE KEYS */;
UNLOCK TABLES;



LOCK TABLES `qr_role_permission` WRITE;
/*!40000 ALTER TABLE `qr_role_permission` DISABLE KEYS */;

INSERT INTO `qr_role_permission` (`id`, `role_id`, `permission_id`)
VALUES
  (1,1,1),
  (2,1,60),
  (3,1,80),
  (4,2,1),
  (5,2,10),
  (6,2,20),
  (7,2,30),
  (8,2,40),
  (9,2,50),
  (10,2,70),
  (11,2,80),
  (12,3,30),
  (13,3,70),
  (14,4,1),
  (15,4,40),
  (16,4,60),
  (17,4,70),
  (18,4,80);

/*!40000 ALTER TABLE `qr_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

