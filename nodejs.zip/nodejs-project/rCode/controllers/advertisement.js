"use strict";
var express = require('express');
var router = express.Router();
var advertisementModel = require('../models/advertisementModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  return res.render('advertisement', {
    header: "自定义公告管理"
  });
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  var opt = {
    user_id:usr.id,
    url:nconf.get("url:advertisement"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:advertisement"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(opt);
  advertisementModel.getAdvertisementByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/update/:id', function(req, res, next) {
  var advertisementId = req.params.id;
  advertisementModel.getAdvertisementById(advertisementId, function(err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('advertisement/update', {
      header: "自定义公告管理 > 公告修改",
      creator: req.session.rcode.user.id,
      advertisement: row
    });
  });
});

router.post('/update/:id', function(req, res, next) {
  var advertisementId = req.params.id;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    id: advertisementId,
    title:req.body.title,
    content: req.body.content || ''
  };
  advertisementModel.updateAdvertisementById(params, function(err, result) {
    if(err){
      req.session.rcode.msg = messageUtils.msgError("公告信息修改失败");
      return res.redirect('/corp_propaganda/advertisement/update/'+advertisementId);
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:advertisement"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:advertisement"),
        operate_id:advertisementId,
        content:{name:{old:req.body.old_title,new:req.body.title}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("公告信息修改成功");
      return res.redirect('/corp_propaganda/advertisement');
    }
  });
});

router.get('/add', function(req, res, next) {
  return res.render('advertisement/add', {
    header: "自定义公告管理 > 公告添加",
    creator: req.session.rcode.user.id
  });
});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params = {
    creator: usr.id,
    corporation_id:usr.corporation_id,
    title: req.body.title,
    content: req.body.content || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  advertisementModel.addAdvertisement( params, function ( err, advertisementId){
    if(err){
      return res.render('advertisement/add', {
        header: "自定义公告管理 > 公告添加",
        msg: messageUtils.msgError("公告信息添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:advertisement"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:advertisement"),
        operate_id:advertisementId,
        content:{name:req.body.title},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("公告信息添加成功");
      return res.redirect('/corp_propaganda/advertisement');
    }
  });
});


router.get('/delete/:id', function(req, res, next) {

  var advertisementId = req.params.id;
  advertisementModel.deletAdvertisement(advertisementId, function(err, brand){
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("公告信息删除失败");
      return res.redirect('/corp_propaganda/advertisement');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:advertisement"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:advertisement"),
        operate_id:advertisementId,
        content:{name:req.query['title']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("公告信息删除成功");
      return res.redirect('/corp_propaganda/advertisement');
    }
  });
});

router.get('/view/:id', function (req, res, next) {
  var advertisementId = req.params.id;
  if (underscore.isNaN(advertisementId)) {
    return next(new Error("Invalid brandId"));
  }
  advertisementModel.getAdvertisementById(advertisementId, function (err, row) {
    if (err) {
      return next(err);
    }
    var params = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:advertisement"),
      action: nconf.get("action:view"),
      operate_type: nconf.get("operate_type:advertisement"),
      operate_id: advertisementId,
      content: {title: row.name},
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    messageUtils.getSessionMsg(req, res);
    return res.render('advertisement/view', {
      header: "公告详情",
      advertisement: row,
      layout: "partial/modal_layout"
    });
  });
});


module.exports = router;
