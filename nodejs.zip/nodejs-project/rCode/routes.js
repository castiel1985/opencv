'use strict';
var fs = require('fs'),
  nconf = require('nconf'),
  logger = require('./utils/winstonUtils').logger;

var userModel = require('./models/userModel');
var roleModel = require('./models/roleModel');
var async = require('async');
var auth = require('./middleware/auth');

//controllers
var index = require('./controllers/index'),

  gis = require('./controllers/gis'),
  api = require('./controllers/api'),
  wap = require('./controllers/wap'),

  notify = require('./controllers/notify'),
  admin = require('./controllers/admin'),
  home = require('./controllers/home'),
  brand = require('./controllers/brand'),
  template = require('./controllers/template'),
  transmit = require('./controllers/transmit'),

  production_package = require('./controllers/production_package'),
  sales = require('./controllers/sales'),
  production = require('./controllers/production'),
  production_base = require('./controllers/production_base'),
  production_manufacture = require('./controllers/production_manufacture'),
  corporation = require('./controllers/corporation'),
  corporation_introduction = require('./controllers/corporation_introduction'),
  serials = require('./controllers/serials'),
  subserials = require('./controllers/subserials'),
  qrcode_approve = require('./controllers/qrcode_approve'),
  qrcode = require('./controllers/qrcode'),
  dealers = require('./controllers/dealers'),
  patrol = require('./controllers/patrol'),
  region_brand = require('./controllers/region_brand'),
  report = require('./controllers/report'),
  serial_manufacture = require('./controllers/serial_manufacture'),
  department = require('./controllers/department'),
  advertisement = require('./controllers/advertisement'),
  displaymenu = require('./controllers/displaymenu'),
  displaymenu_news = require('./controllers/displaymenu_news'),
  businesscard = require('./controllers/businesscard'),
  query = require('./controllers/query'),
  propaganda = require('./controllers/propaganda'),

  test = require('./controllers/test'),

  users = require('./controllers/users'),
  operate_logs = require('./controllers/operate_logs'),
  tab = require('./controllers/tab'),
  role_manufacture = require('./controllers/role_manufacture'),
  user_manufacture = require('./controllers/user_manufacture');




/**
 * role required
 * @param req
 * @param res
 * @param next
 */
function role(req, res, next) {
  var bodyClass;
  if(req.cookies && req.cookies["sidebar_status"] == "1"){
    bodyClass = "skin-blue sidebar-mini sidebar-collapse";
  }else if(req.cookies && req.cookies["sidebar_status"] == "2"){
    bodyClass = "skin-blue sidebar-mini sidebar-open";
  }else{
    bodyClass = "skin-blue sidebar-mini";
  }
  if (!req.session.rcode.menuList) {
    var usr = req.session.rcode.user;
    async.series([
      function(callback) {
        userModel.getMenuIdByUser(usr, callback);
      },
      function(callback) {
        roleModel.getAllPermissions(callback);
      }
    ], function(err, result) {
      var usrPermissions = result[0];
      var allPermissions = result[1];

      usrPermissions.forEach(function(item) {
        for (var i = 0; i < allPermissions.length; i++) {
          var p = allPermissions[i];
          if (!usr.roleId) {
            usr.roleId = item.role_ids;
          }
          if (item.permission_id === p.id) {
            item.permission_id = p.id;
            item.icon = p.icon;
            item.name = p.name;
            item.url = p.url;
            item.has_child = p.has_child;
            item.weight = p.weight;
          }

          if (item.permission_id === p.parent_id) {
            item.hasChildren = true;
            item.children = item.children == null ? [] : item.children;
            //TODO 临时方案
            if((usr.isCorpAdmin && p.id == 41)||(usr.isSupervisor && p.id == 42)||(!usr.isSupervisor && p.id==3)||(!usr.isAdmin && p.id==4)||(!usr.isCorpAdmin && p.id == 5)||(!usr.isCorpAdmin && p.id == 6)||(!usr.isCorpAdmin && p.id == 7)){
              continue;
            }
            item.children.push({
              permission_id: p.id,
              icon: p.icon,
              name: p.name,
              url: p.url,
              has_child: p.has_child,
              parent_id: p.parent_id,
              weight: p.weight
            });
          }

        }
      });
      req.session.rcode.menuList = usrPermissions;
      res.locals.menuList = req.session.rcode.menuList;
      res.locals.bodyClass = bodyClass;
      res.locals.time_key = nconf.get("time_key");
      res.locals.ip_key = nconf.get("ip_key");
      next();
    });
  } else {
    res.locals.menuList = req.session.rcode.menuList;
    res.locals.bodyClass = bodyClass;
    res.locals.time_key = nconf.get("time_key");
    res.locals.ip_key = nconf.get("ip_key");
    next();
  }
}

module.exports = function(app) {
  app.locals.sitename = nconf.get('title');
  app.use('/', index);

  //open
  app.use('/api', api);
  app.use('/gis', gis);
  app.use('/wap', wap);

  //login
  app.use('/users', users);

  app.use('/test', test);
  app.use('/propaganda', propaganda);

  //authentication
  app.use('/notify', auth.userRequired, role, notify);
  app.use('/home', auth.userRequired, auth.authPermission, role, home);

  app.use('/system', auth.userRequired, auth.authPermission, auth.adminRequired, role, admin);
  app.use('/system/trace_tab', auth.userRequired, auth.authPermission, auth.adminRequired, role, tab);
  app.use('/system/user_manufacture', auth.userRequired, auth.authPermission, auth.adminRequired, role, user_manufacture);
  app.use('/system/role_manufacture', auth.userRequired, auth.authPermission, auth.adminRequired, role, role_manufacture);

  app.use('/corp_manage', auth.userRequired, auth.authPermission, role, corporation);
  app.use('/corp_propaganda/introduction', auth.userRequired, auth.authPermission, role, corporation_introduction);

  app.use('/brand', auth.userRequired, auth.authPermission, role, brand);

  app.use('/corp_info', auth.userRequired, auth.authPermission, role, corporation);
  app.use('/corp_info/production_manage', auth.userRequired, auth.authPermission, role, production);
  app.use('/corp_info/dealer_manage', auth.userRequired, auth.authPermission, role, dealers);
  app.use('/corp_info/manufacture_manage', auth.userRequired, auth.authPermission, role, production_manufacture);
  app.use('/corp_info/base_manage', auth.userRequired, auth.authPermission, role, production_base);

  app.use('/work_manage/serials_manage/:serialId/patrol', auth.userRequired, auth.authPermission, role, patrol);
  app.use('/work_manage/serials_manage/:serialId/report', auth.userRequired, auth.authPermission, role, report);
  app.use('/work_manage/serials_manage/:serialId/serial_manufacture', auth.userRequired, auth.authPermission, role, serial_manufacture);
  app.use('/work_manage/serials_manage', auth.userRequired, auth.authPermission, role, serials);
  app.use('/work_manage/serials_manage/:serialId/subserials', auth.userRequired, auth.authPermission, role, subserials);
  app.param('serialId',function(req,res,next,serialId){
    req.serial_id = serialId;
    next();
  });

  app.use('/work_manage/production_package', auth.userRequired, auth.authPermission, role, production_package);
  app.use('/work_manage/production_sales', auth.userRequired, auth.authPermission, role, sales);
  app.use('/work_manage/production_transmit', auth.userRequired, auth.authPermission, role, transmit);

  app.use('/qrcode/apply', auth.userRequired, auth.authPermission, role, qrcode);
  app.use('/qrcode/approve', auth.userRequired, auth.authPermission, role, qrcode_approve);

  app.use('/template', auth.userRequired, auth.authPermission, role, template);
  app.use('/corp_propaganda/advertisement', auth.userRequired, auth.authPermission, role, advertisement);
  app.use('/corp_propaganda/department', auth.userRequired, auth.authPermission, role, department);
  app.use('/corp_propaganda/displaymenu', auth.userRequired, auth.authPermission, role, displaymenu);
  app.use('/corp_propaganda/displaymenu/:displaymenuId/displaymenu_news', auth.userRequired, auth.authPermission, role, displaymenu_news);
  app.param('displaymenuId',function(req,res,next,displaymenuId){
    req.displaymenuId = displaymenuId;
    next();
  });
  app.use('/corp_propaganda/businesscard', auth.userRequired, auth.authPermission, role, businesscard);

  app.use('/data_query', auth.userRequired, auth.authPermission, role, query);
  app.use('/operate_logs', auth.userRequired, auth.authPermission, auth.adminRequired, role, operate_logs);

};