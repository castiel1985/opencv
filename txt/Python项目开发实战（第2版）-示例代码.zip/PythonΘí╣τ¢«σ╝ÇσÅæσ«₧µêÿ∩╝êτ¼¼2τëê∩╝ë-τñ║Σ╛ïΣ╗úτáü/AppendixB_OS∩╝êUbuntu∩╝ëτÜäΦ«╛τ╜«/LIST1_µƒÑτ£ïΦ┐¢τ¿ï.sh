$ ps aux | grep sshd
