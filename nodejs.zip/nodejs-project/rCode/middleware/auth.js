"use strict";
/**
 * Created by Alen on 15/2/28.
 * https://github.com/szanlin
 */
var roleModel = require('../models/roleModel');


/**
 * 需要管理员权限
 */
exports.adminRequired = function (req, res, next) {
  if (!req.session.rcode.user) {
    return res.redirect('/?code=NEED_LOGIN');
  }
  if (!req.session.rcode.user.isAdmin && !req.session.rcode.user.isCorpAdmin && !req.session.rcode.user.isSupervisor) {
    if(req.url.indexOf("profile") == -1){
      return res.redirect('/notify/noauth');
    }
  }
  next();
};

/**
 * 需要登录
 */
exports.userRequired = function (req, res, next) {
  if (!req.session.rcode || !req.session.rcode.user) {
    return res.redirect('/?code=NEED_LOGIN');
  }
  res.locals.user = req.session.rcode.user;
  next();
};

exports.blockUser = function () {
  return function (req, res, next) {
    if (req.path === '/logout') {
      return next();
    }
    if (req.session.rcode.user && req.session.rcode.user.isBlock && req.method !== 'GET') {
      return res.status(403).send('您已被管理员屏蔽了。有疑问请联系。');
    }
    next();
  };
};

/**
 * 需要管理员权限
 */
exports.authPermission = function (req, res, next) {
  if (!req.session.rcode.user) {
    return res.redirect('/?code=NEED_LOGIN');
  }

  var usr = req.session.rcode.user;
  roleModel.getUserPermissionUrl(usr.id, function(err, rows){
    if(!rows){
      return res.redirect('/notify/noauth');
    }
    var url = req.originalUrl;
    var permissionFlag = false;
    rows.forEach(function(item){
      if(url.indexOf(item.url) != -1){
        permissionFlag = true;
      }
    });

    //特殊情况处理
    //1.企业管理员有: 主页
    if(usr.isCorpAdmin && url.indexOf("home") != -1){
      permissionFlag = true;
    }
    //系统管理子菜单
    //2. admin:用户管理，角色管理  监管部门:用户管理，用户审批  企业管理员:用户管理
    if((usr.isAdmin || usr.isCorpAdmin) && url.indexOf("/system/user_approve") != -1){
      permissionFlag = false;
    }
    if((usr.isSupervisor || usr.isCorpAdmin) && url.indexOf("/system/role_manage") != -1){
      permissionFlag = false;
    }
    //二维码管理子菜单
    //3.监管部门:二维码审批   企业管理员:二维码申请
    if(usr.isSupervisor && url.indexOf("/qrcode/apply") != -1){
      permissionFlag = false;
    }
    if(usr.isCorpAdmin && url.indexOf("/qrcode/approve") != -1){
      permissionFlag = false;
    }
    //4.ajax请求为true
    if(req.query["ajax"] == 1){
      permissionFlag = true;
    }
    //5.数据查询结果，查看追溯信息
    var arr = ["/work_manage/production_transmit/scan/record","/work_manage/production_transmit/view/record","/sold_record","/work_manage/production_package/view","/qrcode/apply/view","/report/view","/patrol/view","/serial_manufacture/view"];
    arr.forEach(function(item){
      if(url.indexOf(item) != -1){
        permissionFlag = true;
      }
    });
    //6.查看产品详细信息
    if(url.indexOf("/corp_info/production_manage/view") != -1){
      permissionFlag = true;
    }
    //7.用户修改自己的信息
    if(req.url.indexOf("profile") != -1){
      permissionFlag = true;
    }

    if(!permissionFlag){
      return res.redirect('/notify/noauth');
    }
    next();
  });
};


