$ pip freeze > requirements.txt
