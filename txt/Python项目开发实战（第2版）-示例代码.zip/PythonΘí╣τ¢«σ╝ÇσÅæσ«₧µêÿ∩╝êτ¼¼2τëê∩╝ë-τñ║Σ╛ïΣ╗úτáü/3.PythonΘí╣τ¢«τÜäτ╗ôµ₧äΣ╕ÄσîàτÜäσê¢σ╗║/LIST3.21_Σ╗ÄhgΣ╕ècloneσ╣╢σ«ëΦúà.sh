$ pip install hg+https://bitbucket.org/shimizukawa/logfilter
