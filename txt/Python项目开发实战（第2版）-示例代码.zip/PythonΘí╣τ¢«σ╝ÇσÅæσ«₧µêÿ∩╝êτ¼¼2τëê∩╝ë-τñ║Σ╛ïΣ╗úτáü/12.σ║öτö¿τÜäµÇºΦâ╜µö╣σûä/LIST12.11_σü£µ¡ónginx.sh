$ sudo service nginx stop
