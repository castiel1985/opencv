$ hg branch
default
