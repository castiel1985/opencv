"use strict";
/**
 * Created by Alen on 15/4/3.
 * https://github.com/szanlin
 */
var logger = require('../utils/winstonUtils').logger;


(function(dataTableObj) {

  dataTableObj.getParams = function (req) {
    var reqParams = req.query;
    if(req.method.toUpperCase() == "POST"){
      reqParams = req.body;
    }
    var draw = reqParams.draw;
    var start = parseInt(reqParams.start);
    var length = parseInt(reqParams.length);
    var search = reqParams.search.value;
    var orderIndex =  reqParams.order[0].column;
    var orderName = reqParams.columns[orderIndex].name || reqParams.columns[orderIndex].data;
    var orderDir = reqParams.order[0].dir;
    var params = {
      draw: draw,
      start: start,
      length: length,
      search: search,
      orderIndex: orderIndex,
      orderName: orderName,
      orderDir: orderDir
    };
    return params;
  };


}(exports));

