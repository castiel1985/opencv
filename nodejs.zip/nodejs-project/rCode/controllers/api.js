"use strict";
var express = require('express');
var router = express.Router();
var storage = require('../utils/Storage');
var baseCodeModel = require('../models/baseCodeModel');
var productionModel = require('../models/productionModel');
var patrolModel = require('../models/patrolModel');
var serialsModel = require('../models/serialsModel');
var serialManuModel = require('../models/serialManufactureModel');
var dealerModel = require('../models/dealerModel');
var commonModel = require('../models/commonModel');
var salesModel = require('../models/salesModel');
var transmitModel = require('../models/transmitModel');
var productionPackageModel = require('../models/productionPackageModel');
var qrcodeModel =  require('../models/qrcodeModel');
var underscore = require('underscore');
var util = require('util');
var commonUtil = require('../utils/Common.js');
var userModel = require('../models/userModel');
var passwordHash = require('../utils/Password');
var path = require('path');
var logger = require('../utils/winstonUtils').logger;

var fs = require('fs'),
  nconf = require('nconf');

nconf.argv().env().file({
  file: path.join(__dirname, '../config.json')
});
var logsModel = require('../models/logsModel');
var async = require("async");

var ERROR_REASON = {
  illegal_user:"非法用户",
  database_error:"数据库错误",
  illegal_qrcode:"二维码错误",
  passwd_error:"用户名或密码错误",
  passwd_disagree:"两次输入的密码不一致",
  params_error:"字段错误",
  used_qrcode:"二维码已使用",
  no_send_error: "未发货,请先发货",
  sending_error: "已发货,请误重复操作",
  received_error: "已收货,不能进行操作",
  username_existed:"用户名已存在",
  location_error: "地址获取失败"
};

router.post('/validUserName/:username', function(req, res, next) {
  var username = req.body.username || req.params.username;
  var api_return = {
    "error" : true
  };
  userModel.uniqConfirm(username, function(err, result){
    if(result){
      api_return.reason = ERROR_REASON.username_existed ;
      return res.send(api_return);
    }else{
      api_return.error = false ;
      return res.send(api_return);
    }
  });
});

router.post('/register', function(req, res, next) {
  var username = req.body.username || req.params.username;
  var password = req.body.password || req.params.password;
  var client_address = req.body.client_address || req.params.client_address || commonUtil.getClientIp(req);
  var api_return = {
    "error" : true
  };
  var params = {
    username: username,
    corporation_id: nconf.get("public_corp_id"),
    name: username,
    mail: null,
    mobile: username,
    status: 1,//已审批
    client: 1,//手机端
    roleId: 2,//手机注册用户都是企业管理员
    client_address:client_address
  };

  var hashedPass = passwordHash.generate(password);
  var saved = passwordHash.getPasswdResult(hashedPass);

  params.salt = saved.salt;
  params.password = saved.password;

  userModel.addUser(params, function(err, result) {
    if (!err && result) {
      api_return.error = false;
      return res.send(api_return);
    } else {
      api_return.reason = ERROR_REASON.database_error;
      return res.send(api_return);
    }
  });
});

router.post('/upload_file', function(req, res, next) {
  req.busboy.on('file', function(fieldname, file, filename, encoding, mimetype) {
    storage.upload(file, {
      filename: filename
    }, function(err, result) {
      if (err) {
        return next(err);
      }
      //SAVED TO FILES TABLE
      var list = req.session.rcode.uploadedFile || [];
      list.push({
        "mimetype": mimetype,
        "url": result.url,
        "filename": filename
      });
      req.session.rcode.uploadedFile = list;

      res.json({
        error: false,
        url: result.url
      });
    });
  });

  req.pipe(req.busboy);

});

router.post('/upload_file_video', function(req, res, next) {
  req.busboy.on('file', function(fieldname, file, filename, encoding, mimetype) {
    storage.upload(file, {
      filename: filename
    }, function(err, result) {
      if (err) {
        return next(err);
      }
      //SAVED TO FILES TABLE
      var list = req.session.rcode.uploadedFileVideo || [];
      list.push({
        "mimetype": mimetype,
        "url": result.url,
        "filename": filename
      });
      req.session.rcode.uploadedFileVideo = list;

      res.json({
        success: true,
        url: result.url
      });
    });
  });

  req.pipe(req.busboy);

});


router.post('/login', function(req, res, next) {
  var api_return = {
    "error" : true,
    "reason": ERROR_REASON.passwd_error
  };
  var username = req.body.username || req.query.username;
  var password = req.body.password || req.query.password;
  var client_address = req.body.client_address || req.query.client_address || commonUtil.getClientIp(req);
  if (commonUtil.usernameCheck(username) && commonUtil.usernameCheck(password)) {
    userModel.getUserRoleByName({
      username: username
    }, function(err, userInfo) {
      if (err) {
        logger.error(err);
        return res.send(api_return);
      }
      if (userInfo == null) {
        logger.info(username + " 用户不存在");
        api_return.reason = username + " 用户不存在";
        return res.send(api_return);
      }
      if (userInfo.status == 0) {
        logger.info(username + " 用户未审批");
        api_return.reason = username + " 用户未审批";
        return res.send(api_return);
      }
      if (userInfo.status == 2) {
        logger.info(username + " 用户审批拒绝");
        api_return.reason = username + " 用户审批拒绝";
        return res.send(api_return);
      }
      if (userInfo.status == 3) {
        logger.info(username + " 用户已被禁用");
        api_return.reason = username + " 用户已被禁用";
        return res.send(api_return);
      }
      if (userInfo.client == 2) {
        logger.info(username + " 用户只能在PC端登录");
        api_return.reason = username + " 用户只能在PC端登录";
        return res.send(api_return);
      }
      //verify user's password
      if(passwordHash.verify(password,[passwordHash.algorithm,userInfo.salt,passwordHash.iterations,userInfo.passwd].join('$'))){
        var user = {
          "id": userInfo.id,
          "name": userInfo.name,
          "username":userInfo.username,
          "mail": userInfo.mail,
          "corporation_id":userInfo.corporation_id,
          "mobile_phone": userInfo.mobile_phone,
          "isAdmin": userInfo.identity === 'admin',
          "isCorpAdmin":  userInfo.identity === 'corp-admin',
          "isCorp": userInfo.identity === 'corp',
          "isSupervisor": userInfo.identity === 'supervisor'
        };

        var token_seed = util.format("%s%s%s",userInfo.id, Math.floor(Math.random() * 100), Date.now());
        user.token = commonUtil.hash('md5',token_seed,'hex');
        var opt = {
          user_id:user.id,
          url:nconf.get("url:member"),
          action:nconf.get("action:login"),
          operate_type:nconf.get("operate_type:member"),
          content:{username:user.username},
          state:1,
          client_address: client_address
        };
        logsModel.addOperateLog(opt);
        if(!req.session.rcode) {
          req.session.rcode = {};
        }
        req.session.rcode.user = user;
        return res.send(user);
      }else{
        return res.send(api_return);
      }
    });
  } else {
    return res.send(api_return);
  }
});

router.get('/logout', function(req, res, next) {
  var usr = req.session.rcode.user;
  res.send({
    "success": true
  });
});

function printHead(req) {
  var hd = req.headers;
  logger.info(hd);
}

function checkToken(req, str) {
  var token = req.headers["rooy_token"] || req.query["token"];
  var usr = req.session.rcode.user;
  if(usr && usr.token && token){
    return token == usr.token;
  }else{
    return false;
  }
}



router.get('/production/list', function(req, res, next) {
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    var usr = req.session.rcode.user;
    var params = {
      user:usr,
      userId:usr.id,
      corpId:usr.corporation_id,
      state:1
    };
    productionModel.getProductionList(params, function(err, rows) {
      if (err) {
        api_return.reason = ERROR_REASON.database_error;
        return res.send(api_return);
      }else{
        return res.send({
          "error":false,
          "production": rows
        });
      }
    });
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.get('/manufacture/list', function(req, res, next) {
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    var usr = req.session.rcode.user;
    var params = {
      user:usr,
      userId:usr.id,
      corpId:usr.corporation_id,
      state:1
    };
    productionModel.getProductionManufactureList(params, function(err, rows) {
      if (err) {
        api_return.reason = ERROR_REASON.database_error;
        return res.send(api_return);
      }else{
        return res.send({
          "error":false,
          "manufacture": rows
        });
      }
    });
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.get('/dealers/list/', function(req, res, next) {
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    var usr = req.session.rcode.user;
    var params = {
      userId:usr.id,
      corpId:usr.corporation_id,
      state:1
    };
    dealerModel.getDealerListByCorpId(params, function(err, rows) {
      if (err) {
        api_return.reason = ERROR_REASON.database_error;
        return res.send(api_return);
      }else{
        return res.send({
          "error":false,
          "dealers": rows
        });
      }
    });
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }

});

router.get('/serials_by_production/:production_id', function(req, res, next) {
  var productionId = req.params.production_id;
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    if(underscore.isNaN(productionId)){
      api_return.reason = ERROR_REASON.params_error;
      return res.send(api_return);
    }else{
      serialsModel.getSerialsListByProductionId(productionId, function(err, rows) {
        if(err){
          api_return.reason = ERROR_REASON.database_error;
          return res.send(api_return);
        }else{
          return res.send({
            "error":false,
            "serials":rows,
            "production_id": productionId
          });
        }
      });
    }
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.get('/serials_by_code/:qrcode', function(req, res, next) {
  var qrcode = req.params.qrcode;
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    if(underscore.isNaN(qrcode)){
      api_return.reason = ERROR_REASON.params_error;
      return res.send(api_return);
    }else{
      serialsModel.getSerialsListByQrcode(qrcode, function(err, rows) {
        if(err){
          api_return.reason = ERROR_REASON.database_error;
          return res.send(api_return);
        }else{
          return res.send({
            "error":false,
            "serials":rows,
            "qrcode": qrcode
          });
        }
      });
    }
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.get('/serials/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if (checkToken(req)) {
    var params = {
      userId: usr.id,
      corpId: usr.corporation_id ? usr.corporation_id : 0,
      state: 1
    };
    serialsModel.getSerialsList(params, function(tableData) {
      return res.send({
        "error":false,
        "serials":tableData.aaData
      });
    });
  } else {
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.get('/sub_serials/:parent_id', function(req, res, next) {
  var api_return = {
    "error" : true
  };
  var serialId = req.params.parent_id;
  if(checkToken(req)){
    if(underscore.isNaN(serialId)){
      api_return.reason = ERROR_REASON.params_error;
      return res.send(serialId);
    }else{
      var params = {
        parentSerialId:serialId,
        state:1
      };
      serialsModel.getSubSerialsList(params, function(err, rows) {
        if (err) {
          api_return.reason = ERROR_REASON.database_error;
          return res.send(api_return);
        }else{
          return res.send({
            "error":false,
            "sub_serials": rows,
            "parent_id": serialId
          });
        }
      });
    }
  }else{
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }

});

router.post('/manufacture/add', function(req, res, next) {
  var qrcode = req.body.qrcode || req.params.qrcode;
  var manufacture_id = req.body.manufacture_id || req.params.manufacture_id;
  var serial_id = req.body.serial_id || req.params.serial_id;
  var sub_serial_id = req.body.sub_serial_id || req.params.sub_serial_id;
  var desc = req.body.desc || req.params.desc;
  var images = req.body.images || req.params.images;
  var client_address = req.body.client_address || req.params.client_address || commonUtil.getClientIp(req);
  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if(!usr){
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
  if(!qrcode || !serial_id || !sub_serial_id){
    api_return.reason = ERROR_REASON.params_error;
    return api_return;
  }else if(checkToken(req)){
    if(manufacture_id && manufacture_id > -1){
      insertJob(res, api_return, usr, serial_id, sub_serial_id, manufacture_id, desc, images, client_address);
      return;
    }else{
      baseCodeModel.getBaseCodeInfoByCode(qrcode, function(err,codeinfo){
        if(err){
          api_return.reason = ERROR_REASON.database_error;
          return  res.send(api_return);
        }else if(codeinfo){
          if(codeinfo.manufacture_id){
            insertJob(res, api_return, usr, serial_id, sub_serial_id, codeinfo.manufacture_id, desc, images, client_address);
            return;
          }else{
            api_return.reason = ERROR_REASON.illegal_qrcode;
            return  res.send(api_return);
          }
        }else{
          api_return.reason = ERROR_REASON.illegal_qrcode;
          return  res.send(api_return);
        }
      });
    }
  }else{
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
});

function insertJob(res, api_return, usr, serial_id, sub_serial_id, manufacture_id, desc, images, client_address){
  var params = {
    creator: usr.id,
    serial_id: serial_id,
    sub_serial_id: sub_serial_id,
    manufacture_id: manufacture_id,
    desc: desc || '',
    state: 1,
    client_address:client_address
  };
  serialManuModel.addSerialManu(params,function(err,serialManuId){
    if(err){
      api_return.reason = ERROR_REASON.database_error;
      return  res.send(api_return);
    }else{
      api_return.error = false;
      if(images){
        var imgs = JSON.parse(images);
        imgs.forEach(function (item) {
          item.filename = item.name;
          item.mimetype = item.mine;
          item.creator = params.creator;
          item.type = 'serial_manu_picture_' + serialManuId;
          commonModel.insertFiles(item, null);
        });
      }
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:serial_manufacture"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:serial_manufacture"),
        operate_id: serialManuId,
        content: {desc: desc},
        state: 1,
        client_address: client_address
      };
      logsModel.addOperateLog(opt);
      return res.send(api_return);
    }
  });
}

router.post('/patrol/add', function(req, res, next) {
  var serial_id = req.body.serial_id || req.params.serial_id;
  var sub_serial_id = req.body.sub_serial_id || req.params.sub_serial_id;
  var desc = req.body.desc || req.params.desc;
  var images = req.body.images || req.params.images;
  var client_address = req.body.client_address || req.params.client_address || commonUtil.getClientIp(req);
  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if(!usr){
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
  if(!serial_id || !sub_serial_id){
    api_return.reason = ERROR_REASON.params_error;
    return  res.send(api_return);
  }
  if(checkToken(req)){
    var params = {
      creator: usr.id,
      serial_id: serial_id,
      sub_serial_id: sub_serial_id,
      desc: desc || '',
      state: 1,
      client_address:client_address
    };
    if(images){
      var imgs = JSON.parse(images);
      imgs.forEach(function (item) {
        item.filename = item.name;
        item.mimetype = item.mine;
      });
      params.pictureFiles = imgs;
    }
    patrolModel.addPatrol(params,function(err,patrolId){
      if(err){
        api_return.reason = ERROR_REASON.database_error;
        return  res.send(api_return);
      }else{
        var opt = {
          user_id: usr.id,
          url: nconf.get("url:patrol"),
          action: nconf.get("action:add"),
          operate_type: nconf.get("operate_type:patrol"),
          operate_id: patrolId,
          content: {desc: req.body.desc},
          state: 1,
          client_address: client_address
        };
        logsModel.addOperateLog(opt);
        api_return.error = false;
        return  res.send(api_return);
      }
    });
  }else{
    api_return.reason = ERROR_REASON.illegal_user;
    return res.send(api_return);
  }
});

router.post('/sold/add', function(req, res, next) {
  var dealer_id = req.body.dealer_id || req.params.dealer_id;
  var qrcode_start = req.body.qrcode_start || req.params.qrcode_start;
  var qrcode_end = req.body.qrcode_end || req.params.qrcode_end;
  var client_address = req.body.client_address || req.params.client_address || commonUtil.getClientIp(req);

  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if(!usr || !checkToken(req)){
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
  if( !dealer_id || !qrcode_start || !qrcode_end){
    api_return.reason = ERROR_REASON.params_error;
    return  res.send(api_return);
  }else if(qrcode_start.length < 20 || qrcode_end.length < 20 || qrcode_start.substr(0,qrcode_start.length-20)!=qrcode_end.substr(0,qrcode_end.length-20) || qrcode_start.substr(-2,2) != ".3"){
    api_return.reason = ERROR_REASON.illegal_qrcode;
    return  res.send(api_return);
  }else{
    async.waterfall([
      function(cb){
        productionModel.getProductionByCode(qrcode_start, function(err,production){
          if(!production){
            api_return.reason = ERROR_REASON.illegal_qrcode;
            return  res.send(api_return);
          }else{
            cb(err, production);
          }
        });
      },
      function(production, cb){
        var appayId = parseInt(qrcode_start.substr(-19, 8));
        var qrcode_start_id = parseInt(qrcode_start.substr(-10, 8));
        var qrcode_end_id = parseInt(qrcode_end.substr(-10, 8));

        var params = {
          production_id : production.id,
          dealer_id: dealer_id,
          qrcode_apply_id:appayId,
          qrcode_start_id:qrcode_start_id,
          sold_count: qrcode_end_id - qrcode_start_id + 1,
          creator: usr.id,
          status:0,
          state:1,
          client_address: client_address
        };
        var codeparams = {startcode:qrcode_start,endcode:qrcode_end};
        qrcodeModel.getQrcodeByCode(codeparams, "status =" + qrcodeModel.PRODUCTION_QRCODE_STATUS.packaged, function(err,codelist){
          if(codelist.aaData.length < params.sold_count) {
            api_return.reason = ERROR_REASON.illegal_qrcode;
            return res.send(api_return);
          }else{
            cb(err, params, codeparams);
          }
        });
      },function(params, codeparams, cb){
        qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.saled, codeparams, function(err, result) {
          if(!result){
            api_return.reason = ERROR_REASON.database_error;
            return  res.send(api_return);
          }else{
            cb(err,params);
          }
        });
      },function(params, cb){
        salesModel.addSoldRecord(params,function(err,soldrecordId){
          var opt = {
            user_id: req.session.rcode.user.id,
            url: nconf.get("url:sales"),
            action: nconf.get("action:add"),
            operate_type: nconf.get("operate_type:sales"),
            operate_id: soldrecordId,
            content: {sold_count: params.sold_count},
            state: 1,
            client_address: client_address
          };
          logsModel.addOperateLog(opt);
          api_return.error = false;
          return res.send(api_return);
          cb(err);
        });
      }
    ], function (err) {
      if(err){
        api_return.reason = ERROR_REASON.database_error;
        return  res.send(api_return);
      }else{
        api_return.error = false;
        return res.send(api_return);
      }
    });
  }
});

router.post('/transmit/add', function(req, res, next) {
  var qrcode = req.body.qrcode || req.params.qrcode;
  var scan_action = req.body.scan_action || req.params.scan_action;//上车 下车
  var longitude = req.body.longitude || req.params.longitude;
  var latitude = req.body.latitude || req.params.latitude;

  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if(!usr){
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
  if(!qrcode || !scan_action || !longitude || !latitude){
    api_return.reason = ERROR_REASON.params_error;
    return  res.send(api_return);
  }else{
    transmitModel.getTransmitRecordByCode(qrcode,function(err,transmitRecord){
      if(err){
        api_return.reason = ERROR_REASON.database_error;
        return  res.send(api_return);
      }else if(!transmitRecord){
        api_return.reason = ERROR_REASON.illegal_qrcode;
        return  res.send(api_return);
      }else if(transmitRecord.status == transmitModel.TRANSMIT_QRCODE_STATUS.no_send){
        if(scan_action == "2"){
          transmitModel.updateTransmitById(transmitRecord.id,{status:transmitModel.TRANSMIT_QRCODE_STATUS.sending},function (err, result){
            if(err){
              api_return.reason = ERROR_REASON.database_error;
              return  res.send(api_return);
            }else{
              api_return.error = false;
              return res.send(api_return);
            }
          });
        }else{
          api_return.reason = ERROR_REASON.no_send_error;
          return  res.send(api_return);
        }
      }else if(transmitRecord.status == transmitModel.TRANSMIT_QRCODE_STATUS.sending){
        if(scan_action == "2"){
          api_return.reason = ERROR_REASON.sending_error;
          return  res.send(api_return);
        }else if(scan_action == "3"){
          transmitModel.updateTransmitById(transmitRecord.id,{status:transmitModel.TRANSMIT_QRCODE_STATUS.received},function (err, result){
            if(err){
              api_return.reason = ERROR_REASON.database_error;
              return  res.send(api_return);
            }else{
              api_return.error = false;
              return res.send(api_return);
            }
          });
        }else{
          var params = {
            "transmit_qrcode":qrcode,
            "scan_action":scan_action,
            "scan_user":usr.id,
            "scan_latlng":longitude + "," + latitude
          };
          getLocation(longitude,latitude, function(err,location) {
            if (err) {
              api_return.reason = ERROR_REASON.location_error;
              return res.send(api_return);
            } else {
              params.scan_location = location;
              transmitModel.newScanRecord(params, function (err, scanRecord) {
                if (err) {
                  api_return.reason = ERROR_REASON.database_error;
                  return res.send(api_return);
                } else {
                  var opt = {
                    user_id: req.session.rcode.user.id,
                    url: nconf.get("url:transmit"),
                    action: nconf.get("action:add"),
                    operate_type: nconf.get("operate_type:transmit_records"),
                    operate_id: scanRecord,
                    content: {transmit_qrcode: qrcode, scan_action: scan_action, location: location},
                    state: 1,
                    client_address: location
                  };
                  logsModel.addOperateLog(opt);
                  api_return.error = false;
                  return res.send(api_return);
                }
              });
            }
          });
        }
      }else if(transmitRecord.status == transmitModel.TRANSMIT_QRCODE_STATUS.received){
        api_return.reason = ERROR_REASON.received_error;
        return  res.send(api_return);
      }else{
        api_return.reason = ERROR_REASON.database_error;
        return  res.send(api_return);
      }
    });
  }
});

router.post('/package/add', function(req, res, next) {

  var production_id = req.body.production_id || req.params.production_id;
  var serial_id = req.body.serial_id || req.params.serial_id;
  var sub_serial_id = req.body.sub_serial_id || req.params.sub_serial_id;
  var qrcode_start = req.body.qrcode_start || req.params.qrcode_start;
  var qrcode_end = req.body.qrcode_end || req.params.qrcode_end;
  var client_address = req.body.client_address || req.params.client_address || commonUtil.getClientIp(req);

  var usr = req.session.rcode.user;
  var api_return = {
    "error" : true
  };
  if(!usr || !checkToken(req)){
    api_return.reason = ERROR_REASON.illegal_user;
    return  res.send(api_return);
  }
  if(!production_id || !serial_id || !sub_serial_id || !qrcode_start || !qrcode_end){
    api_return.reason = ERROR_REASON.params_error;
    return  res.send(api_return);
  }else if(qrcode_start.length < 20 || qrcode_end.length < 20 || qrcode_start.substr(0,qrcode_start.length-20)!=qrcode_end.substr(0,qrcode_end.length-20) || qrcode_start.substr(-2,2) != ".3"){
    api_return.reason = ERROR_REASON.illegal_qrcode;
    return  res.send(api_return);
  }else{
    var appayId = parseInt(qrcode_start.substr(-19, 8));
    var qrcode_start_id = parseInt(qrcode_start.substr(-10, 8));
    var qrcode_end_id = parseInt(qrcode_end.substr(-10, 8));

    var params = {
      production_id : production_id,
      serial_id : serial_id,
      subserial_id : sub_serial_id,
      qrcode_apply_id:appayId,
      qrcode_start_id:qrcode_start_id,
      package_count: qrcode_end_id - qrcode_start_id + 1,
      creator: usr.id,
      state:1,
      client_address: client_address
    };
    var codeparams = {startcode:qrcode_start,endcode:qrcode_end};

    async.waterfall([
      function(cb){
        qrcodeModel.getQrcodeByCode(codeparams, "status = " + qrcodeModel.PRODUCTION_QRCODE_STATUS.no_use, function(err,codelist){
          if(codelist.aaData.length < params.package_count) {
            api_return.reason = ERROR_REASON.illegal_qrcode;
            return res.send(api_return);
          }else{
            cb(err, params, codeparams);
          }
        });
      },
      function(params, codeparams, cb){
        qrcodeModel.updateCodeStatus(qrcodeModel.PRODUCTION_QRCODE_STATUS.packaged, codeparams, function(err, result) {
          if(!result) {
            api_return.reason = ERROR_REASON.database_error;
            return  res.send(api_return);
          }else{
            cb(err, params);
          }
        });
      },
      function(params, cb){
        productionPackageModel.addPackage(params,function(err, packageId){
          var opt = {
            user_id: req.session.rcode.user.id,
            url: nconf.get("url:package"),
            action: nconf.get("action:add"),
            operate_type: nconf.get("operate_type:package"),
            operate_id: packageId,
            content: {package_count: params.package_count},
            state: 1,
            client_address: client_address
          };
          logsModel.addOperateLog(opt);
          cb(err);
        });
      }
    ], function (err) {
      if(err){
        api_return.reason = ERROR_REASON.database_error;
        return  res.send(api_return);
      }else{
        api_return.error = false;
        return res.send(api_return);
      }
    });
  }
});

router.get('/promote/data', function(req, res, next) {
  var promoteData = require('../mock/promote.json');
  var host = nconf.get("server_host");
  promoteData.forEach(function(item){
    if(item.picUrl && item.picUrl.indexOf(host) < 0){
      item.picUrl = host + item.picUrl;
    }
  });
  return res.send({"ads":promoteData});
});

function getLocation(longitude, latitude, callback){
  commonModel.getSiteByLatlng(longitude,latitude, function(err,location){
    if(err){
      callback(err,null);
    }else{
      callback(null,location);
    }
  });
}

module.exports = router;