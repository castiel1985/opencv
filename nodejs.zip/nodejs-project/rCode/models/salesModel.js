"use strict";
/**
 * Created by dell on 2015/3/31.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;

function getSoldRecordlist(tableParams, callback){
  var sqlData = "SELECT a.*,b.name as production_name,b.id as production_id,e.name as dealer,c.name as sold_creator FROM qr_sold_record a,qr_production b,qr_user c,qr_corporation d,qr_production_dealer e" +
    " WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and e.id = a.dealer_id and a.state =:state ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_sold_record a,qr_production b,qr_user c,qr_corporation d WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and a.state =:state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and b.name like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_sold_record a,qr_production b,qr_user c,qr_corporation d WHERE a.creator =c.id and d.id = c.corporation_id and ((d.share is true AND c.corporation_id = :corpId) || (d.share is false AND c.id = :userId)) and b.id = a.production_id and a.state =:state AND b.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function addSoldRecord(options,callback){
  var sql='INSERT INTO qr_sold_record (`production_id`,' +
    '`dealer_id` ,' +
    '`qrcode_apply_id` ,' +
    '`qrcode_start_id` ,' +
    '`sold_count`,'+
    '`creator` ,' +
    '`status` ,'+
    '`state`,' +
    '`client_address`) values ' +
    '(:production_id,'+
    ':dealer_id ,' +
    ':qrcode_apply_id ,' +
    ':qrcode_start_id ,' +
    ':sold_count,'+
    ':creator ,' +
    ':status ,'+
    ':state ,' +
    ':client_address)';
  database.query({
    sql:sql,
    params:options
  },function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var soldrecordId = result.insertId;
    logger.info("added soldRecord id = %d", soldrecordId);
    return callback(null, soldrecordId);
  });
}

function getSoldRecordById(soldrecordId,callback){
  var sql = "SELECT a.*,b.name as dealer_name,c.name as production,d.id as apply_id " +
    "FROM qr_sold_record a,qr_production_dealer b,qr_production c,qr_code_apply d"+
    " WHERE (a.production_id=c.id and a.dealer_id=b.id  and d.id = a.qrcode_apply_id and a.id =:soldrecordId) and a.state = :state";
  database.query({
    sql: sql,
    params: {
      soldrecordId:soldrecordId,
      state:1
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function updateSoldRecordStatus(params, recordIds, callback){
  var sql = "UPDATE qr_sold_record SET `status` =:status WHERE id in ("+recordIds+")";
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, true);
  });
}

exports.updateSoldRecordStatus = updateSoldRecordStatus;
exports.getSoldRecordById = getSoldRecordById;
exports.addSoldRecord = addSoldRecord;
exports.getSoldRecordlist = getSoldRecordlist;
