$ pip install pillow==2.6.1
