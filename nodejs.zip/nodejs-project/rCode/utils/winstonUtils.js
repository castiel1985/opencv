var winston = require('winston');
var path = require('path');
var fs = require('fs');
var commonUtils = require("./Common");

var logname = path.join(__dirname, '../logs/icode.log');

try {
  //fs.unlinkSync(logname);
} catch (ex) { }

var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.File)({
      filename: logname,
      level : 'info',
      maxsize: 1024*1024,
      timestamp: function(){
        return commonUtils.dateFormat(new Date());
      }
    })
  ],
  exitOnError:false
});
exports.logger = logger;