"use strict";
var express = require('express');
var router = express.Router();
var logger = require('../utils/winstonUtils').logger;
var messageUtils = require('../utils/Message');
var commonUtils = require('../utils/Common');
var dealerModel = require('../models/dealerModel');
var commonModel = require('../models/commonModel');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  var usr = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params = {
      user:usr,
      userId: usr.id,
      corpId: usr.corporation_id,
      state: 1
    };
    dealerModel.getDealerListByCorpId(params, function(err, tableData) {
      return res.send(tableData);
    });
  }else{
    var params2 = {
      user_id:usr.id,
      url:nconf.get("url:dealers"),
      action:nconf.get("action:index"),
      operate_type:nconf.get("operate_type:dealers"),
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
    messageUtils.getSessionMsg(req, res);
    return res.render('dealers', {
      header: "经销商管理"
    });
  }
});

router.get('/list', function(req, res, next){
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;

  dealerModel.getDealerListByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {

  return res.render('dealers/add', {
    header: "经销商管理 > 经销商添加",
    creator: req.session.rcode.user.id
  });

});

router.post('/add', function(req, res, next){
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params={
    creator : usr.id,
    name : req.body.name || '',
    region_id : req.body.category || '',
    type : req.body.type || '',
    address : req.body.address || '',
    location : req.body.location || '',
    note : req.body.note || '',
    state : 1,
    client_address: commonUtils.getClientIp(req)
  };


  dealerModel.addDealer(params,function(err,dealerId){
    if(err){
      return res.render('dealers/add', {
        header: "经销商管理 > 经销商添加",
        msg: messageUtils.msgError("经销商添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:dealers"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:dealers"),
        operate_id:dealerId,
        content:{name:req.body.name,address:req.body.address},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("经销商添加成功");
      return res.redirect('/corp_info/dealer_manage');
    }
  });

});

router.get('/getRegionList', function(req, res, next){
  commonModel.getRegionList( function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.send(rows);
  });
});

router.get('/update/:dealer_id', function(req, res, next) {
  var dealerId = req.params.dealer_id;
  dealerModel.getDealerById(dealerId, function(err, row) {
    if (err) {
      return next(err);
    }
    if(!!row){
      row.serial_manu_time_fmt = commonUtils.dateFormat(new Date(row.manu_date));
    }
    return res.render('dealers/update', {
      header: "经销商管理 > 经销商修改",
      dealer: row,
      creator: req.session.rcode.user.id
    });
  });
});

router.post('/update/:dealer_id', function(req, res, next){
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var dealerId = req.params.dealer_id;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }
  var params={
    name : req.body.name || '',
    region_id : req.body.category || '',
    type : req.body.type || '',
    address : req.body.address || '',
    location : req.body.location || '',
    note : req.body.note || ''
  };


  dealerModel.updateDealer(params, dealerId, function(err,result){
    if(err || !result){
      return res.render('dealers/update', {
        header: "经销商管理 > 经销商修改",
        dealer: result,
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:dealers"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:dealers"),
        operate_id:dealerId,
        content:{name:{old:req.body.old_name,new:req.body.name},address:{old:req.body.old_address,new:req.body.address}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("经销商修改成功");
      return res.redirect('/corp_info/dealer_manage');
    }
  });

});

router.get("/delete/:dealer_id", function(req, res, next){
  var dealerId = req.params.dealer_id;
  dealerModel.delDealerById(dealerId, function(err, result){
    if(err || !result){
      req.session.rcode.msg = messageUtils.msgSuccess("经销商删除失败");
      return res.redirect('/dealers');
    }else{
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:dealers"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:dealers"),
        operate_id:dealerId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("经销商删除成功");
      return res.redirect('/corp_info/dealer_manage');
    }
  });
});

router.get("/view/:dealer_id", function(req,res,next){
  var dealerId = req.params.dealer_id;
  dealerModel.getDealerById(dealerId, function(err, row) {
    if (err) {
      return next(err);
    }
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:dealers"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:dealers"),
      operate_id:dealerId,
      content:{name:row.name,address:row.address},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    return res.render('dealers/view', {
      dealer: row,
      layout: "partial/modal_layout"
    });
  });
});

module.exports = router;