poll = PollFactory.create(question_text='changed question')
