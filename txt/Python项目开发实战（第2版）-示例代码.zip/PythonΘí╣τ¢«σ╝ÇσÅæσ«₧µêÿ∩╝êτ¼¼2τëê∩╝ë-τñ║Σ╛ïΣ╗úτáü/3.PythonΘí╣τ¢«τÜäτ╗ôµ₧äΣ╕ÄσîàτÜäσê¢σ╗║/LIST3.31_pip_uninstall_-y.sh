$ pip uninstall -y flask
