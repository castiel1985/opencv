$ export PIP_DOWNLOAD_CACHE=~/.pip-cache
$ pip install requests
