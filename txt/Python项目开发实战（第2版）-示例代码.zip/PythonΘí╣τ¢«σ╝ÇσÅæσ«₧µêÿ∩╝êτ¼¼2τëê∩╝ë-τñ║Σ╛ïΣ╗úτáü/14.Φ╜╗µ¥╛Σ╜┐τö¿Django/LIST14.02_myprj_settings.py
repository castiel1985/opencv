INSTALLED_APPS = (
    ...

    'polls',
)
