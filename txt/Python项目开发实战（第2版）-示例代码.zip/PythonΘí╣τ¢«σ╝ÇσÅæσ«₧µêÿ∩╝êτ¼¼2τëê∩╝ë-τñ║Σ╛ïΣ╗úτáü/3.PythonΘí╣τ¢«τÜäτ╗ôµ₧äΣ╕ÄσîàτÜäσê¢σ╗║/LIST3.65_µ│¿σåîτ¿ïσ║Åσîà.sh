$ python setup.py register
