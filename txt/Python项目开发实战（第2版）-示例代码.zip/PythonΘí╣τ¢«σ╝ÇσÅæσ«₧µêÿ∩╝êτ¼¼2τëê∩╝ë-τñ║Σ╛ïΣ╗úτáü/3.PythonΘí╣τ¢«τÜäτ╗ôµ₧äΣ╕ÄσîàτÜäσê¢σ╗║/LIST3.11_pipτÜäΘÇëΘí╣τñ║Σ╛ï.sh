$ pip --quiet --proxy=server:9999 install --upgrade requests
