//分页插件
/**
2015-06-26 zq
**/
(function($){
	var ms = {
		init:function(obj,args){
			return (function(){
				ms.fillHtml(obj,args);
			})();
		},
		//填充html
		fillHtml:function(obj,args){
			return (function(){
				obj.empty();
				//上一页
				obj.append('<li><a href="#">&laquo;</a></li>');
        var current = parseInt(args.current);
        var pageCount = parseInt(args.pageCount);

				if(current-1 > 2 && current <= pageCount && pageCount > 5){
					obj.append('<li><span>...</span></li>');
				}
        var scount = 1;
        var ecount = 1;
        if(current <= 2 || current == pageCount - 2){
          ecount = 2;
        }
        if(current >= pageCount - 1 || current == 3){
          scount = 2;
        }
				var start = current - scount,end = current+ecount;
				if((start > 1 && current < 3) || current == 1){
					end++;
				}
				if(current > pageCount - 3 && current >= pageCount){
					start--;
				}
				for (;start <= end; start++) {
					if(start <= pageCount && start >= 1){
						if(start != current){
							obj.append('<li><a href="#">'+start+'</a></li>');
						}else{
							obj.append('<li class="active"><a href="#">'+start+'</a></li>');
						}
					}
				}

				if(current + 2 < pageCount && current >= 1 && pageCount > 5){
					obj.append('<li><span>...</span></li>');
				}
				//下一页
        obj.append('<li><a href="#">&raquo;</a></li>');
			})();
		}
	}
	$.fn.createPage = function(options){
		var args = $.extend({
			pageCount : 10,
			current : 1,
			backFn : function(){}
		},options);
		ms.init(this,args);
	}
})(jQuery);
