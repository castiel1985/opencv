"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require("./commonModel.js");

function addOperateLog(params){
  params.user_id = params.user_id || null;
  params.operate_type = params.operate_type || null;
  params.operate_id = params.operate_id || null;
  params.content = params.content ? JSON.stringify(params.content) : null;
  params.state = params.state || 1;
  params.client_address = params.client_address || null;
  var sql = "INSERT INTO qr_logs(`user_id`,`url`,`action`,`operate_type`,`operate_id`,`content`,`state`,`client_address`) "+
  "VALUES(:user_id,:url,:action,:operate_type,:operate_id,:content,:state,:client_address)";
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err,result){
      logger.info("add log success");
    }
  );
}

function getOperateLogs(tableParams, callback){
  var sql = "SELECT a.*,b.username,b.name FROM qr_logs a LEFT JOIN qr_user b ON b.id = a.user_id";
  var conn = [];
  var sql1 = "";
  if(tableParams.userId){
    conn.push(" a.user_id = :userId ");
  }else if(tableParams.userIds){
    conn.push(" a.user_id IN (" + tableParams.userIds + ") ");
  }

  if(tableParams.url){
    conn.push(" a.url = :url ");
  }
  if(tableParams.action){
    conn.push(" a.action = :action ");
  }
  if(tableParams.date_start){
    conn.push(" date_format(a.create_time,'%Y-%m-%d') >= :date_start ");
  }
  if(tableParams.date_end){
    conn.push(" date_format(a.create_time,'%Y-%m-%d') <= :date_end ");
  }
  if(conn.length > 0){
    sql1 = " WHERE " + conn.join("AND");
  }

  var sqlData = "SELECT a.*,b.username,b.name FROM qr_logs a LEFT JOIN qr_user b ON b.id = a.user_id " + sql1;
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_logs a " + sql1;
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  sqlData = sqlData + orderStr +" limit :start,:length ";
  sqlArr.push(sqlData);
  sqlArr.push(sqlCount);
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}


exports.addOperateLog = addOperateLog;
exports.getOperateLogs = getOperateLogs;
