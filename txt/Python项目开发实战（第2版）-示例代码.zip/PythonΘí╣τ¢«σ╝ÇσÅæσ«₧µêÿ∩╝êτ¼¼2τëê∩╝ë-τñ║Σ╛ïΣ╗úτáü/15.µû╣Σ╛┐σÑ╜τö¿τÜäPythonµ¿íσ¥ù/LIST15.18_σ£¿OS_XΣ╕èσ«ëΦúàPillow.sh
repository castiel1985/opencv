$ pip install pillow==2.6.1
Downloading/unpacking pillow==2.6.1
  Downloading Pillow-2.6.1-cp27-none-macosx_10_6_intel.macosx_10_9_intel.macosx_10_9_x86_64.whl (2.8MB): 2.8MB downloaded
Installing collected packages: pillow
Successfully installed pillow
Cleaning up...
