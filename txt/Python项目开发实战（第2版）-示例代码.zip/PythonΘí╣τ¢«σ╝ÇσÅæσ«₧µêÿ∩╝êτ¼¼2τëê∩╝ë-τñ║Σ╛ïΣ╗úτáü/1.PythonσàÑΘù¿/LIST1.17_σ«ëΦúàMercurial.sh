$ sudo pip install mercurial
