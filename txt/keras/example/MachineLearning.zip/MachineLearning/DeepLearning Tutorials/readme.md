DeepLearning Tutorials
--

- cnn_LeNet
- FaceRecognition_CNN(olivettifaces)
- mlp
- Softmax_sgd(or logistic_sgd)


以上每个文件夹下有两份代码，一份是Deeplearning网页上的教程的代码，另外一份带有 _commentate 后缀的是我所注释的，因为加入中文注释，显得比较杂乱，仅作帮助理解。真正使用代码时，请直接用原始的代码。

建议Theano用户转用Keras，不会让你失望，下面两份介绍Keras的基本使用。

- keras_usage
- dive _into _keras



