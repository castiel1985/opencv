"use strict";
var express = require('express');
var router = express.Router();
var serialManuModel = require('../models/serialManufactureModel');
var userManuModel = require('../models/userManufactureModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {

  var serialId = req.serial_id;
  if (req.query["ajax"] === "1") {
    var params = {
      serialId: serialId,
      state: 1
    };
    serialManuModel.getSerialManuList(params, function (tableData) {
      return res.send(tableData.aaData);
    });
  } else {
    var opt = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:serial_manufacture"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:serial_manufacture"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    var corp = req.session.rcode.corporation;
    return res.render('serial_manufacture', {
      header: "批次管理  > 批次生产/加工信息管理",
      serialId: serialId,
      corp:corp
    });
  }
});

router.get('/list', function (req, res, next) {
  var tableParams = dataTableObj.getParams(req);
  tableParams.serialId = req.serial_id;
  tableParams.state = 1;
  var userId = req.session.rcode.user.id;
  var manuIds = [];
  userManuModel.getUserManufactureByUserId({userId:userId, state:1}, function(err, rows){
    if(!err){
      rows && rows.forEach(function(item){
        manuIds.push(item.manufacture_id);
      });
      tableParams.manuIds = manuIds.join(",");
      serialManuModel.getSerialManuList(tableParams, function (tableData) {
        tableData.aaData && tableData.aaData.forEach(function (item) {
          item.manu_date = commonUtils.dateFormat(new Date(item.manu_date));
        });
        return res.send(tableData);
      });
    }
  })
});

router.get('/add', function (req, res, next) {

  var serialId = req.serial_id;
  return res.render('serial_manufacture/add', {
    header: "批次管理  > 批次生产/加工信息管理 > 添加批次生产/加工信息",
    serialId: serialId
  });
});


router.post('/add', function (req, res, next) {
  var usr = req.session.rcode.user;
  var serialId = req.serial_id;

  var params = {
    creator: usr.id,
    serial_id: serialId,
    sub_serial_id: req.body.sub_serial_id,
    manufacture_id: req.body.manufacture_id,
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };
  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var images = [];
  pictureFiles && pictureFiles.forEach(function (item) {
    images.push(item.filename);
  });

  serialManuModel.addSerialManu(params, function (err, serialManuId) {
    if (err) {
      return res.render('serial_manufacture/add', {
        header: " 批次管理  > 批次生产/加工信息管理 > 添加批次生产/加工信息",
        msg: messageUtils.msgError("添加批次生产/加工信息失败"),
        serialId: serialId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:serial_manufacture"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:serial_manufacture"),
        operate_id: serialManuId,
        content: {desc: req.body.desc, images: images.join(",")},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("添加批次生产/加工信息成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    }
  });


});


router.get('/view/:serial_manu_id', function (req, res, next) {
  var serialManuId = req.params.serial_manu_id;
  if (underscore.isNaN(serialManuId)) {
    return next(new Error("Invalid serialManuId"));
  }
  serialManuModel.getSerialManuById(serialManuId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    if (!!row) {
      row.serial_manu_time_fmt = commonUtils.dateFormat(new Date(row.manu_date));
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:serial_manufacture"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:serial_manufacture"),
      operate_id:serialManuId,
      content:{desc:row.desc},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('serial_manufacture/view', {
      header: "批次生产/加工信息详情",
      serialManu: row,
      layout: "partial/modal_layout"
    });
  });
});

//修改页面
router.get('/update/:serial_manu_id', function (req, res, next) {

  var serialId = req.serial_id;
  var serialManuId = req.params.serial_manu_id;
  serialManuModel.getSerialManuById(serialManuId, function (err, row) {
    if (err) {
      return next(err);
    }
    if (!!row) {
      row.serial_manu_time_fmt = commonUtils.dateFormat(new Date(row.manu_date));
    }
    var manuType = row.type;
    if (manuType == 0) {
      manuType = "生产";
    } else {
      manuType = "加工";
    }
    var images = [];
    row.pictureFiles && row.pictureFiles.forEach(function(image){
      images.push(image.name);
    });
    return res.render('serial_manufacture/update', {
      header: "批次管理  > 批次生产/加工信息管理 > 修改批次生产/加工信息",
      serialId: serialId,
      manuType: manuType,
      serialManu: row,
      images:images.join(",")
    });
  });
});

//保存修改
router.post('/update/:serial_manu_id', function (req, res, next) {
  var usr = req.session.rcode.user;
  var serialId = req.serial_id;
  var serialManuId = req.params.serial_manu_id;
  var delFileIds = req.body.delFileIds;

  var params = {
    creator: usr.id,
    desc: req.body.desc || '',
    sub_serial_id: req.body.sub_serial_id || '',
    manufacture_id: req.body.manufacture_id || ''
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var old_images = req.body.old_images || "";
  var images = req.body.images || "";
  if(images == ","){
    images = "";
  }
  pictureFiles && pictureFiles.forEach(function (item) {
    if(images != ""){
      images += ","+item.filename;
    }else{
      images += item.filename;
    }
  });

  if (delFileIds) {
    commonModel.updateFilesState({state: 0}, delFileIds, function (err, result) {
      if (err || !result) {
        return res.render('serial_manufacture/update', {
          header: "批次管理  > 批次生产/加工信息管理 > 修改批次生产/加工信息",
          msg: messageUtils.msgError("修改批次生产/加工信息失败"),
          serialId: serialId
        });
      }
    });
  }
  serialManuModel.updateSerialManu(params, serialManuId, function (err, result) {
    if (err || !result) {
      return res.render('serial_manufacture/update', {
        header: "批次管理  > 批次生产/加工信息管理 > 修改批次生产/加工信息",
        msg: messageUtils.msgError("修改批次生产/加工信息失败"),
        serialId: serialId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:serial_manufacture"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:serial_manufacture"),
        operate_id: serialManuId,
        content: {desc: {old: req.body.old_desc, new: req.body.desc}, images: {old: old_images, new: images}},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("修改批次生产/加工信息成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    }
  });
});

router.get('/delete/:serial_manu_id', function (req, res, next) {
  var serialManuId = req.params.serial_manu_id;
  var serialId = req.serial_id;
  if (underscore.isNaN(serialManuId)) {
    return next(new Error("Invalid serialManuId"));
  }
  serialManuModel.delSerialManu(serialManuId, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("删除批次生产/加工信息失败");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:serial_manufacture"),
        action: nconf.get("action:delete"),
        operate_type: nconf.get("operate_type:serial_manufacture"),
        operate_id: serialManuId,
        content: {desc: req.query['desc']},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("删除批次生产/加工信息成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    }
  });
});

router.get('/confirm/:serial_manu_id', function (req, res, next) {
  var serialManuId = req.params.serial_manu_id;
  var serialId = req.serial_id;
  var user = req.session.rcode.user;
  if (underscore.isNaN(serialManuId)) {
    return next(new Error("Invalid serialManuId"));
  }
  var confirm_date = commonUtils.dateFormat(new Date(), "yyyy-MM-dd hh:mm:ss");
  serialManuModel.confirmSerialManu(serialManuId, confirm_date, user.id, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("确认失败");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:serial_manufacture"),
        action: nconf.get("action:confirm"),
        operate_type: nconf.get("operate_type:serial_manufacture"),
        operate_id: serialManuId,
        content: {confirm_date: confirm_date},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("确认成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/serial_manufacture/');
    }
  });
});

module.exports = router;