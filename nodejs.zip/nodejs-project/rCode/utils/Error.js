/*
  #!/usr/local/bin/node
  -*- coding:utf-8 -*-
  Common Exceptions
 */

var nconf = require('nconf');
var util   = require("util");

function DataNotFoundError(message) {
    Error.call(this);
    this.name       = "DataNotFoundError";
    this.message    = message || "Data not found Error.";
    this.statusCode = nconf.get("statusCode:STATUS_NOTFOUND");
}

util.inherits(DataNotFoundError, Error);

function ServerError(message) {
    Error.call(this);
    this.name       = "ServerError";
    this.message    = message || "Server Error";
    this.statusCode = nconf.get("statusCode:STATUS_SERVER_ERROR");
}

util.inherits(ServerError, Error);

function InvalidParamError(message) {
    Error.call(this);
    this.name       = "InvalidParamError";
    this.message    = message || "InvalidParam Error";
    this.statusCode = nconf.get("statusCode:STATUS_INVAILD_PARAMS");
}

util.inherits(InvalidParamError, Error);

function InvalidUserError(message) {
    Error.call(this);
    this.name       = "InvalidUserError";
    this.message    = message || "InvalidUser Error";
    this.statusCode = nconf.get("statusCode:INVAILD_USER");
}

util.inherits(InvalidUserError, Error);

function PageNotFoundError (message) {
    Error.call(this);
    this.name       = "PageNotFoundError";
    this.message    = message || "InvalidParam Error";
    this.statusCode = 404;
}

util.inherits(PageNotFoundError, Error);

function DBError (message) {
    Error.call(this);
    this.name       = "DBError";
    this.message    = message || "DBError";
    this.statusCode = nconf.get("statusCode:STATUS_DBERROR");
}

util.inherits(DBError, Error);

global.ServerError       = ServerError;
global.InvalidParamError = InvalidParamError;
global.DataNotFoundError = DataNotFoundError;
global.PageNotFoundError = PageNotFoundError;
global.DBError           = DBError;
global.InvalidUserError  = InvalidUserError;