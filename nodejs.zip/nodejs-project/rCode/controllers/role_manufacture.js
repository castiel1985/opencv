"use strict";
var express = require('express');
var router = express.Router();
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var roleModel = require('../models/roleModel');
var productionModel = require('../models/productionModel');
var userManufactureModel = require('../models/userManufactureModel');

router.get('/', function(req, res, next) {
  var usr = req.session.rcode.user;
  messageUtils.getSessionMsg(req, res);
  if (req.query["ajax"] === "1") {
    var corpId = usr.corporation_id ? usr.corporation_id : req.query["corpId"];
    params = {
      corpId: corpId,
      state: 1
    };
    roleModel.getRoleList(params, function (tableData) {
      return res.send(tableData.aaData);
    });
  } else {
    var params = {
      user_id: usr.id,
      url: nconf.get("url:role_manufacture"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:role_manufacture"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
    return res.render('role_manufacture', {
      header: "流程角色管理"
    });
  }
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.corpId =usr.corporation_id;
  tableParams.state = 1;
  roleModel.getRoleList(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.create_date = commonUtils.dateFormat(new Date(item.create_date));
    });
    return res.send(tableData);
  });
});

router.get('/delete/:role_id', function(req, res, next){
  var roleId = req.params.role_id;

  roleModel.delRoleById(roleId,function(err, result){
    if(err || !result){
      return next(err);
    }
    userManufactureModel.deleteUserManufactureByRole(roleId,function (err, result){
      if(err || !result){
        return next(err);
      }
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:roles"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:roles"),
        operate_id:roleId,
        content:{name:req.query.roleName},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("角色删除成功");
      res.redirect('/system/role_manufacture');
    });
  });
});


router.get('/view/:role_id', function(req, res, next){
  var roleId = req.params.role_id;

  roleModel.getManufactureRoleById(roleId,function(err, row){
    if(err){
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:roles"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:roles"),
      operate_id:roleId,
      content:{name:row.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('role_manufacture/view', {
      role: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/add', function(req, res, next) {
  var corp = req.session.rcode.corporation;
  var user = req.session.rcode.user;
  var params = {
    corpId: corp.id ,
    user: user,
    userId: user.id,
    state: 1
  }
  productionModel.getProductionManufactureList(params, function(err, rows) {
    if (err) {
      return next(err);
    }

    return res.render('role_manufacture/add', {
      header: "角色管理 > 新建角色",
      manufactureList: rows
    });
  });
});

router.post('/add', function(req, res, next) {
  var corp = req.session.rcode.corporation;
  var params = {
    name: req.body.name,
    corpId: corp.id,
    identity: "",
    desc: req.body.desc,
    manufacture: req.body.manufacture.split(','),
    client_address: commonUtils.getClientIp(req)
  };

  roleModel.addManufactureRole(params, function(err, roleId) {
    if (!err && roleId) {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:roles"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:roles"),
        operate_id:roleId,
        content:{name:req.body.name,manufacture: req.body.manufacture.split(',')},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("新建角色成功");
      res.redirect('/system/role_manufacture');
    } else {
      return next(err);
    }
  });
});


router.get('/update/:roleId', function(req, res, next) {
  var corp = req.session.rcode.corporation;
  var user = req.session.rcode.user;
  var roleId = req.params.roleId;
  var manufactureList = [];
  var selected = [];
  var params = {
    corpId: corp.id ,
    user: user,
    userId: user.id,
    state: 1
  }
  productionModel.getProductionManufactureList(params, function(err, rows) {
    if (err) {
      return next(err);
    }
    roleModel.getManufactureRoleById(roleId,function(err, row){
      if (err) {
        return next(err);
      }
      rows.forEach(function (item1){
        var key = true;
        row.manufacture_id && row.manufacture_id.split(",").forEach(function (item2){
          if(item1.id == item2){
            key = false;
            selected.push({id: item1.id,name: item1.name});
          }
        });
        if(key){
          manufactureList.push({id: item1.id,name: item1.name});
        }
      });
      row.selected = selected;
      return res.render('role_manufacture/add', {
        header: "角色管理 > 新建角色",
        manufactureList: manufactureList,
        roleinfo: row
      });
    });
  });
});

router.post('/update/:roleId', function(req, res, next) {
  var corp = req.session.rcode.corporation;
  var user = req.session.rcode.user;
  var roleId = req.params.roleId;
  var old_selected = req.body.old_selected;

  var params = {
    roleId: roleId,
    name: req.body.name,
    desc: req.body.desc || "",
    Manufacture: req.body.manufacture.split(',')
  };
  roleModel.updateRoleManufactureList(old_selected, {roleId:roleId,state:0} , function (err, result) {
    if (err) {
      return next(err);
    }
    roleModel.updateManufactureRoleById(params, function (err, result) {
      if (err) {
        return next(err);
      } else {
        var opt = {
          user_id: req.session.rcode.user.id,
          url: nconf.get("url:roles"),
          action: nconf.get("action:update"),
          operate_type: nconf.get("operate_type:roles"),
          operate_id: roleId,
          content: {name: req.body.name, manufacture: req.body.manufacture.split(',')},
          state: 1,
          client_address: commonUtils.getClientIp(req)
        };
        logsModel.addOperateLog(opt);
        req.session.rcode.msg = messageUtils.msgSuccess("角色修改成功");
        res.redirect('/system/role_manufacture');
      }
    });
  });
});

module.exports = router;