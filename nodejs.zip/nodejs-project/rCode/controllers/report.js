"use strict";
var express = require('express');
var router = express.Router();
var reportModel = require('../models/reportModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {
  var serialId = req.serial_id;

  if (req.query["ajax"] === "1") {
    var params = {
      serialId: serialId,
      state: 1
    };
    reportModel.getReportList(params, function (tableData) {
      return res.send(tableData.aaData);
    });
  } else {
    var opt = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:report"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:report"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('report', {
      header: "批次管理  > 检验检测报告管理",
      serialId: serialId
    });
  }
});

router.get('/list', function (req, res, next) {

  var tableParams = dataTableObj.getParams(req);
  tableParams.serialId = req.serial_id;
  tableParams.state = 1;
  reportModel.getReportList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.report_date = commonUtils.dateFormat(new Date(item.report_date));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {

  var serialId = req.serial_id;

  return res.render('report/add', {
    header: "批次管理  > 检验检测报告管理 > 添加检验检测报告",
    serialId: serialId
  });

});


router.post('/add', function (req, res, next) {
  var usr = req.session.rcode.user;
  var serialId = req.serial_id;

  var params = {
    creator: usr.id,
    serial_id: serialId,
    sub_serial_id: req.body.sub_serial_id,
    title: req.body.title || '',
    desc: req.body.desc || '',
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var images = [];
  pictureFiles && pictureFiles.forEach(function (item) {
    images.push(item.filename);
  });

  reportModel.addReport(params, function (err, reportId) {
    if (err) {
      return res.render('report/add', {
        header: "批次管理  > 检验检测报告管理 > 添加检验检测报告",
        msg: messageUtils.msgError("添加检验检测报告失败"),
        serialId: serialId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:report"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:report"),
        operate_id: reportId,
        content: {title: req.body.title, images: images.join(",")},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("添加检验检测报告成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/report/');
    }
  });


});


router.get('/view/:report_id', function (req, res, next) {
  var reportId = req.params.report_id;
  if (underscore.isNaN(reportId)) {
    return next(new Error("Invalid reportId"));
  }
  reportModel.getReportById(reportId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    if (!!row) {
      row.report_time_fmt = commonUtils.dateFormat(new Date(row.report_date));
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:report"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:report"),
      operate_id:reportId,
      content:{title:row.title},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    return res.render('report/view', {
      header: "检验检测报告详情",
      report: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/update/:report_id', function (req, res, next) {

  var serialId = req.serial_id;
  var reportId = req.params.report_id;

  if (underscore.isNaN(reportId)) {
    return next(new Error("Invalid reportId"));
  }
  reportModel.getReportById(reportId, function (err, row) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    if (!!row) {
      row.report_time_fmt = commonUtils.dateFormat(new Date(row.report_date));
    }
    var images = [];
    row.pictureFiles && row.pictureFiles.forEach(function(image){
      images.push(image.name);
    });
    return res.render('report/update', {
      header: "批次管理  > 检验检测报告管理 > 修改检验检测报告",
      report: row,
      serialId: serialId,
      images:images.join(",")
    });
  });
});

//保存修改
router.post('/update/:report_id', function (req, res, next) {
  var usr = req.session.rcode.user;
  var serialId = req.serial_id;
  var reportId = req.params.report_id;
  var delFileIds = req.body.delFileIds;

  var params = {
    creator: usr.id,
    sub_serial_id: req.body.sub_serial_id || '',
    title: req.body.title || '',
    desc: req.body.desc || ''
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }

  var old_images = req.body.old_images || "";
  var images = req.body.images || "";
  if(images == ","){
    images = "";
  }
  pictureFiles && pictureFiles.forEach(function (item) {
    if (images != "") {
      images += "," + item.filename;
    } else {
      images += item.filename;
    }
  });

  if (delFileIds) {
    commonModel.updateFilesState({state: 0}, delFileIds, function (err, result) {
      if (err || !result) {
        return res.render('report/update', {
          header: "批次管理  > 检验检测报告管理 > 修改检验检测报告",
          msg: messageUtils.msgError("修改检验检测报告失败"),
          serialId: serialId
        });
      }
    });
  }

  reportModel.updateReport(params, reportId, function (err) {
    if (err) {
      return res.render('report/update', {
        header: "批次管理  > 检验检测报告管理 > 修改检验检测报告",
        msg: messageUtils.msgError("修改检验检测报告失败"),
        serialId: serialId
      });
    } else {
      var opt = {
        user_id: usr.id,
        url: nconf.get("url:report"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:report"),
        operate_id: reportId,
        content: {title: {old: req.body.old_title, new: req.body.title}, images: {old: old_images, new: images}},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("修改检验检测报告成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/report/');
    }
  });
});

//删除
router.get('/delete/:report_id', function (req, res, next) {
  var serialId = req.serial_id;
  var reportId = req.params.report_id;

  if (underscore.isNaN(reportId)) {
    return next(new Error("Invalid reportId"));
  }
  reportModel.delReportById(reportId, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("删除检验检测报告失败");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/report');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:report"),
        action: nconf.get("action:delete"),
        operate_type: nconf.get("operate_type:report"),
        operate_id: reportId,
        content: {title: req.query['title']},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("删除检验检测报告成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/report');
    }
  });
});

module.exports = router;