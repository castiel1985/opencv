"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require("./commonModel.js");

function getRegionBrandListByCorpId(tableParams, callback) {
  var sqlData = "select c.*,a.name as brand_name,b.name as full_name, b.short_name from qr_brand a, qr_production b, qr_region_brand c, qr_user d, qr_corporation e where c.brand_id = a.id and c.production_id = b.id and d.id = c.apply_user_id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords from qr_brand a, qr_production b, qr_region_brand c, qr_user d, qr_corporation e where c.brand_id = a.id and c.production_id = b.id and d.id = c.apply_user_id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr="";
  var pagFlag = true; //是否分页
  var orderStr;
  if(tableParams.orderName == "brand_name"){
    orderStr = " ORDER BY a.name " + tableParams.orderDir;
  }else if(tableParams.orderName == "full_name"){
    orderStr = " ORDER BY b.short_name " + tableParams.orderDir;
  }else if(tableParams.orderName == "short_name"){
    orderStr = " ORDER BY b.short_name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY c." + tableParams.orderName + " " + tableParams.orderDir;
  }

  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND b.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords from qr_brand a, qr_production b, qr_region_brand c, qr_user d, qr_corporation e where c.brand_id = a.id and c.production_id = b.id and d.id = c.apply_user_id and e.id = d.corporation_id and ((e.share is true AND d.corporation_id = :corpId) || (e.share is false AND d.id = :userId)) AND b.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(tableData.aaData);
    }

  });
}

function getBrandById(id, callback) {
  database.query({
    sql: "select a.*,b.url from qr_brand a,qr_file b where a.logo_file_id = b.id and" +
      " a.id =:id",
    params: {
      "id": id
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function addRegionBrand(options, callback) {
  var sql = 'INSERT INTO qr_region_brand (`brand_id`,' +
    ' `region_id`, ' +
    ' `production_id`, ' +
    ' `status`, ' +
    '`state`, ' +
    '`apply_user_id`) values ' +
    '(:brand_id,'+
    ':region_id,' +
    ':production_id,' +
    ':status,' +
    'true,' +
    ':apply_user_id)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var brandId = result.insertId;
    return callback(null, brandId);
  });

}

function updateBrand(options, callback) {
  var sql = 'UPDATE qr_brand SET name =:name,' +
    ' `desc` =:desc,' +
    ' other =:other,' +
    ' creator =:creator ' +
    'where id =:id';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var brandId = options.id;
    logger.info("added brand logo id = %d", brandId);

    if(options.files) {
      options.files.forEach(function (item) {
        item.creator = options.creator;
        item.type = 'brand_logo_' + brandId;
        insertFiles(item, brandId, callback);
      });
    }
    return callback(null, brandId);
  });

}

function insertFiles(opts, brandId, callback){
  var insert = "insert into qr_file (name,url,`type`,mime,creator,`state`) values (:filename,:url,:type,:mimetype,:creator,true)";
  database.query({
    sql: insert,
    params: opts
  },function(err, result){
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    updateLogoFileId(brandId, result.insertId, null);
  });
}

function updateLogoFileId(brandId, logoFileId, callback){
  var update = "update qr_brand set logo_file_id =:logoFileId where id =:id";
  database.query({
    sql: update,
    params: {
      id: brandId,
      logoFileId: logoFileId
    }
  },null); //just ignore errors! //TODO
}


exports.getRegionBrandListByCorpId = getRegionBrandListByCorpId;
exports.addRegionBrand = addRegionBrand;
exports.updateBrand = updateBrand;
exports.getBrandById = getBrandById;
