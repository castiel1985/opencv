"use strict";
var express = require('express');
var router = express.Router();
var productionModel = require('../models/productionModel');
var baseCodeModel = require('../models/baseCodeModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var async = require("async");
var commonModel = require('../models/commonModel');
var userManuModel = require('../models/userManufactureModel');

router.get('/', function (req, res, next) {

  var usr = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params = {
      user:usr,
      userId: usr.id,
      corpId: usr.corporation_id,
      state: 1,
      type: req.query["type"]
    };
    var manuIds = [];
    userManuModel.getUserManufactureByUserId({userId:usr.id, state:1}, function(err, rows){
      if(!err){
        rows && rows.forEach(function(item){
          manuIds.push(item.manufacture_id);
        });
        params.manuIds = manuIds.join(",");
        productionModel.getProductionManufactureList(params, function (err, tableData) {
          return res.send(tableData);
        });
      }
    })
  } else {

    var params2 = {
      user_id: usr.id,
      url: nconf.get("url:manufacture"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:manufacture"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
    messageUtils.getSessionMsg(req, res);
    return res.render('production_manufacture', {
      header: "生产/加工类型管理",
      corp: req.session.rcode.corporation
    });
  }

});

router.get('/list', function (req, res, next) {

  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;
  tableParams.type = req.query["type"];

  productionModel.getProductionManufactureList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {
  var corp = req.session.rcode.corporation;
  productionModel.getCorpMaxSort(corp.id, function(err, result){
    var sort_num = result.sort_num;
    return res.render('production_manufacture/add', {
      header: "生产/加工类型管理 > 添加生产/加工类型",
      creator: req.session.rcode.user.id,
      corp: corp,
      sort: sort_num
    });
  });
});

router.post('/add', function (req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var corp = req.session.rcode.corporation;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  async.waterfall([
    function(cb){
      productionModel.queryCorpSort(corp.id, req.body.sort, function(err, result){
        if(result){
          return res.render('production_manufacture/add', {
            header: "生产/加工类型管理 > 添加生产/加工类型",
            msg: messageUtils.msgError("生产/加工顺序"+req.body.sort+"已经存在"),
            creator: req.session.rcode.user.id,
            corp: corp
          });
        }else{
          cb(err);
        }
      })
    },
    function(cb){
      var params = {
        creator: usr.id,
        name: req.body.name,
        type: req.body.type || '',
        sort: req.body.sort || null,
        corporation_id:corp.id || null,
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };

      var pictureFiles = req.session.rcode.uploadedFile;
      if (pictureFiles) {
        //saved to db
        delete req.session.rcode.uploadedFile;
        params.pictureFiles = pictureFiles;
      }

      productionModel.addProductionManufacture(params, function (err, proManuId) {
        var type = req.body.type == "0" ? "生产" : "加工";
        var opt = {
          user_id: usr.id,
          url: nconf.get("url:manufacture"),
          action: nconf.get("action:add"),
          operate_type: nconf.get("operate_type:manufacture"),
          operate_id: proManuId,
          content: {type: type, name: req.body.name},
          state: 1,
          client_address: commonUtils.getClientIp(req)
        };
        logsModel.addOperateLog(opt);
        cb(err, proManuId)
      });
    }
  ], function (err, proManuId) {
    if(err){
      return res.render('production_manufacture/add', {
        header: "生产/加工类型管理 > 添加生产/加工类型",
        msg: messageUtils.msgError("生产/加工类型添加失败"),
        creator: req.session.rcode.user.id,
        corp: corp
      });
    }else{
      var params = {
        user:usr,
        userId: usr.id,
        corpId: usr.corporation_id,
        state: 1
      };
      productionModel.getProductionBaseList(params, function (rows) {
        if (rows) {
          var corp = req.session.rcode.corporation;
          var codeparamsArr = [];
          rows.forEach(function (item) {
            var data = [];
            data.push(corp.id);
            data.push("'" + item.id + "'");
            data.push("'" + proManuId + "'");
            data.push("'" + corp.qrcode + "." + commonUtils.padZero(parseInt(item.id), 8) + "." + commonUtils.padZero(parseInt(proManuId), 8) + ".2" + "'");
            data.push(2);
            data.push(1);
            codeparamsArr.push("(" + data.join(",") + ")");
          });
          if (codeparamsArr.length > 0) {
            baseCodeModel.insertPatchQrCode(codeparamsArr);
          }
        }
      });
      req.session.rcode.msg = messageUtils.msgSuccess("生产/加工类型添加成功");
      return res.redirect('/corp_info/manufacture_manage');
    }
  });
});


router.get('/view/:production_id', function (req, res, next) {
  var productionId = req.params.production_id;
  productionModel.getProductionById(productionId, function (err, rows) {
    if (err) {
      return next(err);
    }
    messageUtils.getSessionMsg(req, res);
    return res.render('production_manufacture/view', {
      header: "生产/加工类型详情",
      production: rows,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/update/:production_manufacture_id', function (req, res, next) {
  var proManuId = req.params.production_manufacture_id;
  productionModel.getProductionManuById(proManuId, function (err, row) {
    if (err) {
      return next(err);
    }

    var typeName = row.type;
    if (typeName == 0) {
      typeName = "生产";
    } else {
      typeName = "加工";
    }
    var images = [];
    row.pictureFiles && row.pictureFiles.forEach(function(image){
      images.push(image.name);
    });
    messageUtils.getSessionMsg(req, res);
    return res.render('production_manufacture/update', {
      header: "生产/加工类型管理 > 修改生产/加工类型",
      proManu: row,
      typeName: typeName,
      corp: req.session.rcode.corporation,
      images:images.join(",")
    });
  });
});

router.post('/update/:production_manufacture_id', function (req, res, next) {
  var proManuId = req.params.production_manufacture_id;
  var delFileIds = req.body.delFileIds;
  var params = {
    type: req.body.type,
    name: req.body.name,
    sort: req.body.sort
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if (pictureFiles) {
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
    params.creator = req.session.rcode.user.id;
  }

  var old_images = req.body.old_images || "";
  var images = req.body.images || "";
  if(images == ","){
    images = "";
  }
  pictureFiles && pictureFiles.forEach(function (item) {
    if(images != ""){
      images += ","+item.filename;
    }else{
      images += item.filename;
    }
  });

  if (delFileIds) {
    commonModel.updateFilesState({state: 0}, delFileIds, function (err, result) {
      if (err || !result) {
        return res.render('serial_manufacture/update', {
          header: "批次管理  > 批次生产/加工信息管理 > 修改批次生产/加工信息",
          msg: messageUtils.msgError("修改批次生产/加工信息失败"),
          serialId: serialId
        });
      }
    });
  }

  productionModel.updateProductionManu(params, proManuId, function (err, row) {
    if (err) {
      return res.render('production_manufacture/update', {
        header: "生产/加工类型管理 > 修改生产/加工类型",
        msg: messageUtils.msgError("生产/加工类型修改失败")
      });
    } else {
      var type = req.body.type == "0" ? "生产" : "加工";
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:manufacture"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:manufacture"),
        operate_id: proManuId,
        content: {
          type: {old: req.body.old_type, new: type},
          name: {old: req.body.old_name, new: req.body.name}
        },
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("生产/加工类型修改成功");
      return res.redirect('/corp_info/manufacture_manage');
    }

  });
});

router.get('/delete/:production_manufacture_id', function (req, res, next) {
  var proManuId = req.params.production_manufacture_id;
  productionModel.delProductionManuById(proManuId, function (err, result) {
    if (err || !result) {
      req.session.rcode.msg = messageUtils.msgSuccess("生产/加工类型删除失败");
      return res.redirect('/production_manufacture');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:manufacture"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:manufacture"),
        operate_id:proManuId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("生产/加工类型删除成功");
      return res.redirect('/corp_info/manufacture_manage');
    }
  });
});

module.exports = router;