"use strict";
/**
 * Created by Alen on 15/2/18.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var async = require('async');
var commonModel = require('./commonModel.js');


function saveRolePermission(roleId,permissionId){
  var insert = "insert into qr_role_permission (role_id,permission_id) values (:roleId,:permissionId)";
  database.query({
    sql: insert,
    params:{roleId:roleId,permissionId:permissionId}
  },null); //just ignore errors! //TODO
}

function addRole(options, callback) {
  var sql = 'INSERT INTO qr_role (name, `desc`, identity, state, client_address) values ' +
    '(:name,:desc,:identity,true, :client_address)';
  database.query({
    sql: sql,
    params:options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var roleId = result.insertId;
    logger.info("added role id = %d",roleId);
    //insert role-permissions
    options.permissions.forEach(function(item){
      saveRolePermission(roleId,item);
    });
    return callback(null, roleId);
  });
}

function saveRoleManufacture(roleId,manufactureId){
  var insert = "insert into qr_role_manufacture (role_id,manufacture_id) values (:roleId,:manufactureId)";
  database.query({
    sql: insert,
    params:{roleId:roleId,manufactureId:manufactureId}
  },null); //just ignore errors! //TODO
}

function addManufactureRole(options, callback){
  var sql = 'INSERT INTO qr_role (name, `desc`, identity, state, client_address,corporation_id) values ' +
    '(:name,:desc,:identity,true, :client_address,:corpId)';
  database.query({
    sql: sql,
    params:options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var roleId = result.insertId;
    logger.info("added role id = %d",roleId);
    //insert role-manufacture
    options.manufacture.forEach(function(item){
      saveRoleManufacture(roleId,item);
    });
    return callback(null, roleId);
  });
}


function getRoleList(tableParams, callback) {
  var corporation = "ISNULL(corporation_id)";
  if(tableParams.corpId){
    corporation = "corporation_id =:corpId"
  }
  var sqlData = "SELECT * FROM qr_role WHERE "+corporation+" and state = :state ";
  var sqlCount = "SELECT count(id) as iTotalRecords FROM qr_role WHERE "+corporation+" and	state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY `" + tableParams.orderName + "` " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(id) as iTotalDisplayRecords FROM qr_role WHERE "+corporation+" and	state = :state AND name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}


function getParentPermissions(callback){
  //top menu
  var sql = "select * from qr_permissions where state = true and parent_id=0 order by weight";
  database.query({
    sql: sql
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, rows);
  });
}

function getAllPermissions(callback){
  var sql = "select * from qr_permissions where state = true";
  database.query({
    sql: sql
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, rows);
  });
}

function getRoleById(roleId, callback){
  var sql = "SELECT r.*,GROUP_CONCAT(p.name) AS permissions FROM qr_role r,qr_role_permission rp,qr_permissions p WHERE rp.role_id=r.id AND p.id=rp.permission_id AND r.id = :roleId AND r.state = :state";
  database.query({
    sql: sql,
    params: {roleId:roleId, state:1}
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    if(rows.length > 0){
      return callback(null, rows[0]);
    }else{
      return callback(null, null);
    }

  });
}

function getManufactureRoleById(roleId, callback){
  var sql = "select a.*,GROUP_CONCAT(c.name) AS manufacture,GROUP_CONCAT(c.id) as manufacture_id from qr_role a,qr_role_manufacture b,qr_manufacture c where a.id =:roleId and b.role_id =:roleId and b.manufacture_id = c.id and a.state =:state and b.state =:state ";
  database.query({
    sql: sql,
    params: {roleId:roleId, state:1}
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    if(rows.length > 0){
      return callback(null, rows[0]);
    }else{
      return callback(null, null);
    }

  });
}

function delRoleById(roleId, callback){
  var sql = "UPDATE qr_role SET state=:state WHERE id=:roleId";
  database.query({
    sql: sql,
    params: {roleId:roleId, state:0}
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, result);
  });
}

function getUserPermissionUrl(userId, callback){
  var sql = "SELECT c.url FROM qr_auth a, qr_role_permission b, qr_permissions c WHERE a.user_id = :userId AND b.role_id = a.role_ids AND c.id = b.permission_id AND c.state = :state";
  database.query({
    sql: sql,
    params: {userId:userId, state:1}
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, result);
  });
}

function updateManufactureRoleById(options, callback){
  var sql = 'update qr_role set  ' +
    '`name` =:name,' +
    '`desc` =:desc ' +
    ' where id =:roleId';
  database.query({
    sql: sql,
    params:options
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      options.Manufacture.forEach(function (item) {
        updateRoleManufactureList(item,{roleId:options.roleId,state:1}, function (err, result){
          if(err){
            return callback(null, false);
          }else if(!result){
            saveRoleManufacture(options.roleId, item);
          }
        })
      });
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

function updateRoleManufactureList(manufactureId, params, callback){
  var sql = "UPDATE qr_role_manufacture SET state=:state WHERE role_id =:roleId and manufacture_id in("+manufactureId+")";
  database.query({
    sql: sql,
    params: params
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

exports.addRole = addRole;
exports.addManufactureRole = addManufactureRole;
exports.getRoleList = getRoleList;
exports.getParentPermissions = getParentPermissions;
exports.getAllPermissions = getAllPermissions;
exports.getRoleById = getRoleById;
exports.getManufactureRoleById = getManufactureRoleById;
exports.delRoleById = delRoleById;
exports.getUserPermissionUrl = getUserPermissionUrl;
exports.updateManufactureRoleById = updateManufactureRoleById;
exports.updateRoleManufactureList = updateRoleManufactureList;