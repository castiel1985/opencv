$ virtualenv venv
