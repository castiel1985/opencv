"use strict";
/**
 * Created by Alen on 15/3/30.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var async = require("async");
var commonUtils = require('../utils/Common');
var commonModel = require('./commonModel.js');
var qrcodeModel = require('../models/qrcodeModel');
var serialManuModel = require('../models/serialManufactureModel');
var wapModel = require('../models/wapModel');

function getSaleByQrCode(qrcode, callback){
  var applyId = parseInt(qrcode.substr(-19, 8));
  var codeId = parseInt(qrcode.substr(-10, 8));
  var sql = "SELECT a.id AS qrcode_id,b.*,c.id AS dealer_id,c.name,c.address,c.location,a.corporation_qrcode AS corp_qrcode FROM qr_code a, qr_sold_record b, qr_production_dealer c WHERE b.qrcode_apply_id = a.apply_id AND c.id = b.dealer_id AND a.qrcode = :qrcode AND b.qrcode_start_id <= :codeId AND (b.qrcode_start_id + b.sold_count) > :codeId AND a.status = :status AND a.state = :state";
  var params = {
    qrcode:qrcode,
    codeId:codeId,
    status:2,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function validQrCode(qrcode, callback){
  database.query(
    {
      sql:"SELECT * FROM qr_code WHERE qrcode = :qrcode AND state = :state",
      params:{qrcode:qrcode,state:1}
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0]);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getPackageByQrCode(qrcode, callback){
  var applyId = parseInt(qrcode.substr(-19, 8));
  var codeId = parseInt(qrcode.substr(-10, 8));
  var sql = "SELECT a.*,b.name as username FROM qr_package a,qr_user b WHERE b.id = a.creator AND a.qrcode_start_id <= :codeId AND (a.qrcode_start_id + a.package_count) > :codeId AND a.qrcode_apply_id = :applyId";
  var params = {
    codeId:codeId,
    applyId:applyId,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getApplyByQrCode(qrcode, callback){
  var sql = "SELECT a.id, a.create_time AS apply_time,b.create_time AS approve_time,a.apply_count,c.name AS apply_username,d.name AS approve_username,b.corporation_qrcode AS corp_qrcode FROM qr_code_apply a, qr_code b, qr_user c, qr_user d  WHERE a.id = b.apply_id AND c.id = a.apply_user_id AND d.id = a.approve_user_id AND b.qrcode=:qrcode AND b.state = :state";
  var params = {
    qrcode:qrcode,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getTranByQrCode(qrcode, callback){
  var applyId = parseInt(qrcode.substr(-19, 8));
  var codeId = parseInt(qrcode.substr(-10, 8));
  var sql = "SELECT c.* FROM qr_code a, qr_sold_record b, qr_transmit c WHERE b.qrcode_apply_id = a.apply_id AND CONCAT(',',c.sold_records,',') LIKE CONCAT('%,',b.id,',%') AND a.qrcode = :qrcode AND b.qrcode_start_id <= :codeId AND (b.qrcode_start_id + b.sold_count) > :codeId AND a.status = :status AND a.state = :state";
  var params = {
    qrcode:qrcode,
    codeId:codeId,
    status:2,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getSerialsManuInfo(tableParams, callback){
  var sqlData = "SELECT b.type,b.name,a.*,GROUP_CONCAT(c.url) AS url,d.name AS username FROM qr_serials_manufacture a LEFT JOIN qr_file c ON c.type = CONCAT('serial_manu_picture_',a.id) AND c.state = :state, qr_manufacture b, qr_user d WHERE b.id = a.manufacture_id AND d.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state GROUP BY a.id,c.type ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM (SELECT count(a.id) FROM qr_serials_manufacture a LEFT JOIN qr_file c ON c.type = CONCAT('serial_manu_picture_',a.id) AND c.state = :state, qr_manufacture b, qr_user d WHERE b.id = a.manufacture_id AND d.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state GROUP BY a.id,c.type)f ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr;
  if(tableParams.orderName == "name"){
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM (SELECT count(a.id) FROM qr_serials_manufacture a LEFT JOIN qr_file c ON c.type = CONCAT('serial_manu_picture_',a.id) AND c.state = :state, qr_manufacture b, qr_user d WHERE b.id = a.manufacture_id AND d.id = a.creator AND a.serial_id = :serialId AND a.state = :state GROUP BY a.id,c.type AND a.title like :search)f ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function getSerialsPatrolInfo(tableParams, callback){
  var sqlData = "SELECT a.*,GROUP_CONCAT(b.url) AS url,c.name AS username FROM qr_serials_patrol_info a LEFT JOIN qr_file b ON (b.type = CONCAT('patrol_picture_',a.id) OR b.type = CONCAT('patrol_video_',a.id)) AND b.state = :state, qr_user c WHERE c.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state GROUP BY b.type ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM (SELECT count(a.id) FROM qr_serials_patrol_info a LEFT JOIN qr_file b ON (b.type = CONCAT('patrol_picture_',a.id) OR b.type = CONCAT('patrol_video_',a.id)) AND b.state = :state, qr_user c WHERE c.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state GROUP BY b.type)f ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr;
  if(tableParams.orderName == "username"){
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM (SELECT count(a.id) FROM qr_serials_patrol_info a LEFT JOIN qr_file b ON (b.type = CONCAT('patrol_picture_',a.id) OR b.type = CONCAT('patrol_video_',a.id)) AND b.state = :state, qr_user c WHERE c.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state GROUP BY b.type AND a.title like :search)f ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function getSerialsReportInfo(tableParams, callback){
  var sqlData = "SELECT a.*,b.name as username FROM qr_serials_test_report a, qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_serials_test_report a, qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr;
  if(tableParams.orderName == "username"){
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_serials_test_report a, qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND (a.sub_serial_id = :subSerialId || a.sub_serial_id = 0) AND a.state = :state AND a.title like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function getPackageInfo(tableParams, callback){
  var sqlData = "SELECT a.*,b.name AS username FROM qr_package a,qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_package a,qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr;
  if(tableParams.orderName == "name"){
    orderStr = " ORDER BY b." + tableParams.orderName + " " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_package a,qr_user b WHERE b.id = a.creator AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state AND a.name like :search ";

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getSerialSaleInfo(subId, tableData, callback){
  var table = [];
  if(tableData && tableData.aaData && tableData.aaData.length > 0){
    tableData.aaData.forEach(function(item){
      var start = item.qrcode_start_id;
      var end = item.qrcode_start_id + item.sold_count - 1;
      qrcodeModel.getSerialQrcodes(subId,start,end,function(arr){
        var num = 0;
        arr && arr.forEach(function(i){
          var s = i.split("-")[0];
          var e = i.split("-")[1];
          var c = parseInt(e) - parseInt(s) + 1;
          num += c;
        });
        item.sold_count = num;
        item.filter_arr = arr.join(",");
        table.push(item);
        if(table.length == tableData.aaData.length){
          tableData.aaData = table;
          callback(tableData);
        }
      });
    });
  }else{
    callback(tableData);
  }
}

function getSaleInfo(tableParams, callback){
  var sql = " AND ((c.qrcode_start_id >= a.qrcode_start_id AND c.qrcode_start_id < a.qrcode_start_id+a.package_count)" +
    "OR (c.qrcode_start_id + c.sold_count > a.qrcode_start_id AND c.qrcode_start_id + c.sold_count <= a.qrcode_start_id+a.package_count)" +
    "OR (c.qrcode_start_id <= a.qrcode_start_id AND c.qrcode_start_id + c.sold_count >= a.qrcode_start_id+a.package_count))";
  var sqlData = "SELECT distinct c.*,b.name FROM qr_package a, qr_production_dealer b, qr_sold_record c WHERE a.serial_id = :serialId AND a.subserial_id = :subSerialId AND b.id = c.dealer_id "+sql+" AND c.state = :state ";
  var sqlCount = "SELECT count(distinct c.id) as iTotalRecords FROM qr_package a, qr_production_dealer b, qr_sold_record c WHERE a.serial_id = :serialId AND a.subserial_id = :subSerialId AND b.id = c.dealer_id "+sql+" AND c.state = :state ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr;
  if(tableParams.orderName == "name"){
    orderStr = " ORDER BY b." + tableParams.orderName + " " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY c." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_package a, qr_production_dealer b, qr_sold_record c WHERE a.serial_id = :serialId AND a.subserial_id = :subSerialId AND b.id = c.dealer_id "+sql+" AND c.state = :state AND a.name like :search ";

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    getSerialSaleInfo(tableParams.subSerialId,tableData,callback);
    //callback(tableData);
  });
}

function getTranInfo(tableParams, callback){
  var sql = " AND ((b.qrcode_start >= a.qrcode_start_id AND b.qrcode_start < a.qrcode_start_id+a.package_count)" +
    "OR (b.qrcode_start + b.sold_count > a.qrcode_start_id AND b.qrcode_start + b.sold_count <= a.qrcode_start_id+a.package_count)" +
    "OR (b.qrcode_start <= a.qrcode_start_id AND b.qrcode_start + b.sold_count >= a.qrcode_start_id+a.package_count))";
  var sqlData = "SELECT d.* FROM qr_transmit d,(SELECT b.* FROM qr_package a, qr_transmit_plan_record b WHERE a.serial_id = :serialId AND a.subserial_id = :subSerialId AND transmit_id IS NOT NULL AND a.qrcode_apply_id = b.apply_id" + sql + "  GROUP BY b.transmit_id) c WHERE c.transmit_id = d.id";
  var sqlCount = "SELECT count(d.id) as iTotalRecords FROM qr_transmit d,(SELECT b.* FROM qr_package a, qr_transmit_plan_record b WHERE a.serial_id = :serialId AND a.subserial_id = :subSerialId AND transmit_id IS NOT NULL AND a.qrcode_apply_id = b.apply_id" + sql + "  GROUP BY b.transmit_id) c WHERE c.transmit_id = d.id";
  var sqlArr = [];
  var orderStr = " ORDER BY d.id " + tableParams.orderDir;
  sqlData = sqlData + orderStr +" limit :start,:length ";
  sqlArr.push(sqlData);
  sqlArr.push(sqlCount);
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getApplyInfo(tableParams, callback){
  var sqlData = "SELECT b.id,b.create_time AS apply_time,b.status,b.apply_count,d.name AS apply_username,e.name AS approve_username FROM qr_package a, qr_code_apply b, qr_user d, qr_user e WHERE b.id = a.qrcode_apply_id AND d.id = b.apply_user_id AND e.id = b.approve_user_id AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state GROUP BY b.id ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM (SELECT count(b.id) FROM qr_package a, qr_code_apply b, qr_user d, qr_user e WHERE b.id = a.qrcode_apply_id AND d.id = b.apply_user_id AND e.id = b.approve_user_id AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state GROUP BY b.id) f ";

  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr;
  if(tableParams.orderName=="apply_count"){
    orderStr = " ORDER BY b." + tableParams.orderName + " " + tableParams.orderDir;
  }else if(tableParams.orderName=="apply_username"){
    orderStr = " ORDER BY d.name " + tableParams.orderDir;
  }else if(tableParams.orderName=="apply_time"){
    orderStr = " ORDER BY b.create_time " + tableParams.orderDir;
  }else if(tableParams.orderName=="approve_time"){
    orderStr = " ORDER BY c.create_time " + tableParams.orderDir;
  }else if(tableParams.orderName=="approve_username"){
    orderStr = " ORDER BY e.name " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords (SELECT count(b.id) FROM qr_package a, qr_code_apply b, qr_user d, qr_user e WHERE b.id = a.qrcode_apply_id AND d.id = b.apply_user_id AND e.id = b.approve_user_id AND a.serial_id = :serialId AND a.subserial_id = :subSerialId AND a.state = :state GROUP BY b.id AND a.name like :search)f ";

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function getBaseInfo(params, callback){
  var sql = "SELECT b.* FROM qr_serials a, qr_production_base b WHERE b.id = a.base_id AND a.id = :serialId AND b.state = :state";
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err || !rows) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getTab(qrcode, callback){
  var sql = "SELECT a.* FROM qr_tab a,qr_code b WHERE b.qrcode =:qrcode and b.corporation_id and b.corporation_id = a.corporation_id ";
  var params = {
    qrcode:qrcode,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

function getMainInfo(params, callback){
  async.series(
    {
      manu:function(cb){
        getSerialsManuInfo(params, cb);
      },
      patrol:function(cb){
        getSerialsPatrolInfo(params, cb);
      },
      report:function(cb){
        getSerialsReportInfo(params, cb);
      },
      base:function(cb){
        getBaseInfo(params, cb);
      }
    },
    function(err, results) {
      callback(null, results);
    }
  );
}

function getInfoByQrCode(qrcode, callback){
  async.series(
    {
      valid:function(cb){
        validQrCode(qrcode, cb);
      },
      /*
      sale:function(cb){
        getSaleByQrCode(qrcode, cb);
      },*/
      pack:function(cb){
        getPackageByQrCode(qrcode, cb);
      },
      apply:function(cb){
        getApplyByQrCode(qrcode, cb);
      },
      corp:function(cb){
        wapModel.getCorpByQrCode(qrcode, cb);
      },
      tran:function(cb){
        getTranRecursive(qrcode, cb);
      },
      tab:function(cb){
        getTab(qrcode, cb);
      }
  },
    function(err, results) {
      callback(null, results);
    }
  );
}

//按照时间顺序将json数组重新排序
function sortInfo(info, corp_qrcode, serialId, callback){
  var sale = info.sale;
  var pack = info.pack;
  var manu = info.manu;
  var patrol = info.patrol;
  var report = info.report;
  var apply = info.apply;
  var approve = info.approve;
  var tran = info.tran;
  var corp = info.corp;
  var arr = [];
  var keys = [];
  var h = {};

  //物流信息
  tran && tran.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.scan_time),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.scan_time),"yyyy-MM-dd hh:mm:ss");
    var action = data.scan_action == "0" ? "上车" : "下车";
    h = {
      date:date,
      action:"配送",
      desc: "在"+data.scan_location+action,
      icon: "fa fa-truck",
      bg:"bg-navy",
      show:hms,
      url:"/work_manage/production_transmit/scan/record/"+data.transmit_qrcode+"?layout=modal_layout",
      title:"查看物流信息"
    };
    var json = {};
    var key = date + "_sale_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //销售信息
  sale && sale.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.sold_date),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.sold_date),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"销售",
      desc: "经销商:"+data.name,
      icon: "fa fa-shopping-cart",
      bg:"bg-red",
      show:hms,
      url: "/work_manage/production_sales/sold_record/"+data.id+"?corp_qrcode="+corp_qrcode,
      title:"查看销售记录"
    };
    var json = {};
    var key = date + "_sale_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //打包信息
  pack && pack.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.package_date),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.package_date),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"包装",
      icon: "fa fa-archive",
      desc:"包装人:"+data.username,
      bg:"bg-green",
      show:hms,
      url: "/work_manage/production_package/view/"+data.id+"?corp_qrcode="+corp_qrcode,
      title:"查看包装记录"
    };
    var json = {};
    var key = date + "_pack_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //二维码申请
  apply && apply.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.apply_time),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.apply_time),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"二维码申请",
      icon: "fa fa-qrcode",
      desc:"申请人:"+data.apply_username,
      bg:"bg-maroon",
      show:hms,
      url: "/qrcode/apply/view/"+data.id,
      title:"查看二维码"
    };
    var json = {};
    var key = date + "_apply_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //二维码审批
  approve && approve.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.approve_time),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.approve_time),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"二维码审批",
      icon:"fa fa-qrcode",
      desc:"审批人:"+data.approve_username,
      bg:"bg-orange",
      show:hms,
      url: "/qrcode/apply/view/"+data.id,
      title:"查看二维码"
    };
    var json = {};
    var key = date + "_approve_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //检查报告
  report && report.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.report_date),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.report_date),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"检验检测报告"+"("+data.username+")",
      //action:data.title,
      desc:data.desc,
      icon: "fa fa-book",
      bg:"bg-yellow",
      show:hms,
      url: "/work_manage/serials_manage/"+serialId+"/report/view/"+data.id,
      title:"检验检测报告详情"
    };
    var json = {};
    var key = date + "_report_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //巡检信息
  patrol && patrol.forEach(function(data){
    var date = commonUtils.dateFormat(new Date(data.patrol_date),"yyyy-MM-dd hh:mm:ss");
    var hms = commonUtils.dateFormat(new Date(data.patrol_date),"yyyy-MM-dd hh:mm:ss");
    h = {
      date:date,
      action:"巡检"+"("+data.username+")",
      desc:data.desc,
      icon: "fa fa-eye",
      bg:"bg-aqua",
      show:hms,
      url: "/work_manage/serials_manage/"+serialId+"/patrol/view/"+data.id,
      title:"巡检详情"
    };

    var json = {};
    var key = date + "_patrol_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  //生产/加工信息
  manu && manu.forEach(function(data){
    var date;
    var hms;
    var desc;
    date = commonUtils.dateFormat(new Date(data.manu_date),"yyyy-MM-dd hh:mm:ss");
    hms = commonUtils.dateFormat(new Date(data.manu_date),"yyyy-MM-dd hh:mm:ss");
    desc = data.desc;
    h = {
      date:date,
      action: data.name+"("+data.username+")",
      desc:desc,
      icon: "fa fa-user",
      bg:"bg-purple",
      show:hms,
      url: "/work_manage/serials_manage/"+serialId+"/serial_manufacture/view/"+data.id,
      title: "批次生产/加工信息详情"
    };
    var json = {};
    var key = date + "_manu_" + data.id;
    json[key] = h;
    keys.push(key);
    arr.push(json);
  });

  var arr1 = [];
  var arr2 = [];
  var currDay = "";
  var children = [];
  keys.sort().reverse().forEach(function(key, index){
    var day = key.substring(0,10);

    arr.forEach(function(data){
      if(data[key]){
        if(currDay == day){
          children.push(data[key]);
        }else{
          if(currDay != ""){
            var obj = {
              date:currDay,
              children:children
            };
            arr1.push(obj);
          }
          children = [];
          children.push(data[key]);
          currDay = day;
        }
        if(index == keys.length - 1){
          var obj2 = {
            date:currDay,
            children:children
          };
          arr1.push(obj2);
        }
      }
    });
  });

  callback(null, arr1);
}

function getAdvanceColumns(callback){
  var arr = [];
  var params;

  params = {
    id:"tran",
    action:"配送信息",
    columns:[{name:"收货人"},{name:"收货地址"},{name:"发货人"},{name:"发货状态"},{name:"配送时间"}]
  };
  arr.push(params);

  //销售信息
  params = {
    id:"sale",
    action:"销售信息",
    columns:[{name:"产品名称"},{name:"经销商"},{name:"销售数量"},{name:"销售时间"}]
  };
  //arr.push(params);

  //打包信息
  params = {
    id:"package",
    action:"包装信息",
    columns:[{name:"产品名称"},{name:"包装人员"},{name:"包装数量"},{name:"包装时间"}]
  };
  arr.push(params);

  //二维码申请
  params = {
    id:"apply",
    action:"二维码申请",
    columns:[{name:"产品名称"},{name:"申请数量"},{name:"申请人员"},{name:"申请时间"}]
  };
  arr.push(params);

  //二维码审批
  params = {
    id:"approve",
    action:"二维码审批",
    columns:[{name:"产品名称"},{name:"审批数量"},{name:"审批人员"},{name:"审批时间"}]
  };
  arr.push(params);

  //检查报告
  params = {
    id:"report",
    action:"检测报告",
    columns:[{name:"产品名称"},{name:"检测报告标题"},{name:"检测报告日期"}]
  };
  arr.push(params);

  //巡检信息
  params = {
    id:"patrol",
    action:"巡检信息",
    columns:[{name:"产品名称"},{name:"巡检内容"},{name:"巡检日期"}]
  };
  arr.push(params);

  //生产/加工信息
  params = {
    id:"manu",
    action:"生产/加工信息",
    columns:[{name:"产品名称"},{name:"生产/加工类型"},{name:"生产/加工内容"},{name:"生产/加工日期"}]
  };
  arr.push(params);

  callback(null, arr);
}

function getProductionList(params, callback) {
  database.query({
    sql: "SELECT a.* FROM qr_production a,qr_user b WHERE b.id = a.creator AND b.corporation_id = :corpId AND a.state =:state",
    params: params
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function getSerialsList(params, callback){
  var user = params.user;
  var sql;
  if(!user || user.isSupervisor){
    sql = "SELECT * FROM qr_serials WHERE production_id = :proId AND state =:state";
  }else{
    sql = "SELECT a.* FROM qr_serials a,qr_user b,qr_corporation c WHERE b.id=a.creator AND c.id = b.corporation_id AND a.production_id = :proId AND ((c.share is true) || (c.share is false AND a.creator = :userId)) AND a.state =:state";
    params.userId = user.id;
  }
  database.query({
    sql: sql,
    params: params
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }

  });
}

function geResultBySql(sql, callback){
  database.query({
    sql: sql
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function getTranRecursive(qrcode, callback){
  var applyId = parseInt(qrcode.substr(-19, 8));
  var codeId = parseInt(qrcode.substr(-10, 8));
  var sql = "SELECT e.* FROM qr_transmit_record e, (SELECT d.* FROM qr_transmit_plan_record a LEFT JOIN qr_transmit b ON b.id = a.transmit_id LEFT JOIN qr_transmit_plan c ON c.id = a.plan_id, qr_transmit_record d WHERE a.qrcode_start <= :codeId AND (a.qrcode_start + a.sold_count) > :codeId AND a.state = :state AND a.apply_id = :applyId AND d.plan_id IS NOT NULL AND d.plan_id = c.id) f WHERE (e.transmit_qrcode = f.transmit_qrcode AND e.scan_action = :scan_action) || e.id = f.id";
  var params = {
    codeId:codeId,
    applyId:applyId,
    state:1,
    scan_action:'0'
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if (err) {
        logger.error(err ? err.stack : "row is null");
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows);
      } else {
        return callback(null, null);
      }
    }
  );
}

exports.getInfoByQrCode = getInfoByQrCode;
exports.getMainInfo = getMainInfo;
exports.sortInfo = sortInfo;
exports.getProductionList = getProductionList;
exports.getSaleByQrCode = getSaleByQrCode;
exports.getPackageByQrCode = getPackageByQrCode;
exports.getSerialsManuInfo = getSerialsManuInfo;
exports.getSerialsList = getSerialsList;
exports.getTranInfo = getTranInfo;
exports.getAdvanceColumns = getAdvanceColumns;
exports.getSaleInfo = getSaleInfo;
exports.getPackageInfo = getPackageInfo;
exports.getApplyInfo = getApplyInfo;
exports.getSerialsReportInfo = getSerialsReportInfo;
exports.getSerialsPatrolInfo = getSerialsPatrolInfo;
exports.geResultBySql = geResultBySql;
exports.getTranRecursive = getTranRecursive;
exports.validQrCode = validQrCode;
