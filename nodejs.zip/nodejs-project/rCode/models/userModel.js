"use strict";
/**
 * Created by Alen on 15/2/18.
 */
var database = require('../database/mysql.js');
var logger = require('intel');
var commonModel = require('./commonModel.js');

function addUser(options, callback) {
  var username = options.username;
  uniqConfirm(username, function(err, result){
    if(result){
      return callback(new global.DBError("用户名已存在"), null);
    }else{
      var sql = "INSERT INTO qr_user (username,corporation_id,name, passwd, salt, status, mail, mobile_phone, state, client, client_address) values " +
        "(:username,:corporation_id,:name,:password,:salt,:status, :mail,:mobile,1,:client, :client_address)";
      database.query({
        sql: sql,
        params:options
      }, function(err, result) {
        if (err) {
          return callback(new global.DBError("MySQL Error"), null);
        }

        //insert role
        var insert = "insert into qr_auth (user_id,role_ids,type) values (:userId,:roleId,'user')";
        database.query({
          sql: insert,
          params:{roleId:options.roleId,userId:result.insertId}
        },null); //just ignore errors! //TODO
        return callback(null, result);
      });
    }
  });
}


function getValidUsers(valid, callback) {
  var sql = "select * from qr_user where state = true ";
  database.query({
    sql: sql
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, rows);
  });
}

function getMenuIdByUser(user, callback) {
  var sql = "select b.role_ids,c.permission_id from  qr_auth b,qr_role_permission c where b.role_ids = c.role_id  and b.`user_id` =:userId";
  database.query({
    sql: sql,
    params: {userId:user.id}
  }, function(err, rows) {
    if (err) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, rows);
  });


}


function getUserByName(params, callback) {
  database.query({
    sql: "SELECT * FROM qr_user " +
      " WHERE username =:username",
    params: {
      "username": params.username
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function getUserRoleByName(params, callback){
  var sql = "SELECT u.*,r.identity FROM qr_user u, qr_auth a, qr_role r WHERE a.user_id = u.id AND r.id=a.role_ids AND u.username = :username";
  database.query({
    sql: sql,
    params: {
      "username": params.username
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function getUsersByRole(user, tableParams, callback){
  var sqlData = "";
  var sqlCount = "";
  var sqlFilterCount = "";
  if(user.isAdmin){
    sqlData = "SELECT a.*,d.desc,b.name AS corp_name FROM qr_user a, qr_corporation b, qr_auth c, qr_role d WHERE c.user_id=a.id AND d.id=c.role_ids AND b.id=a.corporation_id AND a.state=:state AND d.identity=:identity ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_user a, qr_corporation b, qr_auth c, qr_role d WHERE c.user_id=a.id AND d.id=c.role_ids AND b.id=a.corporation_id AND a.state=:state AND d.identity=:identity ";
  }else if(user.isSupervisor){
    sqlData = "SELECT a.*,d.desc,ifnull(b.name,'') AS corp_name,e.name AS superior_name FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id LEFT JOIN qr_corporation e ON e.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND (a.corporation_id = :corpId || b.superior_id = :corpId) ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND (a.corporation_id = :corpId || b.superior_id = :corpId) ";
  }else{
    sqlData = "SELECT a.*,d.desc,ifnull(b.name,'') AS corp_name FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.corporation_id = :corpId ";
    sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.corporation_id = :corpId ";
  }
  var sqlArr = [];
  var orderStr;
  if(tableParams.orderName == "desc"){
    orderStr = " ORDER BY d.desc " + tableParams.orderDir;
  }else if(tableParams.orderName == "corp_name"){
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";

    if(user.isAdmin){
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_user a, qr_corporation b, qr_auth c, qr_role d WHERE c.user_id=a.id AND d.id=c.role_ids AND b.id=a.corporation_id AND a.state=:state AND d.identity=:identity AND a.name like :search ";
    }else if(user.isSupervisor){
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND (a.corporation_id = :corpId || b.superior_id = :corpId) AND a.name like :search ";
    }else{
      sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.corporation_id = :corpId AND a.name like :search ";
    }

    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });

}

function modifyStatus(userId, status, callback){
  database.query({
    sql: "UPDATE `qr_user` SET status=:status WHERE id=:userId",
    params:{status:status,userId:userId}
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }

    return callback(null, result);
  });
}

function getUsersApproveList(tableParams, callback){
  var sqlData = "SELECT a.*,d.desc,ifnull(b.name,'') AS corp_name FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.status = :status AND (b.id = :corpId || b.superior_id = :corpId) ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.status = :status AND (b.id = :corpId || b.superior_id = :corpId) ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = "";
  if(tableParams.orderName == "desc"){
    orderStr = " ORDER BY d.`desc` " + tableParams.orderDir;
  }else if(tableParams.orderName == "corp_name"){
    orderStr = " ORDER BY b.name " + tableParams.orderDir;
  }else{
    orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id, qr_auth c, qr_role d WHERE c.user_id = a.id AND d.id=c.role_ids AND a.state=:state AND a.status = :status AND (b.id = :corpId || b.superior_id = :corpId)  AND a.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else{
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function userApprove(params, callback){
  database.query({
    sql: "UPDATE qr_user SET status=:status WHERE id=:userId",
    params:params
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, result);
  });
}

function updatePass(params, callback){
  database.query({
    sql: "UPDATE qr_user SET `salt`=:salt,`passwd`=:password WHERE id=:userId",
    params:params
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, result);
  });
}

function uniqConfirm(username, callback){
  database.query({
    sql: "SELECT * FROM qr_user WHERE username=:username",
    params:{username:username}
  }, function(err, rows) {
    if (err || !rows) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    if(rows.length > 0){
      return callback(null, rows[0]);
    }else{
      return callback(null, null);
    }

  });
}

function clientModify(params, callback){
  database.query({
    sql: "UPDATE qr_user SET `client`=:client WHERE id=:userId",
    params:params
  }, function(err, result) {
    if (err || !result) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, result);
  });
}

function getUsersByCorpId(corpId, user, callback){
  var sql;
  if(corpId && corpId != ""){
    if(corpId && corpId != ""){
      sql="SELECT a.* FROM qr_user a LEFT JOIN qr_corporation b ON b.id = a.corporation_id WHERE a.state = :state AND (b.id = :corpId || b.superior_id = :corpId)";
    }
    database.query({
      sql:sql,
      params:{corpId:corpId,state:1}
    },function(err, rows){
      if (err || !rows) {
        return callback(new global.DBError("MySQL Error"), null);
      }
      return callback(null, rows);
    });
  }else{
    var params = {
      state : 1,
      status : 1,
      identity : "supervisor",
      corpId : user.corporation_id
    };
    getUsersByRole(user, params, function(result){
      if(result && result.aaData){
        return callback(null, result.aaData);
      }else{
        return callback(null, null);
      }
    });
  }
}

function getUsersByCorpIdAndRole(params, callback){
  var sql = 'select a.* from qr_user a,qr_auth b where a.corporation_id =:corporationId and a.id = b.user_id and b.role_ids =:roleId and a.state =:state ';
  database.query({
    sql:sql,
    params:params
  },function(err, rows){
    if (err || !rows) {
      return callback(new global.DBError("MySQL Error"), null);
    }
    return callback(null, rows);
  });
}

exports.getMenuIdByUser = getMenuIdByUser;
exports.addUser = addUser;
exports.getValidUsers = getValidUsers;
exports.getUserByName = getUserByName;
exports.getUserRoleByName = getUserRoleByName;
exports.getUsersByRole = getUsersByRole;
exports.getUsersByCorpIdAndRole = getUsersByCorpIdAndRole;
exports.modifyStatus = modifyStatus;
exports.getUsersApproveList = getUsersApproveList;
exports.userApprove = userApprove;
exports.updatePass = updatePass;
exports.uniqConfirm = uniqConfirm;
exports.clientModify = clientModify;
exports.getUsersByCorpId = getUsersByCorpId;