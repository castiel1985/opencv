"use strict";
var express = require('express');
var router = express.Router();
var productionModel = require('../models/productionModel');
var commonModel = require('../models/commonModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var underscore = require('underscore');
var logger = require('../utils/winstonUtils').logger;
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  var usr = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params={
      user:usr,
      userId:usr.id,
      corpId:usr.corporation_id,
      state:1
    };
    productionModel.getProductionList(params, function(err, tableData) {
      return res.send(tableData);
    });

  } else {

    var params2 = {
      user_id:usr.id,
      url:nconf.get("url:production"),
      action:nconf.get("action:index"),
      operate_type:nconf.get("operate_type:production"),
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
    return res.render('production', {
      header: "产品管理"
    });
  }

});

router.get('/list', function(req, res, next) {

  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.userId = usr.id;
  tableParams.corpId = usr.corporation_id;
  tableParams.state = 1;

  productionModel.getProductionList(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {

  return res.render('production/add', {
    header: "产品管理 > 添加产品",
    creator: req.session.rcode.user.id
  });
});


router.post('/add', function(req, res, next) {
  var tag = req.session.rcode.tagBox;
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var expired_num = req.body.expired_num;
  var expired_suffix = req.body.expired_suffix;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    creator: usr.id,
    name: req.body.name,
    brand_id: req.body.brand_id,
    parent_id: req.body.parent_id || null,
    category: req.body.category,
    short_name: req.body.short_name,
    pinyin: req.body.pinyin || '',
    expired_date: (expired_num + ':' + expired_suffix) || null,
    clazz:req.body.clazz,
    standard:req.body.standard || '',
    unit:req.body.unit,
    count:req.body.count,
    identity:req.body.identity,
    status:req.body.status || null,
    attribute:req.body.attributions || '',
    desc: req.body.desc || '',
    client_address: commonUtils.getClientIp(req)
  };

  var files = req.session.rcode.uploadedFile;
  if(files){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.files = files;
  }

  productionModel.addProduction(params,function(err,productionId){
    if(err){
      return res.render('production/add', {
        header: "产品管理 > 添加产品",
        msg: messageUtils.msgError("产品添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:production"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:production"),
        operate_id:productionId,
        content:{name:req.body.name,brand_name:req.body.brand_name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("产品添加成功");
      return res.redirect('/corp_info/production_manage');
    }
  });


});


router.get('/view/:production_id', function(req, res, next) {
  var productionId = req.params.production_id;
  logger.info("productionId=%s",productionId);
  if(underscore.isNaN(productionId)){
    return next(new Error("Invalid productionId"));
  }
  productionModel.getProductionById(productionId, function(err, row) {
    if (err) {
      return next(err);
    }
    if (req.query["ajax"] === "1") {
      return res.send(row);
    } else{
      if(row.expired_date.split(":").length > 1){
        var num =row.expired_date.split(":")[0];
        var suffix = row.expired_date.split(":")[1];
        if(suffix == 'y'){
          row.expired_date = num + "年";
        }else if(suffix == 'm'){
          row.expired_date = num + "月";
        }else{
          row.expired_date = num + "天";
        }
      }
      var params = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:production"),
        action:nconf.get("action:view"),
        operate_type:nconf.get("operate_type:production"),
        operate_id:productionId,
        content:{name:row.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(params);
      messageUtils.getSessionMsg(req, res);
      return res.render('production/view', {
        header: "产品详情",
        production: row,
        layout: "partial/modal_layout"
      });
    }
  });
});

router.get('/industrylist', function(req, res, next) {

  productionModel.getIndustryList( function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.send(rows);
  });
});

router.get('/productionsByBrandId/:brandId', function(req, res, next) {

  var brandId = req.params.brandId;
  var user = req.session.rcode.user;
  productionModel.getProductionListByBrandId(brandId, function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.send(rows);
  });
});


router.get('/update/:production_id',function(req, res, next) {
  var productionId = req.params.production_id;
  logger.info("productionId=%s",productionId);
  if(underscore.isNaN(productionId)){
      return next(new Error("Invalid productionId"));
  }
  productionModel.getProductionById(productionId, function(err, row){
    if(err){
        next(err);
    } else {
      return res.render('production/update', {
        header: "产品管理 > 修改产品信息",
        production: row
      });
    }
  });
});

router.post('/update',function(req, res, next){
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  var id = req.body.id;
  var delFileIds = req.body.delFileIds;
  var expired_num = req.body.expired_num;
  var expired_suffix = req.body.expired_suffix;
  var params = {
    id: id,
    creator: usr.id,
    name: req.body.name,
    brand_id: req.body.brand_id,
    parent_id: req.body.parent_id || null,
    category: req.body.category,
    short_name: req.body.short_name ,
    pinyin: req.body.pinyin || '',
    expired_date: (expired_num + ':' + expired_suffix) || null,
    clazz:req.body.clazz,
    standard:req.body.standard || '',
    unit:req.body.unit,
    count:req.body.count,
    identity:req.body.identity,
    status:req.body.status || null,
    attribute:req.body.attributions || '',
    desc: req.body.desc || ''
  };

  var pictureFiles = req.session.rcode.uploadedFile;
  if(pictureFiles){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.pictureFiles = pictureFiles;
  }
  if(delFileIds){
    commonModel.updateFilesState({state:0}, delFileIds, function (err, result) {
      if(err || !result){
        return res.render('patrol/update', {
          header: "产品管理 > 修改产品信息",
          msg: messageUtils.msgError("产品信息更新失败"),
          creator: req.session.rcode.user.id
        });
      }
    });
  }
  productionModel.updateProduction(params, function(err, patrolId) {
    if (err) {
      return res.render('production/update', {
          header: "产品管理 > 修改产品信息",
          msg: messageUtils.msgError("产品信息更新失败"),
          creator: req.session.rcode.user.id
      });
    } else {
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:production"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:production"),
        operate_id:patrolId,
        content:{name:{old:req.body.old_name,new:req.body.name},brand_name:{old:req.body.old_brand_name,new:req.body.brand_name}},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("产品信息更新成功");
      return res.redirect('/corp_info/production_manage');
    }
  });
});

router.get('/delete/:production_id',function(req, res, next) {
  var productionId = req.params.production_id;
  productionModel.delProduction(productionId,function(err,row){
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("产品信息删除失败");
      return res.redirect('/production');
    } else {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:production"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:production"),
        operate_id:productionId,
        content:{name:req.query['name']},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("产品信息删除成功");
      return res.redirect('/corp_info/production_manage');
    }
  });
});

module.exports = router;