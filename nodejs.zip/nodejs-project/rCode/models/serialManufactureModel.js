"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var commonModel = require("./commonModel.js");
var logger = require('../utils/winstonUtils').logger;
var async = require("async");


function delSerialManu(serialManuId, callback) {
  var update = "UPDATE qr_serials_manufacture SET `state`=0 WHERE id = :serialManuId";
  var params = {
    serialManuId: serialManuId
  };
  database.query({
    sql: update,
    params: params
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    return callback(null, result);
  });
}


function getSerialManuList(tableParams, callback) {
  var sql = "";
  if(tableParams.manuIds){
    sql = " AND d.id IN (" + tableParams.manuIds + ") ";
  }
  if(tableParams.status){
    sql += " AND c.status = :status ";
  }
  var sqlData = "select c.*, a.name as production_name ,b.serial_no,d.type as manu_type,d.name as manu_name, d.sort, ifnull(e.serial_no,'公用') as sub_serial_no " +
    "from qr_production a, qr_serials b, qr_serials_manufacture c left join qr_serials e on e.id = c.sub_serial_id,qr_manufacture d " +
    "where a.id = b.production_id and c.state = :state and b.id = c.serial_id and c.manufacture_id=d.id " + sql +
    "and b.id=:serialId ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_serials_manufacture c,qr_manufacture d WHERE d.id = c.manufacture_id AND c.serial_id = :serialId AND c.state = :state " + sql;
  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.orderName == "name"){
    orderStr = " ORDER BY d." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.orderName == "desc"){
    orderStr = " ORDER BY c." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.orderName == "sort"){
    orderStr = " ORDER BY d." + tableParams.orderName + " " + tableParams.orderDir;
  }
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and c.sub_serial_id like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_serials_manufacture c,qr_manufacture d WHERE d.id = c.manufacture_id AND c.serial_id = :serialId AND c.sub_serial_id like :search " + sql;
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(err, tableData.aaData);
    }
  });
}

function addSerialManu(params, callback) {
  var sql = 'INSERT INTO qr_serials_manufacture (`sub_serial_id`,' +
    ' `serial_id`, ' +
    ' `creator`, ' +
    ' `manufacture_id`, ' +
    ' `desc`, ' +
    '`state`,' +
    '`client_address`) values ' +
    '(:sub_serial_id,' +
    ':serial_id,' +
    ':creator,' +
    ':manufacture_id,' +
    ':desc,' +
    ':state,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var serialManuId = result.insertId;
    logger.info("add serial manufacture id = %d", serialManuId);

    if (params.pictureFiles) {
      params.pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = params.creator;
        item.type = 'serial_manu_picture_' + serialManuId;
        commonModel.insertFiles(item, null);
      });
    }
    return callback(null, serialManuId);
  });

}


function updateSerialManu(params, serialManuId, callback) {
  var sql_head = "UPDATE qr_serials_manufacture SET ";
  var colums = [];
  var pictureFiles = params.pictureFiles;
  var creator = params.creator;
  delete params.pictureFiles;
  delete params.creator;
  for (var key in params) {
    colums.push("`" + key + "`" + "=:" + key);
  }
  var sql = sql_head + colums.join(',') + " WHERE id = " + serialManuId;
  database.query({
    sql: sql,
    params: params
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (pictureFiles) {
      pictureFiles.forEach(function (item) {
        //insetrt to file
        item.creator = creator;
        item.type = 'serial_manu_picture_' + serialManuId;
        commonModel.insertFiles(item, null);
      });
    }
    if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, null);
    }

  });
}

function getSerialManuById(serialManuId, callback) {
  database.query({
    sql: "SELECT a.*, b.id as maunId, b.type,b.name as type_name, ifnull(c.serial_no,'公用') AS sub_serial_no FROM qr_serials_manufacture a LEFT JOIN qr_serials c on c.id = a.sub_serial_id, qr_manufacture b WHERE a.manufacture_id=b.id and a.id =:serialManuId",
    params: {
      "serialManuId": serialManuId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      var row = rows[0];
      database.query({
        sql: "SELECT * FROM qr_file WHERE type =:pictureType AND state=1",
        params: {
          "pictureType": "serial_manu_picture_" + serialManuId
        }
      }, function (err, rows2) {
        if (err) {
          logger.error(err.stack);
          return callback(new global.ServerError("Can't connect MySQL"), null);
        }
        row.pictureFiles = rows2;
        return callback(null, row);
      });
    } else {
      return callback(null, null);
    }
  });
}

function getCorpManu(corpId, callback){
  database.query({
    sql: "SELECT * FROM qr_manufacture WHERE corporation_id = :corpId",
    params: {
      "corpId": corpId
    }
  }, function (err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows);
    } else {
      return callback(null, null);
    }
  });
}

function insertSerialManus(sql, callback){
  database.query({
    sql: sql
  }, function(err, result) {
    if(err){
      return callback(err, null);
    }else{
      return callback(null, result);
    }
  });
}

function autoAddSerialManu(params, callback){
  async.waterfall([
    function(cb){
      getCorpManu(params.corpId, function(err, rows){
        cb(err, rows);
      });
    },
    function(manus, cb){
      var sql = "INSERT INTO `qr_serials_manufacture` (`serial_id`, `manufacture_id`, `creator`, `status`, `state`) VALUES";
      var rows = [];
      manus && manus.forEach(function(item){
        var manuId = item.id;
        var row = [];
        row.push(params.serialsId);
        row.push(item.id);
        row.push(params.userId);
        row.push(0);
        row.push(1);
        rows.push("("+row.join(",")+")");
      })
      sql = sql + rows.join(",");
      cb(null, sql);
    },
    function(sql, cb){
      insertSerialManus(sql, function(err, result){
        cb(err, result);
      });
    }
  ], function (err, result) {
      if(err){
        callback(err, null);
      }else{
        callback(null, null);
      }
  });
}

function confirmSerialManu(serialManuId, confirm_date, confirm_user, callback){
  var sql = "UPDATE qr_serials_manufacture SET status = :status,confirm_date = :confirm_date,confirm_user=:confirm_user WHERE id = :serialManuId";
  database.query({
    sql: sql,
    params: {
      "status": 1,
      "confirm_date":confirm_date,
      "confirm_user":confirm_user,
      "serialManuId":serialManuId
    }
  }, function (err, result) {
    if (err || !result) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else{
      return callback(null, result);
    }
  });
}

function currSerialManu(serialId, callback){
  var sql = "SELECT a.*,b.sort FROM qr_serials_manufacture a, qr_manufacture b WHERE a.manufacture_id = b.id AND a.serial_id = :serialId AND a.status = :status AND a.state = :state ORDER BY b.sort LIMIT 1";
  database.query({
    sql: sql,
    params: {
      "status": 0,
      "state": 1,
      "serialId":serialId
    }
  }, function (err, rows) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if(rows.length > 0){
      return callback(null, rows[0]);
    }else{
      return callback(null, null);
    }
  });
}

function currSerialManu(serialId, callback){
  var sql = "SELECT a.*,b.sort FROM qr_serials_manufacture a, qr_manufacture b WHERE a.manufacture_id = b.id AND a.serial_id = :serialId AND a.status = :status AND a.state = :state ORDER BY b.sort LIMIT 1";
  database.query({
    sql: sql,
    params: {
      "status": 0,
      "state": 1,
      "serialId":serialId
    }
  }, function (err, rows) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }
    if(rows.length > 0){
      return callback(null, rows[0]);
    }else{
      return callback(null, null);
    }
  });
}

exports.getSerialManuList = getSerialManuList;
exports.addSerialManu = addSerialManu;
exports.updateSerialManu = updateSerialManu;
exports.getSerialManuById = getSerialManuById;
exports.delSerialManu = delSerialManu;
exports.autoAddSerialManu = autoAddSerialManu;
exports.confirmSerialManu = confirmSerialManu;
exports.currSerialManu = currSerialManu;