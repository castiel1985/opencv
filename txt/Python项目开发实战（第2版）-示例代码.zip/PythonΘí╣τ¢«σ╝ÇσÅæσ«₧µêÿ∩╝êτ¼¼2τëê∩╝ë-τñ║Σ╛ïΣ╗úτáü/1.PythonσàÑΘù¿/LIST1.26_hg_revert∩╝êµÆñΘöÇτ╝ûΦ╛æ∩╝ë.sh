$ hg revert test.txt
