$ python manage.py migrate application file_name_or_number
