$ hg branch test-branch
$ hg branch
test-branch
