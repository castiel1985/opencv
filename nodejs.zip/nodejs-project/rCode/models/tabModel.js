"use strict";
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var async = require("async");
var commonUtils = require('../utils/Common');
var commonModel = require('./commonModel.js');

var tab_name = ['防伪验证','产品信息','生产信息','巡检信息','销售信息','物流信息' ,'联系我们','产品评价'];

function Initialize(corporationId, callback){
  var sql = 'INSERT INTO qr_tab (corporation_id,tab_name) values ';
  tab_name.forEach(function (item, index){
    tab_name[index] = "(:corporation_id,'"+item+"')";
  });
  sql = sql + tab_name.join(",");
  database.query({
    sql:sql,
    params:{corporation_id: corporationId}
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, result);
    } else {
      return callback(null, null);
    }
  });
}

function getTabByCorpId(tableParams, callback){
  var sqlData = "SELECT * FROM qr_tab WHERE corporation_id = :corpId ";
  var sqlCount = "SELECT count(*) as iTotalRecords FROM qr_tab WHERE corporation_id = :corpId ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var orderStr = " ORDER BY " + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + "and tab_name like :search " + orderStr + " limit :start,:length";
    sqlFilterCount = "SELECT count(*) as iTotalDisplayRecords FROM qr_tab WHERE corporation_id = :corpId and tab_name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr + " limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    callback(tableData);
  });
}

function updateTabById(params, callback){
  console.log(params);
  database.query({
    sql: "UPDATE qr_tab SET `state`=:state WHERE id =:id",
    params: params
  }, function(err, result) {
    if (err) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }else if (result.affectedRows) {
      return callback(null, true);
    } else {
      return callback(null, false);
    }
  });
}

exports.updateTabById = updateTabById;
exports.getTabByCorpId = getTabByCorpId;
exports.Initialize = Initialize;
