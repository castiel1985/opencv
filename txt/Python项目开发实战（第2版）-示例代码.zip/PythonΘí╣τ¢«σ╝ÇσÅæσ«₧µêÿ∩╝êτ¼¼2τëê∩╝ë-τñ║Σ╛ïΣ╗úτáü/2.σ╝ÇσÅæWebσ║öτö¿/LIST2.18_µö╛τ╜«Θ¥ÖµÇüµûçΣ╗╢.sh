$ mkdir static
$ mv main.css static/
