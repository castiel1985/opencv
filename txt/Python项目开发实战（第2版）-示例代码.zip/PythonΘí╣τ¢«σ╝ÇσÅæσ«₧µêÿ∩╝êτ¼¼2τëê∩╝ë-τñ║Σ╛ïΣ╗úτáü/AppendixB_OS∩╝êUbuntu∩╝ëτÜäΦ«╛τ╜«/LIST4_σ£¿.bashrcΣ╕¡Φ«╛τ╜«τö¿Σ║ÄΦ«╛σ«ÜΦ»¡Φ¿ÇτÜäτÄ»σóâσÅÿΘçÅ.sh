export LANG="zh_CN.UTF-8"
export LANGUAGE="zh_CN:zh"