"use strict";
var express = require('express');
var _ = require('underscore');
var router = express.Router();
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var serialsModel = require('../models/serialsModel');
var dataTableObj = require('../middleware/dataTableObject');
var logger = require('../utils/winstonUtils').logger;
var logsModel = require('../models/logsModel');
var nconf = require('nconf');

router.get('/', function (req, res, next) {

  var parentSerialId = req.serial_id;

  if (req.query["ajax"] === "1") {
    var params = {
      parentSerialId: parentSerialId,
      state: 1
    };
    serialsModel.getSubSerialsList(params, function (err, tableData) {
      return res.send(tableData);
    });
  } else {
    var opt = {
      user_id: req.session.rcode.user.id,
      url: nconf.get("url:sub_serials"),
      action: nconf.get("action:index"),
      operate_type: nconf.get("operate_type:sub_serials"),
      state: 1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('subserials', {
      header: "批次管理  > 子批次管理",
      parentSerialId: parentSerialId
    });
  }

});

router.get('/list', function (req, res, next) {

  var tableParams = dataTableObj.getParams(req);
  tableParams.parentSerialId = req.serial_id;
  tableParams.state = 1;
  serialsModel.getSubSerialsList(tableParams, function (tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item) {
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function (req, res, next) {

  var parentSerialId = req.serial_id;

  return res.render('subserials/add', {
    header: "批次管理  > 子批次管理 > 添加子批次",
    parentSerialId: parentSerialId
  });

});


router.post('/add', function (req, res, next) {

  var parentSerialId = req.serial_id;

  var params = {
    serial_no: req.body.serial_no,
    creator: req.session.rcode.user.id,
    parentSerialId: parentSerialId,
    state: 1,
    client_address: commonUtils.getClientIp(req)
  };

  serialsModel.addSubSerials(params, function (err, serialsId) {
    if (err) {
      return res.render('subserials/' + parentSerialId + '/add', {
        header: "批次管理  > 子批次管理 > 添加子批次",
        msg: messageUtils.msgError("子批次添加失败")
      });
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:sub_serials"),
        action: nconf.get("action:add"),
        operate_type: nconf.get("operate_type:sub_serials"),
        operate_id: serialsId,
        content: {subserial_no: req.body.serial_no},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("子批次添加成功");
      return res.redirect('/work_manage/serials_manage/'+parentSerialId+'/subserials/');
    }
  });

});

/**
 * TODO : 需要检查合法醒，是否伪装请求
 */

router.get('/update/:id', function (req, res, next) {
  var serial_Id = req.serial_id;
  var id = req.params.id;
  serialsModel.getSubSerials(id, function (err, row) {
    if (err) {
      next(err);
    }
    return res.render('subserials/update', {
      header: "批次管理 > 子批次管理 > 修改子批次信息",
      subserials: row,
      serialId: serial_Id
    });
  });

});

router.post('/update/:id', function (req, res, next) {
  var serialId = req.serial_id;
  var id = req.params.id;
  var params = {
    serial_no: req.body.serial_no
  };
  serialsModel.updateSerial(params, id, function (err, result) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgError("子批次修改失败");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/subserials/');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:sub_serials"),
        action: nconf.get("action:update"),
        operate_type: nconf.get("operate_type:sub_serials"),
        operate_id: id,
        content: {
          subserial_no: {old: req.body.old_serial_no, new: req.body.serial_no}
        },
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("子批次修改成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/subserials/');
    }
  });

});

router.get('/delete/:id', function (req, res, next) {
  var serialId = req.serial_id;
  var id = req.params.id;
  serialsModel.delSerialById(id, function (err, row) {
    if (err) {
      req.session.rcode.msg = messageUtils.msgSuccess("子批次信息删除失败");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/subserials/');
    } else {
      var opt = {
        user_id: req.session.rcode.user.id,
        url: nconf.get("url:sub_serials"),
        action: nconf.get("action:delete"),
        operate_type: nconf.get("operate_type:sub_serials"),
        operate_id: id,
        content: {subserial_no: req.query['serial_no']},
        state: 1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("子批次信息删除成功");
      return res.redirect('/work_manage/serials_manage/'+serialId+'/subserials/');
    }
  });
});


module.exports = router;