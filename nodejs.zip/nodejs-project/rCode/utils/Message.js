"use strict";
/**
 * Created by Alen on 15/3/4.
 * https://github.com/szanlin
 */



function msg(type,msg){
  return {
    type: type || "warning",
    content: msg || ""
  };
}

exports.msgWarn = function(str){
  return msg("warning",str);
};

exports.msgSuccess = function(str){
  return msg("success",str);
};

exports.msgError = function(str){
  return msg("danger",str);
};

exports.msgInfo = function(str){
  return msg("info",str);
};

exports.getSessionMsg = function(req,res){
  var msg = req.session.rcode.msg;
  if(msg) {
    res.locals.msg = msg;
    delete req.session.rcode.msg;
  }
};


exports.notify = function (req,res,msg){
  req.session.rcode.msg = msg;
  return res.redirect('/notify');
};

exports.flash = function (res,msg){
  res.session.rcode.msg = msg;
};
