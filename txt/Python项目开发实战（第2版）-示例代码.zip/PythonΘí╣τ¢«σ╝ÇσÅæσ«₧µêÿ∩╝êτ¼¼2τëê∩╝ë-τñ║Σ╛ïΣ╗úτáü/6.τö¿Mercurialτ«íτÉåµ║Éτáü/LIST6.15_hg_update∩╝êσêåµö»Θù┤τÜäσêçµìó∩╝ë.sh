$ hg update default
