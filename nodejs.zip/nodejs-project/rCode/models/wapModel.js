"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var async = require('async');
var queryModel = require('../models/queryModel');
var transmitModel = require('../models/transmitModel');
var advertisementModel = require('../models/advertisementModel');
var productionModel = require('../models/productionModel');

function getQrcodeByCode(qrcode, callback){
  var sql = "SELECT * FROM qr_code WHERE qrcode=:qrcode AND state=:state";
  var params = {
    qrcode:qrcode,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0]);
      } else {
        return callback(null, null);
      }
  });
}

function getProIdByApplyId(applyId, callback){
  var sql = "SELECT production_id FROM qr_code_apply WHERE id=:applyId AND state=:state";
  var params = {
    applyId:applyId,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0].production_id);
      } else {
        return callback(null, null);
      }
    });
}

function getDealerIdyByStart(start, callback){
  var sql = "SELECT * FROM qr_sold_record WHERE qrcode_start_id <= :start AND :start < (qrcode_start_id + sold_count) AND state=:state";
  var params = {
    start:start,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null,rows[0].dealer_id);
      } else {
        return callback(null, null);
      }
    });
}
//添加投诉
function insertCustomEvent(params, callback){
  var sql = "INSERT INTO qr_custom_events(production_id,qrcode_id,dealer_id,type,linkman,event_content,mobile,grade,state) VALUES(:production_id,:qrcode_id,:dealer_id,:type,:linkman,:event_content,:mobile,:grade,:state)";
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, result){
      console.log(err);
      if(err || !result){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      return callback(null, result);
    });
}

function getBrandByProId(proId, callback){
  var sql = "SELECT a.*,b.name AS brand_name,b.desc AS brand_desc,c.url FROM qr_production a, qr_brand b LEFT JOIN qr_file c ON c.id = b.logo_file_id WHERE b.id = a.brand_id AND a.id = :proId AND b.state = :state";
  var params = {
    proId:proId,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0]);
      } else {
        return callback(null, null);
      }
    });
}

function getCorpByQrCode(qrcode, callback){
  var sql = "SELECT b.* FROM qr_code a, qr_corporation b WHERE b.id = a.corporation_id AND a.qrcode = :qrcode AND b.state = :state";
  var params = {
    qrcode:qrcode,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0]);
      } else {
        return callback(null, null);
      }
    });
}

function getCommentsByProId(proId,start,length,callback){
  var sql1 = "SELECT * FROM qr_custom_events WHERE production_id = :proId ORDER BY create_time DESC LIMIT :start,:length";
  var sql2 = "SELECT count(id) AS total_count,avg(grade) AS average FROM qr_custom_events WHERE production_id = :proId";
  var sql3 = "SELECT count(id) AS grade_count,grade FROM qr_custom_events WHERE production_id = :proId GROUP BY grade";
  var params = {
    proId:proId,
    start:start,
    length:length,
    state:1
  };
  var results = [];
  var sqlArr = [sql1,sql2,sql3];
  async.eachSeries(sqlArr, function (item, cb){
    database.query({
      sql: item,
      params: params
    }, function(err, result) {
      if (err) {
        logger.error(err);
        cb(new global.ServerError("Can't connect MySQL"), null);
      }else{
        results.push(result);
        cb(null, result);
      }
    });
  },function(err){
    if(err){
      logger.error(err);
      return callback(err,results);
    }
    return callback(null,results);
  });
}

//根据二维码，查找详细信息
function getInfo(proId, serialId, subSerialId, qrcode, transmit_qrcode, callback){
  async.series(
    {
      pro:function(cb){
        productionModel.getProductionById(proId,cb);
      },
      corp:function(cb){
        getCorpByQrCode(qrcode,cb);
      },
      advertisement:function(cb){
        advertisementModel.getAdvertisementByCode(qrcode,cb);
      },
      records:function(cb){
        if(transmit_qrcode){
          transmitModel.getScanRecordByCode(transmit_qrcode, cb);
        }else{
          cb(null,null);
        }
      },
      comment:function(cb){
        getCommentsByProId(proId,0,10,cb);
      },
      mainInfo:function(cb){
        var params = {serialId:serialId,subSerialId:subSerialId,state:1};
        queryModel.getMainInfo(params, cb);
      }
    },
    function(err, results){
      callback(err, results);
    }
  );
}

function fakeCodeConfirm(qrcode, fake_code, callback){
  var sql = "SELECT * FROM qr_code WHERE qrcode = :qrcode AND fake_code = :fake_code AND state = :state";
  var params = {
    qrcode:qrcode,
    fake_code:fake_code,
    state:1
  };
  database.query(
    {
      sql:sql,
      params:params
    },
    function(err, rows){
      if(err){
        return callback(new global.ServerError("Can't connect MySQL"), null);
      }
      if (rows.length > 0) {
        return callback(null, rows[0]);
      } else {
        return callback(null, null);
      }
    });
}

exports.getQrcodeByCode=getQrcodeByCode;
exports.getProIdByApplyId=getProIdByApplyId;
exports.insertCustomEvent=insertCustomEvent;
exports.getDealerIdyByStart=getDealerIdyByStart;
exports.getInfo=getInfo;
exports.getCorpByQrCode=getCorpByQrCode;
exports.fakeCodeConfirm=fakeCodeConfirm;
exports.getCommentsByProId=getCommentsByProId;
