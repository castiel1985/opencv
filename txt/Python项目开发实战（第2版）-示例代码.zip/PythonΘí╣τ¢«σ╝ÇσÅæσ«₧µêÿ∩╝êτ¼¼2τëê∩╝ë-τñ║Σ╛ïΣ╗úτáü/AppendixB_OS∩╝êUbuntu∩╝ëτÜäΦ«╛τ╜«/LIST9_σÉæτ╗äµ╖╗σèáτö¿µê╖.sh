$ sudo usermod -aG sudo bpuser
