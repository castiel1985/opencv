"use strict";
var express = require('express');
var router = express.Router();
var codeModel = require('../models/qrcodeModel');
var messageUtils = require('../utils/Message');
var commonUtils = require('../utils/Common');
var qrcodeUtils = require('../middleware/qrcode');
var dataTableObj = require('../middleware/dataTableObject');
var underscore = require('underscore');
var http = require("http");
var nconf = require('nconf');
var logger = require('../utils/winstonUtils').logger;
var fs = require('fs');
var path = require("path");
var dataTableObj = require('../middleware/dataTableObject');
var childProcess = require('child_process');
var logsModel = require('../models/logsModel');
var async = require("async");

router.get('/', function(req, res, next) {
  messageUtils.getSessionMsg(req, res);
  var usr = req.session.rcode.user;
  var params = {
    user_id:usr.id,
    url:nconf.get("url:qrcode"),
    action:nconf.get("action:index"),
    operate_type:nconf.get("operate_type:qrcode"),
    state:1,
    client_address: commonUtils.getClientIp(req)
  };
  logsModel.addOperateLog(params);
  return res.render('qrcode', {
    header: "企业二维码管理"
  });
});

router.get('/list', function(req, res, next) {
  var corp = req.session.rcode.corporation;
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.userId = usr.id;
  tableParams.corpId = corp.id;
  tableParams.status = null;
  codeModel.getQrcodeApplyList(tableParams, function(tableData) {
    messageUtils.getSessionMsg(req, res);
    var status = ['未审核', '审核拒绝', '审核通过',  '打包完成'];
    tableData.aaData.forEach(function(item){
      item.apply_time = commonUtils.dateFormat(new Date(item.create_time));
      item.status_text = status[item.status];
      item.is_show_code = item.status > 1;
      item.generate_count = item.generate_count || 0;
    });
    return res.send(tableData);
  });

});

router.get('/add', function(req, res, next) {

  return res.render('qrcode/apply', {
    header: "企业二维码管理 > 申请产品二维码"
  });

});

router.post('/add', function(req, res, next) {

  var corp = req.session.rcode.corporation;
  var usr = req.session.rcode.user;
  var params = {
    production_id: null,
    apply_count: req.body.apply_count,
    corporation_id: corp.id,
    apply_user_id: usr.id,
    status: 0,
    state: 1,
    qrcode_start: 1,
    client_address: commonUtils.getClientIp(req)
  };

  codeModel.applyCode(params, function(err, applyId) {
    if (err) {
      return res.render('qrcode/apply', {
        header: "企业二维码管理 > 申请产品二维码",
        msg: messageUtils.msgError("申请产品二维码失败")
      });
    } else {
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:qrcode"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:qrcode"),
        operate_id:applyId,
        content:{apply_count:req.body.apply_count},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      if(corp && corp.is_auto_approve){
        codeModel.geApplyById(applyId, function(err, apply){
          var corpId = corp.id;
          var qrcode = corp.qrcode;
          var start = apply.qrcode_start;
          var generate = apply.apply_count;
          var child_process = childProcess.fork([path.join(__dirname, "../middleware/insertProductionCode.js")], [corpId, qrcode, applyId, start, generate, 3], {
            detached: true
          });
          child_process.on('error', function (data) {
            logger.error('error: ' + data);
          });
          child_process.on("message", function(m){
            logger.info(m);
            child_process.kill();
          });

          var params = {
            generate_count:generate,
            approve_user_id:usr.id,
            status:2,
            id:applyId
          };
          codeModel.approveCode(params, function(err){
            if (err) {
              return next(err);
            }
            req.session.rcode.msg = messageUtils.msgSuccess("申请产品二维码成功");
            return res.redirect('/qrcode/apply');
          });
        });
      }else{
        req.session.rcode.msg = messageUtils.msgSuccess("申请产品二维码成功,等待监管部门审核");
        return res.redirect('/qrcode/apply');
      }
    }
  });

});



router.get('/view/:id', function(req, res, next) {
  var applyId = req.params.id;
  codeModel.geApplyById(applyId, function(err, apply){
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:qrcode"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:qrcode"),
      operate_id:applyId,
      content:{apply_count:apply.apply_count},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
  });
  return res.render('qrcode/view', {
    header: "查看产品二维码",
    applyId : applyId,
    layout: "partial/modal_layout"
  });
});


router.get('/view/:id/list', function(req, res, next) {
  var applyId = req.params.id;
  var tableParams = dataTableObj.getParams(req);
  tableParams.applyId = applyId;
  tableParams.state = 1;
  if (underscore.isNaN(applyId)) {
    return next(new Error("Invalid Parameters"));
  }
  async.waterfall([
    function(cb){
      codeModel.geApplyById(applyId, function(err, apply){
        cb(err, apply);
      });
    },
    function(apply, cb){
      tableParams.apply_count = apply.apply_count;
      var corp_qrcode = apply.corporation_qrcode;
      var page_start = parseInt(tableParams.start);
      var qrcode_prefix = corp_qrcode + "." + commonUtils.padZero(parseInt(applyId), 8);
      tableParams.page_startcode = qrcode_prefix + "." + commonUtils.padZero(parseInt(1) + page_start, 8) + "." + 3;
      codeModel.queryApprovedQrcode(tableParams, function(tableData) {
        cb(null, tableData);
      });
    }
  ], function (err, tableData) {
    if(!err){
      return res.send(tableData);
    }
  });
});

/*router.get('/image/:content', function(req, res, next) {
  var content = req.params.content;
  var params = {
    *//*host: nconf.get("qr_service:host"),
    port: nconf.get("qr_service:port"),
    path: nconf.get("qr_service:path") + '?c=' + content,*//*
    host: "qr.liantu.com",
    port: "80",
    path: "/api.php?el=l&w=200&m=10&text=" + content,
    method: 'GET'
  };
  var request = http.request(params, function(response) {
    var dataArr = [],
      len = 0;
    response.on('data', function(chunk) {
      dataArr.push(chunk);
      len += chunk.length;
    });
    response.on('end', function() {
      res.set("Content-Type", 'image/jpeg');
      return res.send(200, Buffer.concat(dataArr, len));
    });
  });
  request.on('error', function(e) {
    logger.error('problem with request: ' + e.message);
  });
  request.end();

});*/

router.get('/view_sales/:id', function(req, res, next) {
  var applyId = req.params.id;

  if (underscore.isNaN(applyId)) {
    return next(new Error("Invalid Parameters"));
  }

  codeModel.geApplyById(applyId, function(err, apply){
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:qrcode"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:sold_record"),
      operate_id:applyId,
      content:{apply_count:apply.apply_count},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
  });

  return res.render('qrcode/view_sales', {
    header: "查看销售记录",
    applyId: applyId,
    layout: "partial/modal_layout"
  });
});

router.get('/view_sales/:id/list', function(req, res, next) {
  var applyId = req.params.id;
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.applyId = applyId;
  tableParams.state = 1;

  codeModel.querySoldRecores(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function(item){
      item.sold_date = commonUtils.dateFormat(new Date(item.sold_date));
    });
    return res.send(tableData);
  });
});


router.get('/view_transmit/:id', function(req, res, next) {
  var applyId = req.params.id;

  if (underscore.isNaN(applyId)) {
    return next(new Error("Invalid Parameters"));
  }

  codeModel.queryTransmitRecores(applyId, function(err, rows) {
    if (err) {
      return next(err);
    }
    return res.render('qrcode/view_transmit', {
      header: "查看物流信息",
      sales: rows,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/download/:id', function(req, res, next) {
  var applyId = req.params.id;
  var dir = path.join(__dirname, "../public/qrcodedownload/productioncode/");
  /*var fullName = path.join(dir + "apply_"+applyId+".zip");
  var tmpName = path.join(dir + "apply_"+applyId+".tmp.zip");
  var tmpPath = path.join(dir + "apply_"+applyId+".tmp");*/

  var fileName = path.join(dir + "apply_"+applyId+".txt");
  var tmpName = path.join(dir + "apply_"+applyId+".tmp.txt");
  codeModel.geApplyById(applyId, function(err, apply){
    var params = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:qrcode"),
      action:nconf.get("action:download"),
      operate_type:nconf.get("operate_type:qrcode"),
      operate_id:applyId,
      content:{production_name:apply.production_name,apply_count:apply.apply_count},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params);
  });

  fs.exists(fileName, function (exists) {
    if(exists){
      res.download(fileName,"apply_"+applyId+".txt");
    }else{
      if(fs.existsSync(tmpName)){
        req.session.rcode.msg = messageUtils.msgSuccess("文件生成中，请稍后再下载");
        return res.redirect('/qrcode/apply');
      }else{
        logger.info("重新生成二维码文件");
        var child_process = childProcess.fork([path.join(__dirname, "../middleware/insertProductionCode.js")], [applyId], {
          detached: true
        });
        child_process.on('error', function (data) {
          logger.error('error: ' + data);
          child_process.kill();
        });
        child_process.on("message", function(m){
          logger.info(m);
          child_process.kill();
        });
        req.session.rcode.msg = messageUtils.msgSuccess("文件生成中，请稍后再下载");
        return res.redirect('/qrcode/apply');
      }
    }
  });
});

module.exports = router;