"use strict";
/**
 * Created by Alen on 15/2/26.
 */
var database = require('../database/mysql.js');
var logger = require('../utils/winstonUtils').logger;
var commonModel = require("./commonModel.js");

function getBrandListByCorpId(tableParams, callback) {
  var sqlData = "SELECT a.* FROM qr_brand a,qr_user b,qr_corporation c WHERE a.creator = b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state ";
  var sqlCount = "SELECT count(a.id) as iTotalRecords FROM qr_brand a,qr_user b,qr_corporation c WHERE a.creator = b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state ";
  var sqlFilterCount = "";
  var sqlArr = [];
  var pagFlag = true; //是否分页
  var orderStr = " ORDER BY a." + tableParams.orderName + " " + tableParams.orderDir;
  if(tableParams.search){
    tableParams.search = "%" + tableParams.search + "%";
    sqlData = sqlData + " AND a.name like :search " + orderStr +" limit :start,:length";
    sqlFilterCount = "SELECT count(a.id) as iTotalDisplayRecords FROM qr_brand a,qr_user b,qr_corporation c WHERE a.creator = b.id AND c.id = b.corporation_id AND ((c.share is true AND b.corporation_id = :corpId) || (c.share is false AND b.id = :userId)) AND a.state = :state AND a.name like :search ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
    sqlArr.push(sqlFilterCount);
  }else if(tableParams.length){
    sqlData = sqlData + orderStr +" limit :start,:length ";
    sqlArr.push(sqlData);
    sqlArr.push(sqlCount);
  }else{
    pagFlag = false;
    sqlArr.push(sqlData);
  }
  commonModel.queryTableDatas(sqlArr, tableParams, function(err,tableData){
    if(err){
      logger.error(err);
    }
    if(pagFlag){
      callback(tableData);
    }else{
      callback(tableData.aaData);
    }
  });
}

function getBrandById(id, callback) {
  database.query({
    sql: "select a.*,b.name as filename,b.url from qr_brand a,qr_file b where a.logo_file_id = b.id and" +
      " a.id =:id",
    params: {
      "id": id
    }
  }, function(err, rows) {
    if (err || !rows) {
      logger.error(err ? err.stack : "row is null");
      return callback(new global.ServerError("Can't connect MySQL"), null);
    }

    if (rows.length > 0) {
      return callback(null, rows[0]);
    } else {
      return callback(null, null);
    }

  });
}

function addBrand(options, callback) {
  var sql = 'INSERT INTO qr_brand (`name`,' +
    ' `desc`, ' +
    ' `other`, ' +
    '`creator`, ' +
    '`state`,'+
    '`client_address`) values ' +
    '(:name,'+
    ':desc,' +
    ':other,' +
    ':creator,' +
    'true,' +
    ':client_address)';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var brandId = result.insertId;
    logger.info("added brand logo id = %d", brandId);

    if(options.files) {
      options.files.forEach(function (item) {
        item.creator = options.creator;
        item.type = 'brand_logo_' + brandId;
        insertFiles(item, brandId, callback);
      });
    }
    return callback(null, brandId);
  });

}

function updateBrand(options, callback) {
  var sql = 'UPDATE qr_brand SET name =:name,' +
    ' `desc` =:desc,' +
    ' other =:other,' +
    ' creator =:creator ' +
    'where id =:id';
  database.query({
    sql: sql,
    params: options
  }, function(err, result) {
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    var brandId = options.id;
    logger.info("added brand logo id = %d", brandId);

    if(options.files) {
      options.files.forEach(function (item) {
        item.creator = options.creator;
        item.type = 'brand_logo_' + brandId;
        insertFiles(item, brandId, callback);
      });
    }
    return callback(null, brandId);
  });

}

function insertFiles(opts, brandId, callback){
  var insert = "insert into qr_file (name,url,`type`,mime,creator,`state`) values (:filename,:url,:type,:mimetype,:creator,true)";
  database.query({
    sql: insert,
    params: opts
  },function(err, result){
    if (err) {
      logger.error(err.stack);
      return callback(new global.DBError("MySQL Error"), null);
    }
    updateLogoFileId(brandId, result.insertId, null);
  });
}

function updateLogoFileId(brandId, logoFileId, callback){
  var update = "update qr_brand set logo_file_id =:logoFileId where id =:id";
  database.query({
    sql: update,
    params: {
      id: brandId,
      logoFileId: logoFileId
    }
  },null); //just ignore errors! //TODO
}

function deletBrand(id, callback) {
    database.query({
        sql: "UPDATE qr_brand SET state = 0 WHERE id =:id",
        params: {
            "id": id
        }
    }, function(err, result) {
        if (err) {
            logger.error(err ? err.stack : "row is null");
            return callback(new global.ServerError("Can't connect MySQL"), null);
        }else{
          if (result.affectedRows) {
            return callback(null, true);
          } else {
            return callback(null, null);
          }
        }
    });
}

exports.getBrandListByCorpId = getBrandListByCorpId;
exports.addBrand = addBrand;
exports.deletBrand = deletBrand;
exports.updateBrand = updateBrand;
exports.getBrandById = getBrandById;
