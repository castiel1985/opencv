"use strict";
var express = require('express');
var router = express.Router();
var brandModel = require('../models/brandModel');
var productionModel = require('../models/productionModel');
var commonUtils = require('../utils/Common');
var messageUtils = require('../utils/Message');
var logger = require('../utils/winstonUtils').logger;
var underscore = require('underscore');
var dataTableObj = require('../middleware/dataTableObject');
var logsModel = require('../models/logsModel');
var nconf = require('nconf');
var os = require('os');

router.get('/', function(req, res, next) {
  var usr = req.session.rcode.user;
  if (req.query["ajax"] === "1") {
    var params = {
      userId:usr.id,
      corpId:usr.corporation_id,
      state:1
    };
    brandModel.getBrandListByCorpId(params, function(tableData) {
      return res.send(tableData);
    });
  } else {
    var params2 = {
      user_id:usr.id,
      url:nconf.get("url:brand"),
      action:nconf.get("action:index"),
      operate_type:nconf.get("operate_type:brand"),
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(params2);
    messageUtils.getSessionMsg(req, res);
    return res.render('brand', {
      header: "品牌管理"
    });
  }
});

router.get('/list', function(req, res, next) {
  var usr = req.session.rcode.user;
  var tableParams = dataTableObj.getParams(req);
  tableParams.state = 1;
  tableParams.corpId = usr.corporation_id;
  tableParams.userId = usr.id;
  brandModel.getBrandListByCorpId(tableParams, function(tableData) {
    tableData.aaData && tableData.aaData.forEach(function (item){
      item.create_time = commonUtils.dateFormat(new Date(item.create_time));
    });
    return res.send(tableData);
  });
});

router.get('/add', function(req, res, next) {

  return res.render('brand/add', {
    header: "品牌管理 > 添加品牌",
    creator: req.session.rcode.user.id
  });

});

router.post('/add', function(req, res, next) {
  var usr = req.session.rcode.user;
  var creator = req.body.creator;
  if (creator != usr.id) {
    return messageUtils.notify(req, res, messageUtils.msgWarn("非法的提交路径"));
  }

  var params = {
    creator: usr.id,
    name: req.body.name,
    desc: req.body.desc || '',
    other: req.body.other || '',
    client_address: commonUtils.getClientIp(req)
  };

  var files = req.session.rcode.uploadedFile;
  if(files){
    //saved to db
    delete req.session.rcode.uploadedFile;
    params.files = files;
  }

  brandModel.addBrand(params,function(err, brandId){
    if(err){
      return res.render('brand/add', {
        header: "品牌管理 > 添加品牌",
        msg: messageUtils.msgError("品牌添加失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var filename = files ? files[0].filename : "";
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:brand"),
        action:nconf.get("action:add"),
        operate_type:nconf.get("operate_type:brand"),
        operate_id:brandId,
        content:{name:req.body.name,images:filename},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("品牌添加成功");
      return res.redirect('/brand');
    }
  });

});


//修改页面
router.get('/update/:id', function(req, res, next) {

  var id = req.params.id;

  brandModel.getBrandById(id, function(err, brand){
    if(err){
      next(err);
    }
    return res.render('brand/update', {
      header: "品牌管理 > 修改品牌",
      brand: brand
    });
  });
});


router.post('/update', function(req, res, next) {

  var usr = req.session.rcode.user;

  var params = {
    creator: usr.id,
    id: req.body.brandId,
    name: req.body.name,
    desc: req.body.desc || '',
    other: req.body.other || ''
  };

  var files = req.session.rcode.uploadedFile;
  if(files){
    delete req.session.rcode.uploadedFile;
    params.files = files;
  }

  brandModel.updateBrand(params, function(err, brandId){
    if(err){
      return res.render('brand/update', {
        header: "品牌管理 > 更新品牌",
        msg: messageUtils.msgError("品牌更新失败"),
        creator: req.session.rcode.user.id
      });
    }else{
      var name = {old:req.body.old_name, new:req.body.name};
      var filename = files ? files[0].filename : req.body.old_filename;
      var images = {old:req.body.old_filename, new:filename};
      var opt = {
        user_id:usr.id,
        url:nconf.get("url:brand"),
        action:nconf.get("action:update"),
        operate_type:nconf.get("operate_type:brand"),
        operate_id:brandId,
        content:{name:name,images:images},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
      req.session.rcode.msg = messageUtils.msgSuccess("品牌资料更新成功");
      return res.redirect('/brand');
    }
  });


});

router.get('/view/:brand_id', function(req, res, next) {
  var brandId = req.params.brand_id;
  if(underscore.isNaN(brandId)){
    return next(new Error("Invalid brandId"));
  }
  brandModel.getBrandById(brandId, function(err, row) {
    if (err) {
      return next(err);
    }
    var opt = {
      user_id:req.session.rcode.user.id,
      url:nconf.get("url:brand"),
      action:nconf.get("action:view"),
      operate_type:nconf.get("operate_type:brand"),
      operate_id:brandId,
      content:{name:row.name},
      state:1,
      client_address: commonUtils.getClientIp(req)
    };
    logsModel.addOperateLog(opt);
    messageUtils.getSessionMsg(req, res);
    return res.render('brand/view', {
      header: "产品详情",
      brand: row,
      layout: "partial/modal_layout"
    });
  });
});

router.get('/delete/:brand_id', function(req, res, next) {

  var brand_id = req.params.brand_id;
  productionModel.getProductionListByBrandId(brand_id,function(err, rows){
    if(rows){
      req.session.rcode.msg = messageUtils.msgError("品牌信息删除失败,请删除相关产品后再试");
      return res.redirect('/brand');
    }
    brandModel.getBrandById(brand_id, function(err, row) {
      var opt = {
        user_id:req.session.rcode.user.id,
        url:nconf.get("url:brand"),
        action:nconf.get("action:delete"),
        operate_type:nconf.get("operate_type:brand"),
        operate_id:brand_id,
        content:{name:row.name},
        state:1,
        client_address: commonUtils.getClientIp(req)
      };
      logsModel.addOperateLog(opt);
    });

    brandModel.deletBrand(brand_id, function(err, brand){
      if (err) {
        req.session.rcode.msg = messageUtils.msgError("品牌信息删除失败");
        return res.redirect('/brand');
      } else {
        req.session.rcode.msg = messageUtils.msgSuccess("品牌信息删除成功");
        return res.redirect('/brand');
      }
    });
  });
});

module.exports = router;