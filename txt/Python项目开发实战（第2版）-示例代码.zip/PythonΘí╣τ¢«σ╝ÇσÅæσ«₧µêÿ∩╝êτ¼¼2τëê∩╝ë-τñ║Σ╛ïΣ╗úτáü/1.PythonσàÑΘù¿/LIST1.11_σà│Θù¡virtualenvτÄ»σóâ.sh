(venv) $ deactivate
$
