$ python manage.py makemigrations --empty polls
Migrations for 'polls':
0003_auto_20141104_0236.py:
