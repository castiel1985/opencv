$ python django_and_bpmappers.py
{'id': 123, 'name': u'okano', 'age': 26}
