$ sudo nginx -t
the configuration file /etc/nginx/nginx.conf syntax is ok
configuration file /etc/nginx/nginx.conf test is successful
$ sudo service nginx reload
* Reloading nginx configuration nginx                             [ OK ]
